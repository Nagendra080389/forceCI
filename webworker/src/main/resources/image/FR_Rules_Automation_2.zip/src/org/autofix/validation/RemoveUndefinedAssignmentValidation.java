package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
* Violation detection file to detect assignment of "undefined" value to variables in Javascript files.
* Undefined should not be assigned as value to variables. Instead, null can be assigned.
* Instances of such usage will be replaced with null.
* Example : Before Autofix : var variable = undefined;
*  		  : After Autofix : var variable = null;
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-07-24
*/

public class RemoveUndefinedAssignmentValidation implements IValidation {
	
	private static final String EQUALS_UNDEFINED_PATTERN = "\\s*[a-zA-Z0-9]*[=]{1}\\s*undefined\\s*;";
	private static final String WHITESPACE_UNDEFINED_PATTERN = "\\s*undefined\\s*;";
	private static final String ONLY_WHITESPACE_PATTERN = "^\\s*$";
	private static final Pattern equalsUndefinedPattern = Pattern.compile(EQUALS_UNDEFINED_PATTERN);
	private static final Pattern whitespaceUndefinedPattern = Pattern.compile(WHITESPACE_UNDEFINED_PATTERN);
	private static final Pattern onlyWhitespacePattern = Pattern.compile(ONLY_WHITESPACE_PATTERN);

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<>();
		List<Violation> lstViolation = null;
		List<String> lstLines = null;
		int equalsLineNum = 0;
		int undefinedLineNum = 0;
		int equalsCount = 0;
		boolean undefinedFound = false;
		
		Matcher equalsUndefinedMatcher;
		Matcher whitespaceUndefinedMatcher;
		Matcher onlyWhitespaceMatcher;
		for (String filePath : fileNameLst) {
			try {
				lstViolation = new ArrayList<>();
				lstLines = Files.readAllLines(Paths.get(filePath));
				for (int i = 0; i < lstLines.size(); i++) {
					
					String currentLine = lstLines.get(i);
					
					//Pattern matching to check if we get "= undefined" on the same line or spread across multiple lines					
					equalsUndefinedMatcher = equalsUndefinedPattern.matcher(currentLine);
					whitespaceUndefinedMatcher = whitespaceUndefinedPattern.matcher(currentLine);
					onlyWhitespaceMatcher = onlyWhitespacePattern.matcher(currentLine);
					
					//Get the count of equals symbol in each line
					equalsCount += StringUtils.countMatches(currentLine, AppConstants.EQUALS_SIGN);
					
					//If count of equals symbol = 1 and line contains either (= undefined) or only whitespace
					if(equalsCount == 1 && (equalsUndefinedMatcher.find() || whitespaceUndefinedMatcher.find())) {
						
						equalsLineNum = (equalsLineNum == 0) ? (i+1) : equalsLineNum;
						
						undefinedLineNum = i+1;
						undefinedFound = true;
					}
					//If count of equals symbol = 1 and line contains either (= ) or only whitespace
					else if(equalsCount == 1 && (AppConstants.EMPTY.equals(currentLine.substring(currentLine.indexOf(AppConstants.EQUALS_SIGN)+1, currentLine.length()-1))
							|| onlyWhitespaceMatcher.find())) {
						
						equalsLineNum = (equalsLineNum == 0) ? (i+1) : equalsLineNum;
					}
					//If none of the above conditions match, then set equalsCount variable to value 0
					else {
						equalsCount = (equalsCount>0) ? 0 : equalsCount;
					}
					
					//If (= undefined) is found in same line or across multiple lines, then create a Violation object
					if(equalsCount == 1 && undefinedFound) {
						
						//Create violation object for the issue
						createViolation(equalsLineNum, undefinedLineNum, lstViolation);						
						
						//Reset the variables to default values
						equalsCount = 0;
						equalsLineNum = 0;
						undefinedLineNum = 0;
						undefinedFound = false;
					}
				}				
			
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));
				}
			}catch (Exception e) {
				Logging.log(e,"Error occurred for file :: "+filePath);
			}
		}
		return lstFiles;
	}

	/**
	 * Method to set list of all violations for a file
	 * @param filePath
	 * @param lstViolation
	 * @return
	 */
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;
	}
	
	
	/**
     * Method name  : createViolation
     * Description  : Create violation objects for issues and add to list of violations
     * Return Type  : void
     * Parameter    : int equalsLineNum, int undefinedLineNum, List<Violation> lstViolation
     **/
	private static void createViolation(int equalsLineNum, int undefinedLineNum, List<Violation> lstViolation) {
		
		Violation violation = new Violation();
		violation.setBeginline(BigInteger.valueOf(equalsLineNum));
		violation.setEndline(BigInteger.valueOf(undefinedLineNum));
		violation.setRule(CustomValidationRules.UNDEFINED_ASSIGNMENT);
		
		//Add the violation object to the list of violations
		lstViolation.add(violation);
	}

}
