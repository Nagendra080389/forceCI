package org.autofix.ui.panel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.filechooser.FileSystemView;

import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.service.AutofixService;
import org.autofix.service.Autofix_ExcecutorService;
import org.autofix.ui.PanelProgressBar;
import org.autofix.utility.AutofixUIUtility;
import org.autofix.utility.Reporting;
import org.autofix.utility.AppUtility.StringUtility;

public class HomePanel extends ForceReviewerPanel implements ActionListener{

	private static final long serialVersionUID = -7538400623198737401L;
	private boolean initDone = false;
	private Font SALESFORCE_SANS_PLAIN_14 = new Font("Salesforce Sans", Font.PLAIN,14);
	private Font SALESFORCE_SANS_PLAIN_15 = new Font("Salesforce Sans", Font.PLAIN,15);
	private JTextField dstTextField;
	private JTextField srcTextField;
	private JProgressBar progressBar;
	private JLabel errorLabel;
	private JFrame currentFrame;
	private JLabel infoLabel;
	private JButton srcBtn,destinationBtn,submitBtn;
	
	public HomePanel(JFrame frame) {
		this.setLayout(null);
		this.setBackground(Color.WHITE);
		this.setBounds(AppConstants.FR_PANEL_BOUNDS);
		this.currentFrame = frame;
		frame.add(this);
	}
	
	@Override
	public void entry() {
		if(!initDone){
			initDone = true;
			
			errorLabel = new JLabel();
			errorLabel.setForeground(Color.red);
			errorLabel.setText("This will be here");
			
			infoLabel = new JLabel();
			infoLabel.setFont(SALESFORCE_SANS_PLAIN_15);
			infoLabel.setText("Please Select Respective Directories");
			infoLabel.setForeground(Color.BLACK);
			
			JLabel srcLabel = new JLabel();
			srcLabel.setText("Source :");
			srcLabel.setFont(SALESFORCE_SANS_PLAIN_14);
			srcLabel.setForeground(Color.BLACK);
			
			srcTextField= new JTextField();
			srcTextField.setEditable(false);
			srcTextField.setBackground(Color.WHITE);
			
			srcBtn = new JButton("Select");
			srcBtn.setFont(SALESFORCE_SANS_PLAIN_14);
			srcBtn.setBackground(Color.decode("#152D4B"));
			srcBtn.setForeground(Color.WHITE);
			srcBtn.setToolTipText("Source Folder Location");
			
			JLabel destinationLabel = new JLabel("Destination :");
			destinationLabel.setForeground(Color.BLACK);
			destinationLabel.setFont(SALESFORCE_SANS_PLAIN_14);
			
			
			dstTextField = new JTextField();
			dstTextField.setEditable(false);
			dstTextField.setBackground(Color.WHITE);
			
			destinationBtn = new JButton("Select");
			destinationBtn.setFont(SALESFORCE_SANS_PLAIN_14);
			destinationBtn.setBackground(Color.decode("#152D4B"));
			destinationBtn.setForeground(Color.WHITE);
			
			submitBtn=new JButton("Submit");
			submitBtn.setFont(SALESFORCE_SANS_PLAIN_14);
			submitBtn.setForeground(Color.WHITE);
			submitBtn.setBackground(Color.decode("#152D4B"));
			
			progressBar = new JProgressBar(AppConstants.UI_PROGRESS_BAR_MIN_VALUE,AppConstants.UI_PROGRESS_BAR_MAX_VALUE);
			progressBar.setStringPainted(true);
			progressBar.setForeground(Color.decode("#006400"));
			progressBar.setVisible(false);
			
			
			// Setting Bounds
			infoLabel.setBounds(10, 100, 1000, 50);
			
			srcLabel.setBounds(10, 120, 100, 100);
			srcTextField.setBounds(110, 160, 180, 30);
			srcBtn.setBounds(300, 160, 130, 30);
			
			destinationLabel.setBounds(10, 170, 100, 100);
			dstTextField.setBounds(110, 210, 180, 30);
			destinationBtn.setBounds(300, 210, 130, 30);
			
			submitBtn.setBounds(10,250,140, 40);
			progressBar.setBounds(10,300, 420, 20);
			
			// adding to panel
			this.add(errorLabel);
			this.add(destinationBtn);
			this.add(srcBtn);
			this.add(submitBtn);
			this.add(infoLabel);
			this.add(destinationLabel);
			this.add(srcLabel);
			this.add(dstTextField);
			this.add(srcTextField);
			this.add(progressBar);
			
			// Add Action
			srcBtn.addActionListener(this);
			destinationBtn.addActionListener(this);
			submitBtn.addActionListener(this);
		}
		this.setVisible(true);
		AutofixUIUtility.setFrPanelRef(this);
	}
	
	private void doValidation() throws CustomException{
		if(!StringUtility.isNotNullOrBlank(srcTextField.getText()) || !StringUtility.isNotNullOrBlank(dstTextField.getText())){
			throw new CustomException(AppConstants.SELECT_PROPER_PATH_ERROR_MSG);
		}
	}
	
	@Override
	public void showError(String errorMsg){
		infoLabel.setForeground(Color.RED);
		infoLabel.setText(errorMsg);
	}
	
	@Override
	public void showInfo(String infoMsg){
		infoLabel.setForeground(Color.decode("#006400"));
		infoLabel.setText(infoMsg);
	}

	@Override
	public void exit() throws CustomException {
		// TODO Auto-generated method stub
		this.setVisible(false);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() instanceof JButton){
			JButton currentActionButton = (JButton) e.getSource();
			if(currentActionButton == srcBtn){
				JFileChooser chooser = new JFileChooser(); 
				chooser.setCurrentDirectory(FileSystemView.getFileSystemView().getHomeDirectory());
				chooser.setDialogTitle("Select Source Folder");
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setAcceptAllFileFilterUsed(false);
				if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) { 
					srcTextField.setText(chooser.getSelectedFile().getAbsolutePath());
				}
			}
			if(currentActionButton == destinationBtn){
				JFileChooser chooser = new JFileChooser(); 
				chooser.setCurrentDirectory(FileSystemView.getFileSystemView().getHomeDirectory());
				chooser.setDialogTitle("Select Destination Folder");
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setAcceptAllFileFilterUsed(false);
				if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) { 
					dstTextField.setText(chooser.getSelectedFile().getAbsolutePath());
				}
			}
			if(currentActionButton == submitBtn){
				try{					
					doValidation();
					AutofixUIUtility.resetProgressBar();
					Autofix_ExcecutorService.submitTask(new AutofixService(srcTextField.getText(), dstTextField.getText()));
					Autofix_ExcecutorService.submitTask(new PanelProgressBar(progressBar,currentFrame));
					//Reporting.initiateReportPreq();
					showInfo(AppConstants.AUTOFIX_SUBMIT_MSG);
				}catch (Exception error) {
					showError(error.getMessage());
				}
			}
		}
	}

}
