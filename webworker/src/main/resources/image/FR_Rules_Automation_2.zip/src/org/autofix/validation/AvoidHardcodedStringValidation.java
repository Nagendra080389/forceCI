package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.checker.ApexCommentChecker;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.AppUtility;
import org.autofix.utility.Logging;

public class AvoidHardcodedStringValidation implements IValidation{

	// Anything which is in ' ' capture that
	private final Pattern violationCheckPattern = Pattern.compile("'(.*?)'");
	// If Line Contains a String Variable or a variable which takes string or start with +,',system.debug,/,* ignore that line
	private final Pattern invalidLineCheckPattern = Pattern.compile("(string\\s+[a-zA-Z$_][a-zA-Z0-9$_]*\\s+=)|"
			+"(string\\s+[a-zA-Z$_][a-zA-Z0-9$_]*=)|"
			+ "([a-zA-Z$_][a-zA-Z0-9$_]*\\s+[\\+]{1}[=]{1})|"
			+ "([a-zA-Z$_][a-zA-Z0-9$_]*[\\+]{1}[=]{1})|"
			+ "(^['+/*]{1})|"
			+ "(^system.debug)|"
			+ "(^@)|"
			+ "(^when)|"
			+ "(=database.query\\()|"
			+ "(=\\s+database.query\\()"
			+ "(=database.query\\s+\\()|"
			+ "(=\\s+database.query\\s+\\()"
			+ "(=database.getquerylocator\\()|"
			+ "(=\\s+database.getquerylocator\\()"
			+ "(=database.getquerylocator\\s+\\()|"
			+ "(=\\s+database.getquerylocator\\s+\\()"
			);
	private static final String ESCAPE_CHAR = "\\";
	private ApexCommentChecker commentChecker;

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		List<Violation> tempViolation;
		File tempFile;
		for(String filePath : fileNameLst){
			try{
				violationLst = new ArrayList<>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				commentChecker = ApexCommentChecker.getInstance(lstLines);
				for(int i=0;i<lstLines.size();i++){
					tempViolation = checkForViolation(lstLines.get(i).toLowerCase(),i+1);
					if(AppUtility.isNotNullOrBlank(tempViolation)){
						violationLst.addAll(tempViolation);
					}
				}
				if(!violationLst.isEmpty()){
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			}catch(Exception err){
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	private List<Violation> checkForViolation(String line,int lineNumber){
		if(line!=null){
			if(!isValidLine(line)){
				return null;
			}
			List<Violation> violationLst = new ArrayList<>();
			Violation tempViolation;
			Matcher matcher = violationCheckPattern.matcher(line);
			while(matcher.find()){
				// No escape character inside Hardcoded String
				if(line.substring(matcher.start()+1, matcher.end()-1).indexOf(ESCAPE_CHAR) == -1){
					// check if this is not part of comment
					if(!commentChecker.isCommented(lineNumber, matcher.start())){
						tempViolation = new Violation();
						tempViolation.setBeginline(BigInteger.valueOf(lineNumber));
						tempViolation.setBegincolumn(BigInteger.valueOf(matcher.start()));
						tempViolation.setEndcolumn(BigInteger.valueOf(matcher.end()));
						tempViolation.setRule(CustomValidationRules.AVOID_HARDCODED_STRING);
						violationLst.add(tempViolation);
					}
				}
			}
			return violationLst;
		}
		return null;
	}

	private boolean isValidLine(String line){
		line = line.trim();
		/*if(line.startsWith("//")){
			return false;
		}
		if(line.startsWith("system.debug")){
			return false;
		}
		if(line.startsWith("/*") || line.startsWith("*")){
			return false;
		}*/
		Matcher matcher = invalidLineCheckPattern.matcher(line);
		if(matcher.find()){
			return false;
		}
		// if Line Contains a escape char
		// it's a invalid line
		/*if(line.contains(ESCAPE_CHAR)){
			return false;
		}*/
		
		return true;
	}

}
