package org.autofix.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Autofix_ExcecutorService {

	private static ExecutorService executorService = Executors.newFixedThreadPool(10);
	
	public static void submitTask(Runnable task){
		executorService.submit(task);
	}
	
	public static void shutdown(){
		if(!executorService.isShutdown())
			executorService.shutdownNow();
	}
}
