/**************************************************************************************
Class Name		: EmptyIfStmtRule
Version   		: 1.0 
Created Date	: 03 Feb 2020
Function   		: Class to fix the empty if statement violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/02/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.util.List;
import java.util.Stack;
import java.util.regex.Pattern;

import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

public class EmptyIfStmtRule implements IFRRules{

	private final static String OPEN_BRACE = "{";
	private final static String CLOSE_BRACE = "}";
	//private final static Pattern elsePattern1 = Pattern.compile(".*else.*\\{.*");
	private final static Pattern elsePattern = Pattern.compile(".*else.*");
	private final static Pattern singleLineEmptyIf = Pattern.compile(".*(if|If|IF).*\\(.*\\).*\\{.*\\}");
	private final static Pattern multiLineEmptyIf = Pattern.compile(".*(if|If|IF).*\\(.*\\).*\\{.*");

	/**
     * Method name  : doOperation
     * Description  : updates the code by removing empty if statement loops
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String pieceOfCode;
		for(Violation violation : violationLst) {
			pieceOfCode = "";
			String content = allLines.get(violation.getBeginline().intValue()-1);
			try {
				
				//Check if the empty if statement follows else block
				if(!followsElse(violation, allLines)) {
					
					//Check if the empty is statement is written in single line
					if(singleLineEmptyIf.matcher(content).matches()) {
						allLines.set(violation.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
						pieceOfCode += content + "\n";
					}
					
					//Check if the empty if statement is written in multiple lines
					else if(multiLineEmptyIf.matcher(content).matches()) {
						Integer openBraces = 0;
						Integer closeBraces = 0;
						if(content.contains(OPEN_BRACE)) {
							openBraces++;
						}
						allLines.set(violation.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
						pieceOfCode += content + "\n";
						
						//find the end of empty if statement and remove 
						for(int i=violation.getBeginline().intValue(); i<allLines.size(); i++) {
							content = allLines.get(i);
							if(content.contains(CLOSE_BRACE) && openBraces > 0) {
								allLines.set(i, AppConstants.NEED_TO_REMOVE_THIS_LINE);
								pieceOfCode += content + "\n";
								closeBraces++;
								if(openBraces == closeBraces) {
									break;
								}
							} else if(!content.contains(CLOSE_BRACE)) {
								if(content.contains(OPEN_BRACE)) {
									openBraces++;
								}
								allLines.set(i, AppConstants.NEED_TO_REMOVE_THIS_LINE);
								pieceOfCode += content + "\n";
							}
						}
					}
					Reporting.violationInfos.add(new ViolationInfo(fileName, violation.getRule(), pieceOfCode, "").toCSVRow());
				}
			} catch(Exception ex) {
				Logging.log(ex);
			}
		}
	}

	
	/**
     * Method name  : followsElse
     * Description  : checks if any if loop follows else block
     * Return Type  : void
     * Parameter    : Violation violation, List<String> codelines
     **/
	private static boolean followsElse(Violation violation, List<String> codelines) {
		Stack<String> braceStack = new Stack<String>();
		boolean followsElse = false;
		String content = "";
		try {
			for(int i=violation.getBeginline().intValue()-1; i<codelines.size(); i++) {
				content = codelines.get(i);
				for(Character eachChar : content.toCharArray()) {
					if(eachChar.toString().equals(OPEN_BRACE)) {
						braceStack.push(OPEN_BRACE);
					} else if(eachChar.toString().equals(CLOSE_BRACE)) {
						braceStack.pop();
						//Check if matches else pattern
						if(braceStack.isEmpty()) {
							if(elsePattern.matcher(content).matches() || elsePattern.matcher(codelines.get(i+1)).matches() 
									//|| elsePattern1.matcher(content).matches() || elsePattern1.matcher(codelines.get(i+1)).matches()
									) {
								followsElse = true;
							}
							return followsElse;
						}
					}
				}
			}
		} catch(Exception ex) {
			Logging.log(ex);
		}
		return followsElse;
	}
}
