package org.autofix.rules;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

public class RecordTypeInfoRule implements IFRRules{
	
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		// TODO Auto-generated method stub
		String currentLine;
		String tempRecordTypeName;
		Pattern p = Pattern.compile("'(.*?)'");
		Matcher matcher;
		ViolationInfo info;
		for(Violation v : violationLst){
			info = new ViolationInfo(fileName, v.getRule());
			currentLine = allLines.get(v.getBeginline().intValue()-1);
			info.setBeforeFix(currentLine);
			matcher = p.matcher(currentLine);
			if(matcher.find()){
				tempRecordTypeName = getRecordTypeDevName(currentLine,matcher);
				currentLine = currentLine.replace(matcher.group(1), tempRecordTypeName);
				currentLine = currentLine.replace("getRecordTypeInfosByName()", "getRecordTypeInfosByDeveloperName()");
				allLines.set(v.getBeginline().intValue()-1, currentLine);
				info.setAfterFix(currentLine);
			}
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}
	
	private String getRecordTypeDevName(String input,Matcher matcher){
		try{
			return matcher.group(1).replace(" ", "_");
		}catch(Exception e){
			System.out.println("Error occured :: "+input+" :: "+matcher.group(1));
			e.printStackTrace();
		}
		return matcher.group(1);
	}

}
