/**************************************************************************************
Class Name		:  UnusedPrivateMethodRule
Version   		: 1.0 
Created Date	: 10 Aug 2020
Function   		: Class to Comment Unused Private methodss
Example : Before Autofix : private void foo(){
          After Autofix :  /*private void foo(){
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Kundan Shaw  			        10/08/2020              Initial Version
*************************************************************************************/
package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

public class UnusedPrivateMethodRule implements IFRRules {

  
	private final static String BEFORE_COMMENT = "/* ";
	private final static String AFTER_COMMENT = " */";

  /**
     * Method name  : doOperation
     * Description  : Comment the Unused private methods.
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
  @Override
  public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) throws CustomException {
    String tempContentStart;
    String tempContentEnd;
    ViolationInfo info;
    for (Violation violation : violationLst) {
      if(allLines.get(violation.getBeginline().intValue() - 1)!=null && allLines.get(violation.getEndline().intValue() - 1)!=null){
        info = new ViolationInfo(fileName, violation.getRule());
        tempContentStart = allLines.get(violation.getBeginline().intValue() - 1);
        tempContentEnd = allLines.get(violation.getEndline().intValue() - 1);
        info.setBeforeFix(tempContentStart);
        tempContentStart = BEFORE_COMMENT + tempContentStart.trim();
        tempContentEnd = tempContentEnd + AFTER_COMMENT;
        allLines.set(violation.getBeginline().intValue() - 1, tempContentStart);
        allLines.set(violation.getEndline().intValue() - 1, tempContentEnd);
        info.setAfterFix(tempContentStart);
        Reporting.violationInfos.add(info.toCSVRow());
      }
     
    }

  }

}