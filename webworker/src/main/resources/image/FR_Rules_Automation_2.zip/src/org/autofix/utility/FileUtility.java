package org.autofix.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.autofix.main.AutoFixUtilMain;

public class FileUtility {

    public static void copyFilesToDestinaionFolder(List<String> filePathLst, String destFolder, String srcFolder) throws IOException {
        String destFilePath = "";
        for (String filePath : filePathLst) {
            try {
                destFilePath = filePath.replace(srcFolder, destFolder);
                isDirectoryExists(destFilePath);
                deleteFileIfPresent(destFilePath);
                if (AutoFixUtilMain.boolIsRunningFromAutoFixExtension) {
                    if (AutoFixUtilMain.boolRunOnFolder) {
                        copyFile(filePath, destFilePath);
                    } else {
                        copyFile(filePath, destFilePath, false);
                    }
                } else {
                    copyFile(filePath, destFilePath);
                }
            } catch (NoSuchFileException e) {
                Logging.log(e);
            }
        }
    }

    private static boolean isDirectoryExists(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            Files.createDirectories(path);
            return false;
        }
        return true;
    }

    private static void deleteFileIfPresent(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }

    }

    public static void copyFile(String from, String to) throws IOException {
        Path src = Paths.get(from);
        Path target = Paths.get(to);
        Files.copy(src, target);
    }

    public static void copyFile(String from, String to, Boolean isFolderCopy) throws IOException {
        Path src = Paths.get(from);
        Path target = Paths.get(to);
        if (isFolderCopy) {
            Files.copy(src, new File(target + File.separator + new File(from).getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
        } else {
            Files.copy(src, target);
        }
    }

    public static void deleteAllFiles(String destFolder) throws IOException {
        System.out.println("Deleting files from folder " + destFolder);
        File dir = new File(destFolder);
        File[] listFiles = dir.listFiles();
        for (File file : listFiles) {
            if (file.isDirectory()) {
                //System.out.println("DIR Deleted "+file.getAbsolutePath());
                FileUtils.deleteDirectory(file);
            } else if (file.isFile()) {
                //System.out.println("File Deleted :: "+file.getAbsolutePath());
                file.delete();
            }
        }
    }

    public static List<String> getAllApexClassFileName(String srcDir) throws IOException {
        return Files.find(Paths.get(srcDir), 999, (p, b) -> b.isRegularFile())
                .map(p -> p.toAbsolutePath().toString())
                .filter(p -> p.endsWith(".cls") || p.endsWith(".trigger"))
                .collect(Collectors.toList());
    }

    public static List<String> getAllXmlFileNames(String srcDir) throws IOException {
        return Files.find(Paths.get(srcDir), 999, (p, b) -> b.isRegularFile())
                .map(p -> p.toAbsolutePath().toString())
                .filter(p -> p.endsWith(".xml"))
                .collect(Collectors.toList());
    }

    public static List<String> getAllCssFileNames(String srcDir) throws IOException {
        return Files.find(Paths.get(srcDir), 999, (p, b) -> b.isRegularFile())
                .map(p -> p.toAbsolutePath().toString())
                .filter(p -> p.endsWith(".css"))
                .collect(Collectors.toList());
    }

    public static List<String> getAllJsFileNames(String srcDir) throws IOException {
        return Files.find(Paths.get(srcDir), 999, (p, b) -> b.isRegularFile())
                .map(p -> p.toAbsolutePath().toString())
                .filter(p -> p.endsWith(".js"))
                .collect(Collectors.toList());
    }

    /**
     * This function recursively copy all the sub folder and files from sourceFolder to destinationFolder
     */
    public static void copyFolder(File sourceFolder, File destinationFolder) throws IOException {
        //Check if sourceFolder is a directory or file
        //If sourceFolder is file; then copy the file directly to new location
        if (sourceFolder.isDirectory()) {
            //Verify if destinationFolder is already present; If not then create it
            if (!destinationFolder.exists()) {
                destinationFolder.mkdir();
            }

            //Get all files from source directory
            String files[] = sourceFolder.list();

            //Iterate over all files and copy them to destinationFolder one by one
            for (String file : files) {
                File srcFile = new File(sourceFolder, file);
                File destFile = new File(destinationFolder, file);

                //Recursive function call
                copyFolder(srcFile, destFile);
            }
        } else {
            //Copy the file content from one place to another
            Files.copy(sourceFolder.toPath(), destinationFolder.toPath(), StandardCopyOption.REPLACE_EXISTING);
            //System.out.println("File copied :: " + destinationFolder);
        }
    }


    public static void writeToFile(String content, String fileNameWithPath) {
        BufferedWriter bw = null;
        FileWriter fw = null;
        File file = new File(fileNameWithPath);
        try {
            fw = new FileWriter(file.getAbsolutePath());
            bw = new BufferedWriter(fw);
            bw.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (Exception e) {

            }
        }
    }

    public static String getFileContent(String filePath, String fileName) throws IOException {
        StringBuilder builder = new StringBuilder();
        List<String> allLines = Files.readAllLines(Paths.get(filePath, fileName));
        for (String line : allLines) {
            builder.append(line + "\n");
        }
        return builder.toString();
    }

}
