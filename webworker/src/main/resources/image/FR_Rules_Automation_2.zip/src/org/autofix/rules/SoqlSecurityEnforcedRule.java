package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
* Autofix rule file to apply accessibility checks for selected fields in SOQL query using Apex schema function
* If accessibility checks are not present for SOQL query, then they are added
* Example : Before Autofix : [SELECT Status__c FROM Contact WHERE Id=:ID];
*  		  : After Autofix : if(Schema.SObjectType.Contact.Fields.Status__c.isAccessible() { [SELECT Status__c FROM Contact WHERE Id=:ID]; }
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-08-04
*/

public class SoqlSecurityEnforcedRule implements IFRRules {
	
	/**
     * Method name  : doOperation
     * Description  : Method to check apply field accessibility checking using Apex schema function
     * Example	    : Before Autofix : [SELECT Status__c FROM Contact WHERE Id=:ID];
     *  			: After Autofix : if(Schema.SObjectType.Contact.Fields.Status__c.isAccessible() { [SELECT Status__c FROM Contact WHERE Id=:ID]; }
     * Return Type  : void
     * Parameter    : String fileName, List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		
		ViolationInfo info;
		StringBuilder startLine = new StringBuilder();
		StringBuilder endLine = new StringBuilder();
		int startLineNum = 0;
		int endLineNum = 0;
		
		for (Violation violation : violationLst) {
			
			info = new ViolationInfo(fileName, violation.getRule());
			
			startLineNum = violation.getBeginline().intValue();
			endLineNum = violation.getEndline().intValue();			

			info.setBeforeFix(startLine.toString());
			setStartLine(startLine, allLines, violation);
			
			//If entire SOQL query is on the same line, then ending "}" for function can be placed on the same line
			if(startLineNum == endLineNum) {
				processEndingSemiColon(startLine);
			}
			//If the SOQL query is not ending on the same line, then ending "}" for function needs to be placed on appropriate SOQL ending line
			else {
				endLine.append(allLines.get(violation.getEndline().intValue() - 1));
				processEndingSemiColon(endLine);
				allLines.set(violation.getEndline().intValue() - 1, endLine.toString());
			}
			
			allLines.set(violation.getBeginline().intValue() - 1, startLine.toString());
			info.setAfterFix(startLine.toString());
			
			startLine.setLength(0);
			endLine.setLength(0);
						
			Reporting.violationInfos.add(info.toCSVRow());
		}				
	}
	
	
	/**
     * Method name  : setStartLine
     * Description  : Sets the if condition checking for accessibility before the start of SOQL statement
     * Return Type  : void
     * Parameter    : StringBuilder startLine, List<String> allLines, Violation violation
     **/
	private static void setStartLine(StringBuilder startLine, List<String> allLines, Violation violation) {
		
		startLine.append(allLines.get(violation.getBeginline().intValue() - 1));
		startLine.insert(violation.getBegincolumn().intValue(), AppConstants.SPACE);
		startLine.replace(violation.getBegincolumn().intValue(), violation.getBegincolumn().intValue()+1, violation.getValue());
	}
	
	/**
     * Method name  : processEndingSemiColon
     * Description  : Sets the closed curly brace ("}") after SOQL statement end ("]") or after ";", if it exists on the line
     * Return Type  : void
     * Parameter    : StringBuilder currentLine
     **/
	private static void processEndingSemiColon(StringBuilder currentLine) {
		
		if(currentLine.indexOf(AppConstants.SEMI_COLON_CHARACTER) != -1) {
			currentLine.insert(currentLine.indexOf(AppConstants.SEMI_COLON_CHARACTER)+1, AppConstants.SPACE);				
			currentLine.replace(currentLine.indexOf(AppConstants.SEMI_COLON_CHARACTER)+1, currentLine.indexOf(AppConstants.SEMI_COLON_CHARACTER)+2, AppConstants.CLOSE_BRACES_STR);
		}
		else if(currentLine.indexOf(AppConstants.CLOSE_BRACES_STR) != -1) {
			currentLine.insert(currentLine.indexOf(AppConstants.CLOSE_BRACES_STR)+1, AppConstants.SPACE);				
			currentLine.replace(currentLine.indexOf(AppConstants.CLOSE_BRACES_STR)+1, currentLine.indexOf(AppConstants.CLOSE_BRACES_STR)+2, AppConstants.CLOSE_BRACES_STR);
		}
		else {
			currentLine.insert(currentLine.indexOf(AppConstants.CLOSE_RECT_BRACE)+1, AppConstants.SPACE);				
			currentLine.replace(currentLine.indexOf(AppConstants.CLOSE_RECT_BRACE)+1, currentLine.indexOf(AppConstants.CLOSE_RECT_BRACE)+2, AppConstants.CLOSE_BRACES_STR);
		}
		
	}

}