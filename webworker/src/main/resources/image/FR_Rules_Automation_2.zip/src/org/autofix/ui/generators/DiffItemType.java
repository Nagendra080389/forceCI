package org.autofix.ui.generators;

public enum DiffItemType {
    EQUAL,
    INSERT,
    DELETE
}
