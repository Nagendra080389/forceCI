package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Below class is the rule for all Alert Statements to be removed from JS validation
 * @author Manuraj
 * @version 1.0
 * @modified 2020-08-10
 */
public class RemoveAlertFromJsValidation implements IValidation {
	
	private final static String CHECK_PATTERN = "^alert\\(.*\\);$";

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		Violation tempViolation;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				violationLst = new ArrayList<>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));

				for (int i = 0; i < lstLines.size(); i++) {
					tempViolation = checkForViolation(lstLines.get(i), i + 1);
					if (tempViolation != null) {
						violationLst.add(tempViolation);
					}
				}
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	private Violation checkForViolation(String line, int lineNumber) {
		String afterRemove = null;
		if(line!=null) {
			afterRemove=removeWhite(line);
		}
		
		if (line != null && Pattern.matches(CHECK_PATTERN, afterRemove)) {
			Violation v = new Violation();
			v.setBeginline(BigInteger.valueOf(lineNumber));
			v.setRule(CustomValidationRules.REMOVE_ALERT_JS);
			return v;
		}
		return null;
	}
	public static String removeWhite(String s) { 
	      
        // Creating a pattern for whitespaces 
        Pattern patt = Pattern.compile("[\\s]"); 
  
        // Searching patt in s. 
        Matcher mat = patt.matcher(s); 
  
        // Replacing 
        return mat.replaceAll(""); 
   } 

}
