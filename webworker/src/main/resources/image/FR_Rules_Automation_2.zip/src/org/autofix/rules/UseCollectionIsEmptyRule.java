/**************************************************************************************
Class Name		: UseCollectionIsEmptyRule
Version   		: 1.0 
Created Date	: 05 Apr 2020
Function   		: Class to fix isEmpty method instead of size() method violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Nikhil Kumar			05/04/2020              Initial Version
*************************************************************************************/
package org.autofix.rules;

import java.math.BigInteger;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

public class UseCollectionIsEmptyRule implements IFRRules{
	private static String notEqualsRegex = "(\\.size\\(\\)( *)!=)( *)0"; //Regex to check for .size()!=0
	Pattern notEqualsPattern = Pattern.compile(notEqualsRegex);
	private static String isEmpty = "isEmpty()";
	private static String notOperator = "!";
	private static String openingParanthesis = "(";
	private static String sizeMethod = "size()";
	private Comparator<Violation> violationComparator = (v1,v2)->v1.getBegincolumn().compareTo(v2.getBegincolumn());

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String lineWithViolation, violatedText, sizeReplacedWithIsEmpty;
		StringBuilder updatedLine;
		int nextIndex, indexOfSize;
		Matcher notEqualsMatcher;
		Map<BigInteger, List<Violation>> violationMap = violationLst
				.stream()
				.collect(Collectors.groupingBy(Violation::getBeginline));
		ViolationInfo info = null;
		
		for(BigInteger beginLine : violationMap.keySet()){
			lineWithViolation = allLines.get(beginLine.intValue());
			violationMap.get(beginLine).sort(violationComparator);
			nextIndex=0;
			updatedLine = new StringBuilder();
			for(Violation v : violationMap.get(beginLine)){
				try{
					info = new ViolationInfo(fileName, v.getRule());
					info.setBeforeFix(lineWithViolation);
					violatedText = lineWithViolation.substring(v.getBegincolumn().intValue(), v.getEndcolumn().intValue());
					indexOfSize = violatedText.toLowerCase().indexOf(sizeMethod);
					notEqualsMatcher = notEqualsPattern.matcher(violatedText.toLowerCase());
					sizeReplacedWithIsEmpty = replaceSizeWithIsEmpty(notEqualsMatcher, violatedText, indexOfSize);
					updatedLine.append(lineWithViolation.substring(nextIndex, v.getBegincolumn().intValue())+sizeReplacedWithIsEmpty);
					//Updating index to violation end column
					nextIndex = v.getEndcolumn().intValue();
				}
				catch(Exception ex){
					Logging.log("error occured on file :: "+fileName+" for rule :: "+v.getRule(),ex);
				}
				
			}
			updatedLine.append(lineWithViolation.substring(nextIndex));
			allLines.set(beginLine.intValue(), updatedLine.toString());
			info.setAfterFix(updatedLine.toString());
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}
	
	/**
	 * Method name : replaceSizeWithIsEmpty
	 * This function accepts a matcher, and a String having size method with equals or not equals
	 * comparison to zero and Replaces size method with isEmpty
	 * @param notEqualsMatcher 
	 * @param textWithSizeMethod
	 * @param indexOfSize 
	 * @return sizeReplacedByIsEmpty 
	 */
	public String replaceSizeWithIsEmpty(Matcher notEqualsMatcher, String textWithSizeMethod, int indexOfSize){
		String sizeReplacedByIsEmpty; //To be returned by this function
		if(notEqualsMatcher.find()){
			//If size()!=0 found, form the String with !isEmpty
			if(textWithSizeMethod.substring(0,indexOfSize).contains(openingParanthesis)){
				int indexOfOpeningP = textWithSizeMethod.substring(0,indexOfSize).indexOf(openingParanthesis);
				sizeReplacedByIsEmpty = textWithSizeMethod.substring(0,indexOfOpeningP+1)
						+ notOperator + textWithSizeMethod.substring(indexOfOpeningP+1,indexOfSize)
						+ isEmpty + textWithSizeMethod.substring(notEqualsMatcher.end());	
			}
			else{
				sizeReplacedByIsEmpty = notOperator + textWithSizeMethod.substring(0,indexOfSize)
				+ isEmpty + textWithSizeMethod.substring(notEqualsMatcher.end());
			}
		}
		else{
			//If size()==0 found, form the String with isEmpty
			sizeReplacedByIsEmpty = textWithSizeMethod.substring(0,indexOfSize) + isEmpty;
		}
		//Return string having isEmpty() instead of size()
		return sizeReplacedByIsEmpty;
	}
}
