/**************************************************************************************
Class Name		:  SoqlStmtValidation
Version   		: 1.0 
Created Date	: 05 May 2020
Function   		: Class to spot the SOQL statements without where or limit clause
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			05/05/2020              Initial Version
*************************************************************************************/

package org.autofix.validation;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

public class SoqlStmtValidation implements IValidation {
	
	private final static String RECT_OPEN_BRACE = "[";
	private final static String RECT_CLOSE_BRACE = "]";
	private final static String LITERAL_ISTEST = "@ISTEST";
	private final static String LITERAL_CLASS = "CLASS";
	private final static String LITERAL_SELECT = "SELECT";
	private final static int INDEX_ZERO = 0;
	private final static Pattern databaseQuery = Pattern.compile("(.*)database.query(.*)");
	private final static Pattern soqlWherePattern = Pattern.compile("(.*)where(.*)");
	private final static Pattern soqlLimitPattern = Pattern.compile("(.*)limit(.*)");
	private final static Pattern singleLineDatabaseQuery = Pattern.compile("(.*)database.query\\((.*)\\'(.*)select(.*)\\'(.*)\\)(.*);(.*)");
	
	/**
     * Method name  : runValidation
     * Description  : runs the SOQL query validations and returns files with violations if any
     * Return Type  : List<File>
     * Parameter    : List<String> fileNameLst
     **/
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<Violation> violations;
		List<String> queries;
		String queryParams;
		List<File> lstFiles = new ArrayList<File>();
		List<String> pieceOfCode = new ArrayList<String>();
		List<String> lstLines = new ArrayList<String>();
		boolean moveForward = false;
		int lineNum = 0;
		int beginline = 0;
		
		
		for(String filePath : fileNameLst) {
			try {
				lineNum = 0;
				lstLines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
				
				//Skip violation check if it is a test class
				if(!isTestClass(lstLines)) {
					violations = new ArrayList<Violation>();
					queries = new ArrayList<String>();
					for(String codeline : lstLines) {
						lineNum++;
						// if SOQL is written in single line
						if(containsSoql(codeline) && codeline.contains(RECT_CLOSE_BRACE)) {
							pieceOfCode.add(codeline);
							beginline = lineNum;
							if(!contaisWhereClause(pieceOfCode) && isValidSoql(pieceOfCode)) {
								violations.add(prepareViolation(pieceOfCode, beginline, lineNum));							
							}
							pieceOfCode.clear();
						}
						
						// if SOQL is written in multiple lines
						else if(moveForward) {
							pieceOfCode.add(codeline);
							if(codeline.contains(RECT_CLOSE_BRACE)) {
								moveForward = false;
								if(!contaisWhereClause(pieceOfCode) && isValidSoql(pieceOfCode)) {
									violations.add(prepareViolation(pieceOfCode, beginline, lineNum));								
								}
								pieceOfCode.clear();
							}
						} else if(containsSoql(codeline) && !codeline.contains(RECT_CLOSE_BRACE)) {
							pieceOfCode.add(codeline);
							beginline = lineNum;
							moveForward = true;
						} 
						
						//if SOQL is written as string and fired using Database.query(argument);
						else if(databaseQuery.matcher(codeline.toLowerCase()).matches()) {
							if(codeline.toLowerCase().lastIndexOf(")") > INDEX_ZERO) {
								queryParams = codeline.substring(codeline.toLowerCase().indexOf("database.query(")+15, 
										codeline.toLowerCase().lastIndexOf(")"));
								queries.add(queryParams.split(",")[INDEX_ZERO]);
							}
							
						}
						
					}
					//if SOQL is written as string and fired using Database.query(argument) exists
					if(!queries.isEmpty()) {
						addDatabaseVioaltions(queries, violations, lstLines);
					}
					//File processing completed, now adding violations to the file
					if (!violations.isEmpty()) {
						lstFiles.add(getFile(filePath, violations));
					}
				}
			} catch(Exception e) {
				Logging.log(e);
			}
			
		}
		
		return lstFiles;
	}
	
	
	/**
     * Method name  : containsSoql
     * Description  : returns if the given code line contains any SOQL
     * Return Type  : Boolean
     * Parameter    : String codeLine
     **/
	private static Boolean containsSoql(String codeLine) {
		if(codeLine.contains(RECT_OPEN_BRACE)) {
			return true;
		} else {
			return false;
		}
	}
	
	
	/**
     * Method name  : contaisWhereClause
     * Description  : returns if the given piece of code contains WHERE or LIMIT clause
     * Return Type  : Boolean
     * Parameter    : List<String> pieceOfCode
     **/
	private static Boolean contaisWhereClause(List<String> pieceOfCode) {
		for(String codeLine : pieceOfCode) {
			//if(codeLine.toUpperCase().contains(WHERE_CLAUSE) || codeLine.toUpperCase().contains(LIMIT_CLAUSE)) {
			//	return true;
			//}
			if(soqlWherePattern.matcher(codeLine.toLowerCase()).matches() || soqlLimitPattern.matcher(codeLine.toLowerCase()).matches()) {
				return true;
			}
		}
		return false;
	}
	
	
	/**
     * Method name  : getBeginColumnIndex
     * Description  : returns the start column index of SOQL query
     * Return Type  : Integer
     * Parameter    : List<String> pieceOfCode
     **/
	private static Integer getBeginColumnIndex(List<String> pieceOfCode) {
		for(String codeLine : pieceOfCode) {
			if(codeLine.contains(RECT_OPEN_BRACE)) {
				return codeLine.indexOf(RECT_OPEN_BRACE);
			} else if(codeLine.toUpperCase().contains(LITERAL_SELECT)) {
				return codeLine.toUpperCase().indexOf(LITERAL_SELECT);
			}
		}
		return -1;
	}
	
	
	/**
     * Method name  : getEndColumnIndex
     * Description  : returns the end column index of SOQL query
     * Return Type  : Integer
     * Parameter    : List<String> pieceOfCode
     **/
	private static Integer getEndColumnIndex(List<String> pieceOfCode) {
		for(String codeLine : pieceOfCode) {
			if(codeLine.contains(RECT_CLOSE_BRACE)) {
				return codeLine.indexOf(RECT_CLOSE_BRACE);
			} else if(codeLine.contains(";")) {
				return codeLine.lastIndexOf("'")>0 ? codeLine.lastIndexOf("'") : codeLine.indexOf(";")-1;
			}
		}
		return -1;
	}
	
	
	/**
     * Method name  : prepareViolation
     * Description  : prepares violation data within the given piece of code
     * Return Type  : Violation
     * Parameter    : List<String> pieceOfCode, int beginLine, int endLine
     **/
	private static Violation prepareViolation(List<String> pieceOfCode, int beginLine, int endLine) {
		Violation violation = new Violation();
		violation.setValue(ValidationRules.CustomValidationRules.SOQL_STMT_VALIDATION);
		violation.setBeginline(BigInteger.valueOf(beginLine));
		violation.setBegincolumn(BigInteger.valueOf(getBeginColumnIndex(pieceOfCode)));
		violation.setEndline(BigInteger.valueOf(endLine));
		violation.setEndcolumn(BigInteger.valueOf(getEndColumnIndex(pieceOfCode)));
		violation.setRule("SoqlStmtViolation");
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		return violation;	
	}
	
	
	/**
     * Method name  : getFile
     * Description  : returns file after adding listed violations
     * Return Type  : File
     * Parameter    : String filePath, List<Violation> lstViolation
     **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;	
	}
	
	/**
     * Method name  : isValidSoql
     * Description  : returns if the piece of code contains a valid soql
     * Return Type  : File
     * Parameter    : List<Violation> lstViolation
     **/
	private static boolean isValidSoql(List<String> pieceOfCode) {
		String actualCodeline = "";
		for(String codeline : pieceOfCode) {
			if(codeline.indexOf(RECT_OPEN_BRACE) > 0 &&  codeline.indexOf(RECT_CLOSE_BRACE) > 0) {
				actualCodeline += codeline.substring(codeline.indexOf(RECT_OPEN_BRACE)+1, codeline.indexOf(RECT_CLOSE_BRACE)).trim();
			} else if(codeline.indexOf(RECT_OPEN_BRACE) > 0) {
				actualCodeline += codeline.substring(codeline.indexOf(RECT_OPEN_BRACE)+1, codeline.length()-1).trim();
			} else if(codeline.indexOf(RECT_CLOSE_BRACE) > 0) {
				actualCodeline += codeline.substring(0, codeline.indexOf(RECT_CLOSE_BRACE)).trim();
			} else {
				actualCodeline += codeline;
			}
		}
		if(actualCodeline.length() > 0) {
			if(actualCodeline.toLowerCase().contains("select") && actualCodeline.toLowerCase().contains("from")) {
				return true;
			}
		}
		return false;
	}
	
	
	/**
     * Method name  : addDatabaseVioaltions
     * Description  : adds database query violations if any
     * Return Type  : viod
     * Parameter    : List<String> queries, List<Violation> violations, List<String> codelines
     **/
	public static void addDatabaseVioaltions(List<String> queries, List<Violation> violations, List<String> codelines) {
		boolean queryContext = false;
		int linenum = 0;
		int beginline = 0;
		int endline = 0;
		List<String> pieceOfCode = new ArrayList<String>();
		for(String query : queries) {
			linenum = 0;
			for(String codeline : codelines) {
				linenum++;
				if(codeline.contains(query) || queryContext) {
					//If the query string is written in single line
					//if(codeline.contains("'") && codeline.contains(";") && codeline.toUpperCase().contains(LITERAL_SELECT)) {
					if(singleLineDatabaseQuery.matcher(codeline.toLowerCase()).matches()) {
						beginline = linenum; endline = linenum;
						pieceOfCode.add(codeline);
						if(isValidSoql(pieceOfCode) && !contaisWhereClause(pieceOfCode)) {
							violations.add(prepareViolation(pieceOfCode, beginline, endline));
						}
						pieceOfCode.clear();
					}
					//If the query string is written in multiple lines
					else if(queryContext) {
						if(codeline.contains(";")) {
							queryContext = false;
							endline = linenum;
							pieceOfCode.add(codeline);
							if(isValidSoql(pieceOfCode) && !contaisWhereClause(pieceOfCode)) {
								violations.add(prepareViolation(pieceOfCode, beginline, endline));
							}
							pieceOfCode.clear();
						} else {
							pieceOfCode.add(codeline);
						}
					} 
					else if(codeline.contains("'") && !codeline.contains(";")) {
						beginline = linenum;
						pieceOfCode.add(codeline);
						queryContext = true;
					}
				}
			}
			
		}
	}
	
	
	/**
     * Method name  : isTestClass
     * Description  : returns if the file to be processed is a test class
     * Return Type  : Boolean
     * Parameter    : List<String> codelines
     **/
	private static Boolean isTestClass(List<String> codelines) {
		for(String codeline : codelines) {
			if(codeline.toUpperCase().contains(LITERAL_ISTEST)) {
				return true;
			} else if(codeline.toUpperCase().contains(LITERAL_CLASS)) {
				return false;
			}
		}
		return false;
	}

}
