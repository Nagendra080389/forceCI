package org.autofix.validation;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * This class return the list of files 
 * having 'Perform ISNULL before DML Operation.' violation along with Violation details  
 *  *  Example: - Before fix : Insert accList;
 *							Database.insert(accList);
 *							Database.insert(accList,true);
 *
 *            After fix : if(!accList.isEmpty){
 *                            insert accList;
 *                            Database.insert(accList);
 *                            Database.insert(accList,true);
 *                            }
 * @author ruchkumari
 *
 */
public class NullCheckForDMLValidation implements IValidation {
	//private static final  String DATABASE_QUERY_PATTERN = "[\\s\\r\\n]*[a-zA-z0-9\\;\\r\\n\\s\\(\\)\\,\\=\\[\\]\\.\\<\\>]*[Database.]*(insert|update|upsert|delete|undelete|merge)+[\\s]*[a-zA-z0-9;\\r\\n\\s\\(\\)\\,\\=]+";
	private static final  String DATABASE_QUERY_PATTERN = "[\\s\\r\\n]*[a-zA-z0-9\\;\\r\\n\\s\\(\\)\\,\\=\\[\\]\\.\\<\\>]*((insert|update|upsert|delete|undelete|merge)[\\s]*[a-zA-z0-9]*;)|(Database.(insert|update|upsert|delete|undelete|merge)[\\s]*[a-zA-z0-9;\\r\\n\\s\\(\\)\\,\\=]+;)";
	private static final  String IF_PATTERN = "if";
	private static final  String DATABASE_VARIABLE_PATTERN = "[\\s]*[Database.]+(insert|update|upsert|delete|undelete|merge)+[\\s]*[\\)\\r\\n\\s\\(\\,\\;]+";
	private static final  String WHITESPACE_PATTERN = "[\\s]+";
	private static final  String IF_CHECK_PATTERN = "(if|null|size()|length|isempty|\\.|\\!|\\=|\\(|\\)|\\{|\\}|\\&|\\|)*";
	private static final  String GRT_LESS_OPERATOR = "[<|>]+[0-9]+";
	private static final  String DATABASE_PATTERN = "database";
	private static final  String CURLY_BRACKET_PATTERN = "{";
	private static final  String BOOLEAN_OPERATOR= "(true|false|FALSE|TRUE)$";
	private static final  String SEMICOLON_COMMA = "[\\;|\\,|\\)\\s]*";
	private static final  String COMMA = "[\\s]*[\\,]+[\\s]*";
	private static Pattern databaseQueryPattern = Pattern.compile(DATABASE_QUERY_PATTERN);
	private static final Pattern FIRST_CHARACTER_PATTERN = Pattern.compile("\\w+", Pattern.CASE_INSENSITIVE);
	private static final Pattern DATABASEQUERY = Pattern.compile("[a-zA-z0-9\\;\\(\\)\\,\\=\\[\\]\\.\\<\\>]*[Database.]*(insert|update|upsert|delete|undelete|merge)+[\\s]*[a-zA-z0-9\\(\\)\\,\\=]+", Pattern.CASE_INSENSITIVE);

	/* (non-Javadoc)
	 * @see org.fpr.validation.IValidation#runValidation(java.util.List)
	 * scan the list of files to find out DML operation before which 
	 * null check is not performed .  
	 * returns file after adding listed violations
	 */
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<>();
		List<Violation> violations;
		List<String> lstLines = new ArrayList<>();
		boolean moveForward = false;
		int lineNum = 0;
		Map<String,int[]> varAndLine ;
		int[] ifLoopLineNumber = new int[2];
		try {	
			for(String filePath : fileNameLst) {
				violations = new ArrayList<>();
				varAndLine = new HashMap<>();
				lineNum = 0;
				lstLines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
				Stack<Character> stack = new Stack<>();
				for(String codeline : lstLines) {
					lineNum++; 
					if(codeline.toLowerCase().contains(IF_PATTERN) 
							&& (codeline.toLowerCase().contains("isempty") ||codeline.toLowerCase().contains("null")
									||codeline.toLowerCase().contains("size"))) {
						if(codeline.toLowerCase().contains("!") && (codeline.toLowerCase().contains("isempty") ||codeline.toLowerCase().contains("null"))) {	

							Set<String> varName =  getVariableNameFormIf(codeline);
							for(String name : varName) {
								varAndLine.put(name, ifLoopLineNumber);
							}
						}
						else if(codeline.toLowerCase().contains("size") || codeline.toLowerCase().contains("length")  ){
							Set<String> varName =  getVariableNameFormIf(codeline);
							for(String name : varName) {
								varAndLine.put(name, ifLoopLineNumber);
							}
						}
						if(!moveForward) {
							ifLoopLineNumber[0]= lineNum;
						}
						moveForward = true;
					}

					// run for all line of code present inside if loop
					if(moveForward) {
						ifLoopLineNumber[1]= lineNum;
						if(isIfStatmentLastLine(codeline,stack)){
							// when '{' is in next line of IF statment 
							if(codeline.toLowerCase().contains(IF_PATTERN) && !codeline.contains(CURLY_BRACKET_PATTERN)) {
								moveForward = true;	
							}else {
								moveForward = false;	
								stack.clear();
							}
						}
					}
					if(databaseQueryPattern.matcher(codeline).matches()) {
						Violation tempViolation;
						Matcher databaseQueryPatternMatcher = databaseQueryPattern.matcher(codeline);
						List<String> varName = getVariableFromDML(codeline);
						if(!dmlPresentInsideIfLoop(lineNum,varAndLine,varName)) {	
							if(!moveForward) {
								varAndLine.clear();
								ifLoopLineNumber= new int[2];
							}
							if(databaseQueryPatternMatcher.find()) {
								tempViolation = new Violation();
								Matcher firstCharacterMatcher = DATABASEQUERY.matcher(codeline);
								if(firstCharacterMatcher.find()) {
									tempViolation.setBegincolumn(BigInteger.valueOf(firstCharacterMatcher.start()));
								}
								tempViolation.setBeginline(BigInteger.valueOf(lineNum));
								//tempViolation.setBegincolumn(BigInteger.valueOf(databaseQueryPatternMatcher.start()));
								tempViolation.setEndcolumn(BigInteger.valueOf(codeline.length()));
								tempViolation.setEndline(BigInteger.valueOf(lineNum));
								tempViolation.setRule(CustomValidationRules.NULL_CHECK_BEFORE_DML);
								tempViolation.setRuleset("Code Style");
								tempViolation.setPriority("3");
								violations.add(tempViolation);							
							}
						}
					}
				}
				if (!violations.isEmpty()) {
					lstFiles.add(getFile(filePath, violations));
				}

			}
		}catch(Exception e) {
			e.printStackTrace();
			Logging.log(e.getMessage());
		}
		return lstFiles;
	}


	/**
	 * This method gets the variable name from DML operation
	 * @param tempContent
	 * @return
	 */
	private List<String> getVariableFromDML(String tempContent) {
		String dmlCodeLine = tempContent.trim();
		String dmlVarLine ;
		List<String> name =new ArrayList<>();
		// dml statement having structure like Database.MergeResult[] results1 = merge AccToUpsert AddressToUpsert;
		if(tempContent.contains("=")) {  
			String[] dmlLine = tempContent.split("=");
			if(dmlLine.length==2) {
				dmlCodeLine = dmlLine[1].trim();
			}
		}
		// dml statement having structure like Databse.*
		if(dmlCodeLine.contains("Database") && !dmlCodeLine.contains("merge")) { 
			StringBuilder varName = new StringBuilder(dmlCodeLine);
			varName = replaceAll(varName,DATABASE_VARIABLE_PATTERN,"");
			varName = replaceAll(varName,SEMICOLON_COMMA,"");
			varName = replaceAll(varName,BOOLEAN_OPERATOR,"");
			name.add(varName.toString());				
		}else if(dmlCodeLine.contains("Database") && dmlCodeLine.contains("merge")) {
			String[] mergeDmlStmtVar = dmlCodeLine.split(COMMA);
			for(String mergeVarName : mergeDmlStmtVar) {
				StringBuilder varName = new StringBuilder(mergeVarName);
				varName = replaceAll(varName,DATABASE_VARIABLE_PATTERN,"");
				varName = replaceAll(varName,SEMICOLON_COMMA,"");
				varName = replaceAll(varName,BOOLEAN_OPERATOR,"");
				name.add(varName.toString());	
			}
		}
		// dml having structure like insert/update... acct
		else {
			String[] varName = dmlCodeLine.split(WHITESPACE_PATTERN);	
			String dmlStmtVarName ="";
			if(varName.length==2) {
				dmlStmtVarName = varName[1].replace(";", "");
				name.add(dmlStmtVarName);	
			}
			// when dml having structure like 'merge AccToUpsert AddressToUpsert;'
			if(varName.length>=3 ) {
				if(varName[1].equals(varName[2])) {  // when both variable name is equal eg : merge AccToUpsert AccToUpsert;
					dmlStmtVarName = varName[1].replace(";", "");
					name.add(dmlStmtVarName);	
				}else {
					String firstVarName = varName[1].replace(";", "");
					String secondVarName = varName[2].replace(";", "");
					name.add(firstVarName);	
					name.add(secondVarName);	
				}				
			}

		}
		return name;
	}

	private StringBuilder replaceAll(StringBuilder varName, String regex, String replacment)
	{
		Pattern pattern = Pattern.compile(regex);		
		Matcher matcher = pattern.matcher(varName);
		varName = varName.replace(0, varName.length(), matcher.replaceAll(replacment));		
		return varName;    
	}
	/**
	 * This method find the variable present in the IF Statement
	 * @param codeline
	 * @return Set<String>
	 */
	private Set<String> getVariableNameFormIf(String codeline) {
		Set<String> finalVarName = new HashSet<>();
		String line = codeline.toLowerCase();
		line = line.replaceAll(IF_CHECK_PATTERN, ""); 
		line = line.replaceAll(GRT_LESS_OPERATOR, "");
		String[] ifStatmentCode = line.trim().split(WHITESPACE_PATTERN);
		for(int i =0;i<ifStatmentCode.length;i++) {
			finalVarName.add(ifStatmentCode[i]);

		}
		return finalVarName;
	}

	/**
	 * Check if the line is the last line for IF Statment
	 * @param codeline
	 * @param stack
	 * @return boolean
	 */
	private boolean isIfStatmentLastLine(String codeline, Stack<Character> stack) {
		List<Character> leftKey = Arrays.asList('{');
		List<Character> rightKey = Arrays.asList('}');
		String line = codeline;
		for(int i =0 ;i< line.length();i++) {
			char c = line.charAt(i);
			if(leftKey.contains(c)) {
				stack.push(c);
			}
			else if(rightKey.contains(c)) {
				int index = rightKey.indexOf(c);
				if(stack.isEmpty() || stack.pop()!=leftKey.get(index)) {
					return false;
				}
			}
		}
		return stack.isEmpty();
	}

	/**This method check if the DML statement is present inside if Statement
	 * @param lineNum
	 * @param varAndLine
	 * @param varName
	 * @return boolean
	 */
	private boolean dmlPresentInsideIfLoop(int lineNum, Map<String, int[]> varAndLine, List<String> varName) {
		int ifLoopBeginLine = 0;
		int ifLoopEndLine = 0;
		String name = "";
		int count = 0;
		if(!varAndLine.isEmpty()) {
			for(Map.Entry<String, int[]> entry : varAndLine.entrySet() ) {
				ifLoopBeginLine = entry.getValue()[0];
				ifLoopEndLine = entry.getValue()[1];
				name = entry.getKey();
				if(ifLoopBeginLine!=0 && ifLoopEndLine!=0 
						&& (lineNum>=ifLoopBeginLine && lineNum<=ifLoopEndLine )) {
					if(varName.size()==1 && varName.get(0).equalsIgnoreCase(name)) {
						return true;
					}else if(varName.size()>1){
						for(String ifStmtVarName :varName ) {
							if(ifStmtVarName.equalsIgnoreCase(name)) {
								count++;
							}
						}
						if(count==2) {
							return true;
						}
					}

				}
			}
		}
		return false;
	}

	/**
	 * Method name  : getFile
	 * Description  : returns file after adding listed violations
	 * Return Type  : File
	 * Parameter    : String filePath, List<Violation> lstViolation
	 **/
	private File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;	
	}
}
