package org.autofix.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import net.sourceforge.pmd.ruleset._2_0.Ruleset;

public class AppUtility {

	private static ObjectMapper mapper;

	@SuppressWarnings("unchecked")
	public static <T> T getObject(String fileNameWithPath, Class<T> className) throws JAXBException{
		File file = new File(fileNameWithPath);
		JAXBContext jaxbContext = JAXBContext.newInstance(className);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
		return (T) jaxbUnmarshaller.unmarshal(file);
	}

	public static <T> void writeXmlToFileFromObject(Object obj, Class<T> className, String fileNameWithPath) throws JAXBException, FileNotFoundException{
		JAXBContext contextObj = JAXBContext.newInstance(Ruleset.class);
		Marshaller marshallerObj = contextObj.createMarshaller();
		marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		FileOutputStream fileOutputStream = new FileOutputStream(fileNameWithPath);
		marshallerObj.marshal(obj,fileOutputStream);
		try {
			fileOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static List<Integer> getAllIndex(String input, char inputChar){
		List<Integer> outLst = new ArrayList<>();
		int strLen = input.length();
		int currentIndex = 0;
		while(currentIndex < strLen){
			currentIndex = input.indexOf(inputChar,currentIndex);
			if(currentIndex == -1){
				break;
			}
			outLst.add(currentIndex);
			currentIndex++;
		}
		return outLst;
	}

	public static String getFormattedJson(Object obj, Class<?> className) throws JsonParseException, JsonMappingException, JsonGenerationException, IOException{
		if(mapper == null){
			mapper = new ObjectMapper();
		}
		Object jsonObject = mapper.readValue(mapper.writeValueAsString(obj), className);
		return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObject);
	}

	public static void removeIndexFromList(List<Integer> indexLst, List<? extends Object> inputLst){
		if(indexLst != null && indexLst.size() > 0){
			Collections.sort(indexLst, (a,b)->b.compareTo(a));
			for(Integer index : indexLst){
				inputLst.remove(index.intValue());
			}
		}
	}
	
	public static List<String> splitToNChar(String text, int size) {
        List<String> parts = new ArrayList<>();
        int length = text.length();
        for (int i = 0; i < length; i += size) {
            parts.add(text.substring(i, Math.min(length, i + size)));
        }
        return parts;
    }
	
	public static boolean isNull(Object obj){
		if(obj == null)
			return true;
		return false;
	}

	public static boolean isNotNull(Object obj){
		return !isNull(obj);
	}
	
	public static boolean isNotNullOrBlank(Collection<?> collection){
		if(collection != null && !collection.isEmpty()){
			return true;
		}
		return false;
	}
	
	public static class StringUtility{
		public static boolean isNotNullOrBlank(String input){
			if(input != null && input.length()>0){
				return true;
			}
			return false;
		}
	}

}
