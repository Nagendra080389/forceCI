/**************************************************************************************
Class Name		: ViolationInfo
Version   		: 1.0 
Created Date	: 6 June 2020
Function   		: Class to carry violation information like piece of code before fix, after fix, file name etc
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			06/06/2020              Initial Version
*************************************************************************************/

package org.autofix.model;

import java.io.Serializable;
import java.util.Comparator;

public class ViolationInfo implements Serializable, Comparable<ViolationInfo> {
	
	private static final long serialVersionUID = 1L;
	private String fileName;
	private String ruleName;
	private String beforeFix;
	private String afterFix;
	
	public ViolationInfo() {
		this.fileName = "";
		this.ruleName = "";
		this.beforeFix = "";
		this.afterFix = "";
	}

	public ViolationInfo(String fileName, String ruleName) {
		super();
		this.fileName = fileName;
		this.ruleName = ruleName;
	}

	public ViolationInfo(String fileName, String ruleName, String beforeFix, String afterFix) {
		super();
		this.fileName = fileName;
		this.ruleName = ruleName;
		this.beforeFix = beforeFix;
		this.afterFix = afterFix;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getBeforeFix() {
		return beforeFix;
	}

	public void setBeforeFix(String beforeFix) {
		this.beforeFix = beforeFix;
	}

	public String getAfterFix() {
		return afterFix;
	}

	public void setAfterFix(String afterFix) {
		this.afterFix = afterFix;
	}
	
	public String[] toCSVRow() {
		String[] toCSVRow = { this.fileName, this.ruleName, this.beforeFix, this.afterFix };
		return toCSVRow;
	}
	
	public static final Comparator<String[]> CompareByFileName = new Comparator<String[]>() {

        @Override
        public int compare(String[] info1, String[] info2) {
            return info1[0].compareTo(info2[0]);
        }
      
    };
    
    public static final Comparator<String[]> CompareByRuleName = new Comparator<String[]>() {

        @Override
        public int compare(String[] info1, String[] info2) {
            return info1[1].compareTo(info2[1]);
        }
      
    };
    
	@Override
	public int compareTo(ViolationInfo vi) {
		String[] info = vi.toCSVRow();
		return this.fileName.compareTo(info[0]);
	}

}
