package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
* Autofix rule file to remove unused import statements in Javascript files.
* If unused import statements are found, then flag "NEED TO REMOVE THIS LINE" is associated with the line and later,
* the line is removed by the code formatter.
* Example : Before Autofix : import { Component } from test;
*  		  : After Autofix : Line is removed if not used in the Javascript file
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-08-07
*/

public class RemoveUnnecessaryImportsRule implements IFRRules {
	
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		String currentLine;
		ViolationInfo info;
		for (Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			currentLine = allLines.get(violation.getBeginline().intValue()-1);
			info.setBeforeFix(currentLine);
			
			if(AppConstants.NEED_TO_REMOVE_THIS_LINE.equalsIgnoreCase(violation.getValue())) {
				allLines.set(violation.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
			}
			else {
				allLines.set(violation.getBeginline().intValue()-1, violation.getValue());
			}
			
			info.setAfterFix(currentLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}