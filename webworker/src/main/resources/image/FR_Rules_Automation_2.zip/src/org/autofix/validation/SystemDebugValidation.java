/**************************************************************************************
Class Name		: SystemDebugValidation
Version   		: 1.0 
Created Date	: 03 Feb 2020
Function   		: Class to spot the debug statement violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/02/2020              Initial Version
*************************************************************************************/

package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Pattern;

import org.autofix.common.AutofixValidationRules;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.main.AutoFixUtilMain;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

public class SystemDebugValidation implements IValidation{

	private final Pattern singleLineDebug = Pattern.compile("(.*)SYSTEM.DEBUG(.*)\\((.*)\\)(.*);(.*)");
	private final Pattern multiLineDebugStart = Pattern.compile("(.*)SYSTEM.DEBUG(.*)\\((.*)");
	private final Pattern multiLineDebugEnd = Pattern.compile("(.*)\\)(.*);(.*)");
	private static final String DEBUG_FOUND_VIOLATION = "Avoid using debug statements.";
	private static final String DEBUG = "SYSTEM.DEBUG";
	private static final String QUOTE = "'";
	private static final String SEMICOLON = ";";
	
	
	/**
     * Method name  : runValidation
     * Description  : runs the validation the given list of files and returns files with vilations
     * Return Type  : List<File>
     * Parameter    : List<String> fileNameLst
     **/
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<File>();
		List<Violation> lstViolation = null;
		List<String> lstLines = new ArrayList<String>();
		List<String> pieceOfCode = new ArrayList<String>();
		boolean debugContext = false;
		int lineNo;
		for (String filePath : fileNameLst) {
			try {
				lineNo = 1;
				lstViolation = new ArrayList<Violation>();
				lstLines = Files.readAllLines(Paths.get(filePath));
				for (String strLine : lstLines) {
					//Debug statment written in single line
					if (singleLineDebug.matcher(strLine.toUpperCase()).matches()) {
						pieceOfCode.add(strLine);
						lstViolation.add(getViolation(pieceOfCode, lineNo));
						pieceOfCode.clear();
					} 
					
					//Debug statement written in multiple lines
					else if(multiLineDebugStart.matcher(strLine.toUpperCase()).matches()) {
						pieceOfCode.add(strLine);
						debugContext = true;
					} 
					
					//Find end of the debug statement in case its written in multiple lines
					else if(debugContext) {
						pieceOfCode.add(strLine);
						if (multiLineDebugEnd.matcher(strLine.toUpperCase()).matches()) {
							debugContext = false;
							lstViolation.add(getViolation(pieceOfCode, lineNo-pieceOfCode.size()+1));
							pieceOfCode.clear();
						}
					}
					lineNo++;
				}
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));				
				}
			} catch (Exception e) {
				Logging.log(e);
			}
		}
		return lstFiles;
	}
	
	
	/**
     * Method name  : getViolation
     * Description  : prepares the violation object based on given piece of code
     * Return Type  : Violation
     * Parameter    : List<String> pieceOfCode, int beginLine
     **/
	private static Violation getViolation(List<String> pieceOfCode, int beginLine) {
		int codeBlockSize = pieceOfCode.size();
		Violation violation = new Violation();
		violation.setValue(DEBUG_FOUND_VIOLATION);
		violation.setRule(getSelectedRule());
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		violation.setBeginline(BigInteger.valueOf(beginLine));
		violation.setBegincolumn(BigInteger.valueOf(pieceOfCode.get(0).toUpperCase().indexOf(DEBUG)));
		violation.setEndline(BigInteger.valueOf(beginLine+codeBlockSize-1));
		violation.setEndcolumn(getEndColumn(pieceOfCode.get(codeBlockSize-1)));
		return violation;	
	}
	
	
	/**
     * Method name  : getFile
     * Description  : get the file
     * Return Type  : File
     * Parameter    : String filePath, List<Violation> lstViolation
     **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;	
	}
	
	
	/**
     * Method name  : getEndColumn
     * Description  : Returns the end column
     * Return Type  : BigInteger
     * Parameter    : String strLine
     **/
	public static BigInteger getEndColumn(String strLine) {
		Stack<String> commentStack = new Stack<String>();
		int endColumn=-1;
		
		//Do not consider ; as the end of the stmt if it is witten inside single quotes
		char[] strLineChars = strLine.toCharArray();
		for(int i=0; i<strLineChars.length; i++) {
			if(String.valueOf(strLineChars[i]).equals(QUOTE)) {
				if(commentStack.isEmpty()) {
					commentStack.push(QUOTE);
				} else {
					commentStack.clear();
				}
			}
			if(String.valueOf(strLineChars[i]).equals(SEMICOLON) && commentStack.isEmpty()) {
				endColumn = i;
			}
		}
		if (endColumn == -1) {
			endColumn = strLine.length()-1;
		}
		return BigInteger.valueOf(endColumn);
	}
	
	
	/**
     * Method name  : getSelectedRule
     * Description  : gets the selected rule (remove/comment)
     * Return Type  : String
     * Parameter    : NA
     **/
	public static String getSelectedRule(){
		if(AutoFixUtilMain.boolIsRunningFromAutoFixExtension){
			if(AutoFixUtilMain.selectedRulesFromExtn.contains(CustomValidationRules.SYSTEM_DEBUG_VALIDATION)){
				return CustomValidationRules.SYSTEM_DEBUG_VALIDATION;
			} else {
				return CustomValidationRules.SYSTEM_DEBUG_VALIDATION_REMOVE;
			}
		} else {
			if(AutofixValidationRules.isRuleSelectedByUser(CustomValidationRules.SYSTEM_DEBUG_VALIDATION)){
				return CustomValidationRules.SYSTEM_DEBUG_VALIDATION;
			}else{
				return CustomValidationRules.SYSTEM_DEBUG_VALIDATION_REMOVE;
			}
		}
	}
	

}
