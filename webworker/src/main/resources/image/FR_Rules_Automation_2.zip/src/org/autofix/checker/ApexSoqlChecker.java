package org.autofix.checker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.model.Checker;

public class ApexSoqlChecker {
	private static List<String> allLines;
	private static Map<Integer, Checker> checkerMap = new HashMap<>();
	private static ApexSoqlChecker soqlChecker = new ApexSoqlChecker();
	
	private static final Pattern SINGLE_lINE_SOQL_PATTERN = Pattern.compile("(\\[select.*\\])|(\\[\\s+select.*\\])");
	private static final Pattern MULTI_LINE_SOQL_START_PATTERN = Pattern.compile("(\\[select)|(\\[\\s+select)");
	private static final Pattern MULTI_LINE_SOQL_END_PATTERN = Pattern.compile("\\]");
	private static final Pattern SOQL_BIND_VARIABLE_PATTERN = Pattern.compile(
			"(=\\s+'(.*?)')|(='(.*?)')|"
			+ "(<>\\s+'(.*?)')|(<>'(.*?)')"
			+ "(!=\\s+'(.*?)')|(!='(.*?)')|"
			);
	
	private ApexSoqlChecker(){}
	
	public static ApexSoqlChecker getInstance(List<String> allLines) {
		ApexSoqlChecker.allLines = allLines;
		doCheck();
		return soqlChecker;
	}
	
	public ApexSoqlChecker getInstance(String fileNameWithPath) throws IOException {
		Path path = Paths.get(fileNameWithPath);
		allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
		doCheck();
		return soqlChecker;
	}
	
	public Checker getChecker(int lineNo) throws CloneNotSupportedException{
		return checkerMap.get(lineNo).clone();
	}
	
	public boolean isSoql(int lineNo, int index){
		Checker checker = checkerMap.get(lineNo);
		if(checker != null){
			if(checker.isMultiLineComment()){
				if(lineNo > checker.getBeginLine() && lineNo < checker.getEndLine()){
					return true;
				}else if( lineNo == checker.getBeginLine() && index >= checker.getBeginIndex()){
					return true;
				}else if( index < checker.getEndIndex()){
					return true;
				}
			}else{
				if(index >= checker.getBeginIndex()){
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean isBindVariableRequired(int lineNo, int beginIndex){
		String tempLine = allLines.get(lineNo-1);// because allLines is 0 index based
		Matcher matcher = SOQL_BIND_VARIABLE_PATTERN.matcher(tempLine);
		while(matcher.find()){
			if(beginIndex >= matcher.start() && beginIndex <= matcher.end()){
				return true;
			}
		}
		return false;
	}
	
	private static void doCheck(){
		Checker tempChecker = null;
		String line;
		boolean isMultiLineSoql = false;
		Matcher tempMatcher;
		checkerMap.clear();
		for(int i=0; i<allLines.size(); i++){
			line = allLines.get(i).toLowerCase();
			if(isMultiLineSoql){
				checkerMap.put(i+1, tempChecker);
				tempMatcher = MULTI_LINE_SOQL_END_PATTERN.matcher(line);
				if(tempMatcher.find()){
					isMultiLineSoql = false;
					tempChecker.setEndLine(i+1);
					tempChecker.setEndIndex(tempMatcher.end());
				}
			}else{
				tempMatcher = SINGLE_lINE_SOQL_PATTERN.matcher(line);
				if(tempMatcher.find()){
					tempChecker = new Checker();
					tempChecker.setBeginLine(i+1);
					tempChecker.setEndLine(i+1);
					tempChecker.setBeginIndex(tempMatcher.start());
					tempChecker.setEndIndex(line.length()-1);
					checkerMap.put(i+1, tempChecker);
				}
				else{
					tempMatcher = MULTI_LINE_SOQL_START_PATTERN.matcher(line);
					if(tempMatcher.find()){
						isMultiLineSoql = true;
						tempChecker = new Checker();
						tempChecker.setBeginLine(i+1);
						tempChecker.setBeginIndex(tempMatcher.start());
						tempChecker.setMultiLineComment(true);
					}
				}
			}
		}
	}
	
	
}
