package org.autofix.ui.panel;

import org.autofix.common.CustomException;
import org.autofix.ui.CompareFileFrame;
import org.autofix.utility.AutofixUIUtility;

public class ReportPanel extends ForceReviewerPanel{

	private CompareFileFrame frame = new CompareFileFrame(this);
	@Override
	public void entry() {
		// TODO Auto-generated method stub
		frame.entry();
		AutofixUIUtility.getAutoFixUIRef().setVisible(false);
		
	}

	@Override
	public void exit() throws CustomException {
		// TODO Auto-generated method stub
		AutofixUIUtility.getAutoFixUIRef().setVisible(true);
	}

}
