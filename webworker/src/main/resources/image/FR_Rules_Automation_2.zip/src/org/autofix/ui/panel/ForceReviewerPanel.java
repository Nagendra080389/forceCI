package org.autofix.ui.panel;

import javax.swing.JPanel;

import org.autofix.common.CustomException;

public abstract class ForceReviewerPanel extends JPanel{

	private static final long serialVersionUID = 5891575710511542045L;
	public abstract void entry();
	public abstract void exit() throws CustomException;
	public void showError(String errorMsg){};
	public void showInfo(String infoMsg){};

}
