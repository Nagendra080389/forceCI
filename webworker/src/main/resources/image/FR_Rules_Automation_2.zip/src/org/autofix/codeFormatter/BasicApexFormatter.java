/**************************************************************************************
Class Name		: BasicApexFormatter
Version   		: 1.0 
Created Date	: 03 September 2020
Function   		: Class to fix the basic apex formatting
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/09/2020              Initial Version
*************************************************************************************/

package org.autofix.codeFormatter;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class BasicApexFormatter {
	
	private static final Pattern ifStmt = Pattern.compile("(.*)if\\((.*)\\)(.*)");
	private static final Pattern whileStmt = Pattern.compile("(.*)while\\((.*)\\)(.*)");
	private static final Pattern forStmt = Pattern.compile("(.*)for\\((.*)\\)(.*)");
	private static final String CLOSE_BRACE = ")";
	private static final String TAB = "\t";
	private static final String IF = "if";
	private static final String WHILE = "while";
	private static final String FOR = "for";

	
	/**
     * Method name  : runApexFormatter
     * Description  : runs the basic apex formatting
     * Return Type  : void
     * Parameter    : File file
     **/
	public static void runApexFormatter(File file) throws IOException {
		List<String> lines = new ArrayList<String>();
		Path path;
		path = Paths.get(file.getAbsolutePath());
		lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		
		//update single line if statements
		lines = updateSingleLineIfStmts(lines);
		
		//update single line if statements
		lines = updateSingleLineWhileStmts(lines);
				
		//update single line if statements
		lines = updateSingleLineForStmts(lines);
		
		Files.write(path, lines, StandardCharsets.UTF_8);
	}

	
	/**
     * Method name  : updateSingleLineIfStmts
     * Description  : updates the if statements written in single line
     * Return Type  : void
     * Parameter    : List<String> lines
     **/
	private static List<String> updateSingleLineIfStmts(List<String> lines) {
		String stringAfterStmt = null;
		String content = null;
		
		for(int i=0; i<lines.size(); i++) {
			if(ifStmt.matcher(lines.get(i).toLowerCase()).matches()) {
				stringAfterStmt = lines.get(i).substring(lines.get(i).indexOf(CLOSE_BRACE)+1).trim();
				if(stringAfterStmt.length() > 0) {
					content = lines.get(i).substring(0, lines.get(i).toLowerCase().indexOf(IF))
							+ TAB
							+ lines.get(i).substring(lines.get(i).indexOf(CLOSE_BRACE)+1);
					lines.set(i, lines.get(i).substring(0, lines.get(i).indexOf(CLOSE_BRACE)+1));
					lines.add(i+1, content);
				}
			}
		}
		
		return lines;
	}
	
	
	/**
     * Method name  : updateSingleLineWhileStmts
     * Description  : updates the while statements written in single line
     * Return Type  : void
     * Parameter    : List<String> lines
     **/
	private static List<String> updateSingleLineWhileStmts(List<String> lines) {
		String stringAfterStmt = null;
		String content = null;
		
		for(int i=0; i<lines.size(); i++) {
			if(whileStmt.matcher(lines.get(i).toLowerCase()).matches()) {
				stringAfterStmt = lines.get(i).substring(lines.get(i).indexOf(CLOSE_BRACE)+1).trim();
				if(stringAfterStmt.length() > 0) {
					content = lines.get(i).substring(0, lines.get(i).toLowerCase().indexOf(WHILE))
							+ TAB
							+ lines.get(i).substring(lines.get(i).indexOf(CLOSE_BRACE)+1);
					lines.set(i, lines.get(i).substring(0, lines.get(i).indexOf(CLOSE_BRACE)+1));
					lines.add(i+1, content);
				}
			}
		}
		
		return lines;
	}
	
	
	/**
     * Method name  : updateSingleLineForStmts
     * Description  : updates the for statements written in single line
     * Return Type  : void
     * Parameter    : List<String> lines
     **/
	private static List<String> updateSingleLineForStmts(List<String> lines) {
		String stringAfterStmt = null;
		String content = null;
		
		for(int i=0; i<lines.size(); i++) {
			if(forStmt.matcher(lines.get(i).toLowerCase()).matches()) {
				stringAfterStmt = lines.get(i).substring(lines.get(i).indexOf(CLOSE_BRACE)+1).trim();
				if(stringAfterStmt.length() > 0) {
					content = lines.get(i).substring(0, lines.get(i).toLowerCase().indexOf(FOR))
							+ TAB
							+ lines.get(i).substring(lines.get(i).indexOf(CLOSE_BRACE)+1);
					lines.set(i, lines.get(i).substring(0, lines.get(i).indexOf(CLOSE_BRACE)+1));
					lines.add(i+1, content);
				}
			}
		}
		
		return lines;
	}
	
}
