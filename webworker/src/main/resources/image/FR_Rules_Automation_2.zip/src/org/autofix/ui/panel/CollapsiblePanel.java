package org.autofix.ui.panel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.image.BufferedImage;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


/**
 * This class creates the CollapsablePanel panel for Apex and AURA/LWC 
 * Category
 * @author ruchkumari
 *
 */
class CollapsablePanel extends JPanel {
 
	private boolean selected;
	private JPanel contentPanel;
	private HeaderPanel headerPanel;
	private String up ="up";
	private String down ="down";
	private String upArrow ="\u02C5 ";
	private String downArrow ="\u02C3 ";
			
	// creates the header
	private class HeaderPanel extends JPanel implements MouseListener {
		String text;
		Font font;
		BufferedImage open, closed;
		final int OFFSET = 30, PAD = 5;
        String direction = "down";
       
		public HeaderPanel(String headerText) {
			addMouseListener(this);
			this.text = headerText ;
			font = new Font("sans-serif", Font.BOLD, 15);
			setPreferredSize(new Dimension(450, 30));
			setBackground(Color.WHITE);
			setBorder(BorderFactory.createEmptyBorder());
			setOpaque(false);	
		}

		protected void paintComponent(Graphics g) {
			super.paintComponent(g);		
			Graphics2D g2 = (Graphics2D) g;
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			int h = getHeight();
			g2.setFont(font);
			FontRenderContext frc = g2.getFontRenderContext();
			LineMetrics lm = font.getLineMetrics(text, frc);
			float height = lm.getAscent() + lm.getDescent();
			float x = OFFSET;
			float y = (h + height) / 2 - lm.getDescent();
			if(direction.equalsIgnoreCase(up)) {
				String newText = upArrow+this.text; 
				g2.drawString(newText, x, y);
			}else if(direction.equalsIgnoreCase(down)) {
				String newText = downArrow+this.text;
				g2.drawString(newText, x, y);
			}
			
		}

		public void mouseClicked(MouseEvent e) {
			boolean flag = toggleSelection();
			if(flag) {
				this.direction = up;				 
			}else{
				this.direction = down;
			}
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}

		public void mousePressed(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}
	}


	/**
	 * add Category Apex and Aura/LWC along with  respective checkbox in the JPanel
	 * @param text
	 * @param panelForCheckBox
	 */
	public CollapsablePanel(String text, List<JCheckBox> allCheckBox) {

		super(new GridBagLayout());
		JPanel panelForCheckBox = buildPanel(allCheckBox);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.weightx = 1.0;
		gbc.anchor = gbc.LINE_START;
		gbc.gridwidth = gbc.REMAINDER;
		selected = false;
		headerPanel = new HeaderPanel(text);
		headerPanel.setFont(new Font(headerPanel.getFont().getName(),Font.BOLD,headerPanel.getFont().getSize()));

		this.setOpaque(false);
		this.setBackground(Color.WHITE);
		this.setForeground(Color.WHITE);
		contentPanel = panelForCheckBox;
		contentPanel.setVisible(false);

		add(headerPanel, gbc);
		add(contentPanel, gbc);
		headerPanel.revalidate();
		headerPanel.repaint();
		contentPanel.revalidate();
		contentPanel.repaint();
		gbc.gridwidth = gbc.REMAINDER;
	}
	/**
	 * toggle the panel containing checkbox
	 */
	public boolean toggleSelection() {
		selected = !selected;
		if (contentPanel.isShowing()) {
			contentPanel.setVisible(false);
			validate();
			headerPanel.repaint();	
			return false;
		}
		else {
			contentPanel.setVisible(true);
			validate();
			headerPanel.repaint();	
			return true;
			}
		
	}

	//creates the panel containing all the checkbox of respective Category
	public  JPanel buildPanel(List<JCheckBox> allCheckBox) {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(2, 25, 2, 1);       
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		gbc.anchor = gbc.WEST;
		gbc.fill = gbc.VERTICAL;

		JPanel panelForCheckBox = new JPanel(new GridBagLayout());     
		for(JCheckBox checkbox : allCheckBox){	
			gbc.gridwidth = gbc.RELATIVE;
			JLabel padding = new JLabel();
			panelForCheckBox.add(padding, gbc);
			gbc.gridwidth = gbc.REMAINDER;
			panelForCheckBox.add(checkbox,gbc);

		}

		panelForCheckBox.setOpaque(false);
		panelForCheckBox.setBackground(Color.WHITE);
		panelForCheckBox.setForeground(Color.WHITE);
		return panelForCheckBox;
	}

}