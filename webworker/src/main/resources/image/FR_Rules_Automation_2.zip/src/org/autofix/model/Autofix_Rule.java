package org.autofix.model;

public class Autofix_Rule {
	
	private String uniqueRuleName;
	private String ruleInfoForUI;
	private int iteration_order;
	private int execution_order;
	private boolean isSelected;
	private boolean isPMDRule;
	private String validationClassName;
	private String ruleClassName;
	private String category;
	private RuleCategory ruleCategory;
	
	public Autofix_Rule(String uniqueRuleName, String ruleInfoForUI, int iteration_order, int execution_order,
			boolean isSelectedByDefault, boolean isPMDRule, String category) {
		super();
		this.uniqueRuleName = uniqueRuleName;
		this.ruleInfoForUI = ruleInfoForUI;
		this.iteration_order = iteration_order;
		this.execution_order = execution_order;
		this.isSelected = isSelectedByDefault;
		this.isPMDRule = isPMDRule;
		this.category = category;
	}
	
	public Autofix_Rule(String uniqueRuleName, String ruleInfoForUI, int iteration_order, int execution_order,
			boolean isSelected, boolean isPMDRule, String validationClassName, String ruleClassName) {
		super();
		this.uniqueRuleName = uniqueRuleName;
		this.ruleInfoForUI = ruleInfoForUI;
		this.iteration_order = iteration_order;
		this.execution_order = execution_order;
		this.isSelected = isSelected;
		this.isPMDRule = isPMDRule;
		this.validationClassName = validationClassName;
		this.ruleClassName = ruleClassName;
	}



	public String getUniqueRuleName() {
		return uniqueRuleName;
	}
	
	public String getRuleInfoForUI() {
		return ruleInfoForUI;
	}
	
	public int getIteration_order() {
		return iteration_order;
	}
	
	public int getExecution_order() {
		return execution_order;
	}
	
	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public boolean isPMDRule() {
		return isPMDRule;
	}

	public String getValidationClassName() {
		return validationClassName;
	}

	public String getRuleClassName() {
		return ruleClassName;
	}
	
	public String getCategory() {
		return category;
	}

	public void setUniqueRuleName(String uniqueRuleName) {
		this.uniqueRuleName = uniqueRuleName;
	}

	public void setRuleInfoForUI(String ruleInfoForUI) {
		this.ruleInfoForUI = ruleInfoForUI;
	}

	public void setIteration_order(int iteration_order) {
		this.iteration_order = iteration_order;
	}

	public void setExecution_order(int execution_order) {
		this.execution_order = execution_order;
	}

	public void setPMDRule(boolean isPMDRule) {
		this.isPMDRule = isPMDRule;
	}

	public void setValidationClassName(String validationClassName) {
		this.validationClassName = validationClassName;
	}

	public void setRuleClassName(String ruleClassName) {
		this.ruleClassName = ruleClassName;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public RuleCategory getRuleCategory() {
		return ruleCategory;
	}

	public void setRuleCategory(RuleCategory ruleCategory) {
		this.ruleCategory = ruleCategory;
	}

}
