package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
 * Program to remove extra semi colon in javascript code
 *
 * @author Akshay Anil Agrawal
 * @version 1.0
 * @since 2020-08-11
 */
public class RemoveExtraSemiColonFromJsRule implements IFRRules {
	
	private static final String CONSECUTIVE_SEMICOLONS_REGEX = "(;\\s*)+;";

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		String currentLine = null;
		ViolationInfo info = null;
		for(Violation v : violationLst){
			info = new ViolationInfo(fileName, v.getRule());			
			currentLine = allLines.get(v.getBeginline().intValue()-1);
			info.setBeforeFix(currentLine);
			currentLine = currentLine.replaceAll(CONSECUTIVE_SEMICOLONS_REGEX, ";");
			allLines.set(v.getBeginline().intValue()-1, currentLine);
			info.setAfterFix(currentLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}
