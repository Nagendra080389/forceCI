/**************************************************************************************
Class Name		: DebugStmtsRule
Version   		: 1.0 
Created Date	: 03 Feb 2020
Function   		: Class to fix the debug statement violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/02/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.util.List;

import org.autofix.common.AutofixValidationRules;
import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

public class DebugStmtsRule implements IFRRules {
	private static final String ADD_COMMENT = "//";
	private static final String NEW_LINE = "\n";

	/**
     * Method name  : doOperation
     * Description  : updates the code by commenting/removing debug statements based on user's choice
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		boolean removeDebug = true;
		if(AutofixValidationRules.isRuleSelectedByUser(CustomValidationRules.SYSTEM_DEBUG_VALIDATION)) {
			removeDebug = false;
		}
		
		for(Violation violation : violationLst){
			try {
				//Handle single line debugs
				if(violation.getBeginline().intValue() == violation.getEndline().intValue()) {
					allLines = fixSingleLineViolation(fileName, allLines, violation, removeDebug);
				}
				
				//Handle multiline debugs
				else {
					allLines = fixMultiLineViolation(fileName, allLines, violation, removeDebug);
				}
				
			} catch(Exception ex) {
				Logging.log("error occured on file :: "+fileName+" for rule :: "+violation.getRule(),ex);
			}
		}
		
	}
	
	
	/**
     * Method name  : fixSingleLineViolation
     * Description  : fixes the single line debug statement violations
     * Return Type  : List<String>
     * Parameter    : String fileName, List<String> allLines, Violation violation, boolean removeDebug
     **/
	private static List<String> fixSingleLineViolation(String fileName, List<String> allLines, Violation violation, boolean removeDebug) {
		ViolationInfo info = new ViolationInfo(fileName, violation.getRule());
		String tempContent = allLines.get(violation.getBeginline().intValue()-1);
		
		info.setBeforeFix(tempContent);
		if(removeDebug) {
			tempContent = tempContent.substring(0, violation.getBegincolumn().intValue()) 
					+ AppConstants.NEED_TO_REMOVE_THIS_LINE 
					+ tempContent.substring(violation.getEndcolumn().intValue()+1);
		} else {
			tempContent = tempContent.substring(0, violation.getBegincolumn().intValue())
					+ ADD_COMMENT
					+ tempContent.substring(violation.getBegincolumn().intValue());
		}
		info.setAfterFix(tempContent.replace(AppConstants.NEED_TO_REMOVE_THIS_LINE, ""));
		Reporting.violationInfos.add(info.toCSVRow());
		allLines.set(violation.getBeginline().intValue()-1, tempContent);
		return allLines;
	}
	
	
	/**
     * Method name  : doOperation
     * Description  : fixes the multiple line debug statement violations
     * Return Type  : List<String>
     * Parameter    : String fileName, List<String> allLines, Violation violation, boolean removeDebug
     **/
	private static List<String> fixMultiLineViolation(String fileName, List<String> allLines, Violation violation, boolean removeDebug) {
		ViolationInfo info = new ViolationInfo(fileName, violation.getRule());
		String tempContent = null;
		
		for(int i=violation.getBeginline().intValue()-1; i<violation.getEndline().intValue(); i++) {
			tempContent = allLines.get(i);
			info.setBeforeFix((info.getBeforeFix() == null ? "" : info.getBeforeFix() + NEW_LINE) + tempContent);
			
			//Remove debug statements
			if(removeDebug) {
				//Begin line of the multiline debug
				if(i == violation.getBeginline().intValue()-1) {
					tempContent = tempContent.substring(0, violation.getBegincolumn().intValue()) + AppConstants.NEED_TO_REMOVE_THIS_LINE;
				}
				
				//End line of the multiline debug
				else if(i == violation.getEndline().intValue()) {
					tempContent = AppConstants.NEED_TO_REMOVE_THIS_LINE + tempContent.substring(violation.getEndcolumn().intValue()+1);
				}
				
				//Middle lines of the multiline debug
				else {
					tempContent = AppConstants.NEED_TO_REMOVE_THIS_LINE;
				}
			} 
			
			//Comment debug statements
			else {
				//Begin line of the multiline debug
				if(i == violation.getBeginline().intValue()-1) {
					tempContent = tempContent.substring(0, violation.getBegincolumn().intValue()) + ADD_COMMENT + tempContent.substring(violation.getBegincolumn().intValue());
				}
				
				//End line of the multiline debug
				else if(i == violation.getEndline().intValue()) {
					tempContent = tempContent.substring(0, violation.getBegincolumn().intValue()) + ADD_COMMENT + tempContent;
				}
				
				//Middle lines of the multiline debug
				else {
					tempContent = tempContent.substring(0, violation.getBegincolumn().intValue()) + ADD_COMMENT + tempContent;
				}
			}
			
			allLines.set(i, tempContent);
			info.setAfterFix((info.getAfterFix() == null ? "" : info.getAfterFix() + NEW_LINE) + tempContent.replace(AppConstants.NEED_TO_REMOVE_THIS_LINE, ""));
		}
		Reporting.violationInfos.add(info.toCSVRow());
		return allLines;
	}
	
}
