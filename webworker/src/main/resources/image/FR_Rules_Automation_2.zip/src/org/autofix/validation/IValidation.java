package org.autofix.validation;

import java.util.List;

import org.autofix.model.File;

public interface IValidation {
	
	public List<File> runValidation(List<String> fileNameLst);

}
