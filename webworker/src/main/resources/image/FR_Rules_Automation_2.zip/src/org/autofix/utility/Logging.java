/**************************************************************************************
Class Name		: Logging
Version   		: 1.0 
Created Date	: 05 May 2020
Function   		: Class to log info/errors and reporting
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Laltu Banerjee			05/05/2020              Initial Version
*************************************************************************************/

package org.autofix.utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.autofix.common.ApplicationParameter;
import org.autofix.constants.AppConstants;

public class Logging {

	private static String loggingFolder;
	private static String errorFileName;
	private static String infoFileName;

	static{
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMYYYY_HHmmss");
		String strDate = formatter.format(date);
		
		//Info logging details
		errorFileName = AppConstants.ERROR_LOG_FILE_NAME+"_"+strDate+".txt";
		infoFileName = AppConstants.INFO_LOG_FILE_NAME+"_"+strDate+".txt";
		File logFolder = new File(ApplicationParameter.getAppLogFolderName());
		if(! logFolder.exists()){
			logFolder.mkdir();
		}
		loggingFolder = logFolder.getAbsolutePath();
	}

	public static void log(String infoStr){
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = new File(loggingFolder+"/"+infoFileName);
		try{
			fw = new FileWriter(file.getAbsolutePath(),true);
			bw = new BufferedWriter(fw);
			bw.write("============================\n");
			bw.write(infoStr+"\n");
			bw.write("============================\n");
		}catch(Exception error){
			error.printStackTrace();
		}finally {
			try{
				if(bw!=null)
					bw.close();
				if(fw!=null)
					fw.close();
			}catch(Exception e){

			}
		}

	}

	public static void log(List<String> infoLst){
		StringBuilder sb = new StringBuilder();
		for(String str : infoLst){
			sb.append(str+"\n");
		}
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = new File(loggingFolder+"/"+infoFileName);
		try{
			fw = new FileWriter(file.getAbsolutePath(),true);
			bw = new BufferedWriter(fw);
			bw.write("============================\n");
			bw.write(sb.toString()+"\n");
			bw.write("============================\n");
		}catch(Exception error){
			error.printStackTrace();
		}finally {
			try{
				if(bw!=null)
					bw.close();
				if(fw!=null)
					fw.close();
				sb = null;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}

	public static void log(String info,Exception error){
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = new File(loggingFolder+"/"+errorFileName);
		// covert the stack trace to string
		StringWriter sw = new StringWriter();
		error.printStackTrace(new PrintWriter(sw));
		try{
			fw = new FileWriter(file.getAbsolutePath(),true);
			bw = new BufferedWriter(fw);
			bw.write("============================\n");
			bw.write(info+"\n");
			bw.write(sw.toString()+"\n");
			bw.write("============================\n");
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try{
				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();
			}catch(Exception e1){
				e1.printStackTrace();
			}
		}	
	}
	
	public static void log(Exception error,String info){
		log(info,error);
	}

	public static void log(Exception error){
		BufferedWriter bw = null;
		FileWriter fw = null;
		File file = new File(loggingFolder+"/"+errorFileName);
		// covert the stack trace to string
		StringWriter sw = new StringWriter();
		error.printStackTrace(new PrintWriter(sw));
		try{
			fw = new FileWriter(file.getAbsolutePath(),true);
			bw = new BufferedWriter(fw);
			bw.write("============================\n");
			bw.write(sw.toString()+"\n");
			bw.write("============================\n");
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try{
				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();
			}catch(Exception e1){
				e1.printStackTrace();
			}
		}
	}
	
}
