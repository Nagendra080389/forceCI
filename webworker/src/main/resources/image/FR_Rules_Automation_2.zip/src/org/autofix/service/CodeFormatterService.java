package org.autofix.service;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.autofix.codeFormatter.BracesFormatter;
import org.autofix.codeFormatter.ICodeFormatter;
import org.autofix.common.ApplicationParameter;
import org.autofix.constants.AppConstants;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.AppUtility;
import java.util.*;

public class CodeFormatterService {
	
	private static final String srcFolder = ApplicationParameter.getLocalSourceFolderPath();
	private String destFoler;
	private static final String OPEN_BRACE = "{";
	private static final String CLOSE_BRACE = "}";
	private static final List<String> nestedViolationCheckForRules = Arrays.asList(AppConstants.NESTED_VIOLATION_CHECK.split(";"));
	private static final List<String> bracesFormatterCheckForRules = Arrays.asList(AppConstants.BRACES_FORMATTER_CHECK.split(";"));
	private static final String SOQL_SECURITY_ENFORCED_RULE = "SoqlSecurityEnforced";
	
	public CodeFormatterService(String destFoler) {
		super();
		this.destFoler = destFoler;
		System.out.println(" CodeFormatterService :: "+this.destFoler);
	}

	public void runCodeFormatter1(File file) throws IOException{
		List<Integer> intLst = file.getViolation()
				.stream()
				.filter(f -> bracesFormatterCheckForRules.contains(f.getRule()))
				.map(f -> f.getBeginline().intValue() )
				.collect(Collectors.toList());
		
		HashMap<Object, Object> startEndLineMap = (HashMap) file.getViolation()
													.stream()
													.filter(f -> SOQL_SECURITY_ENFORCED_RULE.equals(f.getRule()) && !f.getBeginline().equals(f.getEndline()))														
													.collect(Collectors.toMap(Violation::getBeginline, Violation::getEndline));
		
		Path path = Paths.get(file.getName());
		List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		if(intLst != null && !intLst.isEmpty()){
			if(startEndLineMap != null && startEndLineMap.isEmpty()) {
				ICodeFormatter formatter = new BracesFormatter();
				lines = formatter.formatCode(lines, intLst);
			}
			else {
				ICodeFormatter formatter = new BracesFormatter();
				lines = formatter.formatCode(lines, intLst, startEndLineMap);
			}
		}
		removeUnwantedLines(lines);
		Files.write(path, lines, StandardCharsets.UTF_8);
	}
	
	public void runCodeFormatter(File file) throws IOException{
		List<Integer> intLst = file.getViolation()
				.stream()
				.filter(f -> bracesFormatterCheckForRules.contains(f.getRule()))
				.map(f -> f.getBeginline().intValue() )
				.collect(Collectors.toList());
		
		String destFolderFileNameWithPath = file.getName().replace(srcFolder, this.destFoler);
		Path path = Paths.get(destFolderFileNameWithPath);
		List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		if(intLst != null && !intLst.isEmpty()){
			ICodeFormatter formatter = new BracesFormatter();
			lines = formatter.formatCode(lines, intLst);
		}
		
		removeUnwantedLines(lines);
		Files.write(path, lines, StandardCharsets.UTF_8);
	}
	
	private void removeUnwantedLines(List<String> allLinesOfFile){
		List<Integer> indexLst = new ArrayList<>();
		String tempLine;
		for(int i=0;i<allLinesOfFile.size();i++){
			tempLine = allLinesOfFile.get(i).trim();
			if(tempLine.equalsIgnoreCase(AppConstants.NEED_TO_REMOVE_THIS_LINE.trim())) {
				indexLst.add(i);
			} else if(tempLine.contains(AppConstants.NEED_TO_REMOVE_THIS_LINE.trim())){
				allLinesOfFile.set(i, tempLine.replace(AppConstants.NEED_TO_REMOVE_THIS_LINE.trim(), ""));
			}
		}
		AppUtility.removeIndexFromList(indexLst, allLinesOfFile);
	}
	
	public void updateNestedViolations(File inputFile) throws IOException{
		Path path = Paths.get(inputFile.getName());
		List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		List<Violation> violationNeedUpdate = new ArrayList<>();
		for(Violation violation : inputFile.getViolation()){
			if(nestedViolationCheckForRules.contains(violation.getRule())){
				violationNeedUpdate.add(violation);
			}
		}
		
		int openBraces = 0;
		int closeBraces = 0;
		for(Violation violation : violationNeedUpdate) {
			for(Violation vlatn : violationNeedUpdate) {
				if((violation.getBeginline().intValue() + 1) == vlatn.getBeginline().intValue()) {
					vlatn.setNumberOfEndBraces(vlatn.getNumberOfEndBraces() + violation.getNumberOfEndBraces());
					violation.setNumberOfEndBraces(0);
					if(lines.get(vlatn.getEndline().intValue()-1).length() > vlatn.getEndcolumn().intValue()) {
						openBraces = 0;
						closeBraces = 0;
						for(Integer i = vlatn.getEndline().intValue()-1 ; i <= lines.size() ; i++) {
							String content = lines.get(i);
							if(content.contains(OPEN_BRACE)) {
								openBraces++;
							}
							if(openBraces > 0 && content.contains(CLOSE_BRACE)) {
								closeBraces++;
							}
							if(openBraces == closeBraces) {
								vlatn.setEndline(BigInteger.valueOf(i+1));
								vlatn.setEndcolumn(BigInteger.valueOf(content.indexOf(CLOSE_BRACE)-1));
								break;
							}
						}
					}
				}
			}
		}
		// For Loop Ends
		
	}
	
	/*public LinkedHashMap<String, List<Violation>> reorderViolations(Map<String, List<Violation>> violationMap) {
		LinkedHashMap<String, List<Violation>> orderedViolations = new LinkedHashMap<String, List<Violation>>();
		for(String rule : AutofixConfig.getFrConfigMap().keySet()) {
			if(violationMap.containsKey(rule) && violationMap.get(rule) != null) {
				orderedViolations.put(rule, violationMap.get(rule));
			}
		}
		return orderedViolations;
	}*/

}
