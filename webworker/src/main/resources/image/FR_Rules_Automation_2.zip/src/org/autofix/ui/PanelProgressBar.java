package org.autofix.ui;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

import org.autofix.constants.AppConstants;
import org.autofix.utility.AutofixUIUtility;

public class PanelProgressBar extends Thread {

	JProgressBar progressBar;
	JFrame uiFrame;

	public PanelProgressBar(JProgressBar progressBar,JFrame uiFrame) {
		this.progressBar = progressBar;
		this.uiFrame = uiFrame;
	}

	public void run() {
		this.uiFrame.setEnabled(false);
		this.progressBar.setValue(progressBar.getMinimum());
		this.progressBar.setVisible(true);
		int maximum = progressBar.getMaximum();
		int currentProgressbarVal = AutofixUIUtility.getUiProgressBarValue();
		while(currentProgressbarVal<maximum){
			try{
				currentProgressbarVal = AutofixUIUtility.getUiProgressBarValue();
				this.progressBar.setValue(currentProgressbarVal);
				Thread.sleep(AppConstants.PROGRESS_BAR_THREAD_DELAY);
			}catch(Exception e){

			}
		}
		this.progressBar.setVisible(false);
		this.uiFrame.setEnabled(true);
	}
}
