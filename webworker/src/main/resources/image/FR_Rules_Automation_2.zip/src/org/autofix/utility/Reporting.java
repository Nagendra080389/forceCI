/**************************************************************************************
Class Name		: Reporting
Version   		: 1.0 
Created Date	: 10 June 2020
Function   		: Class to log info/errors and reporting
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------
* Ette Balakrishna			06/10/2020				Intial Version
*************************************************************************************/

package org.autofix.utility;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.autofix.common.ApplicationParameter;
import org.autofix.constants.AppConstants;

import com.opencsv.CSVWriter;

public class Reporting {
	
	private static String reportFolder;
	private static String reportFileName;
	public static List<String[]> violationInfos;
	
	
	/**
     * Method name  : initiateReportPreq
     * Description  : creates a report file
     * Return Type  : void
     * Parameter    : NA
     **/
	public static void initiateReportPreq() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("ddMMYYYY_HHmmss");
		String strDate = formatter.format(date);
		
		//Report logging details
		reportFileName = AppConstants.INFO_REPORT_FILE_NAME + "_" + strDate + ".csv";
		File repFolder = new File(ApplicationParameter.getReportFolderName());
		if(!repFolder.exists()){
			repFolder.mkdir();
		}
		reportFolder = repFolder.getAbsolutePath();
		
		//initialize violationInfos
		violationInfos = new ArrayList<String[]>();
	}
	
	
	/**
     * Method name  : initReport
     * Description  : creates a CSV file with header row
     * Return Type  : void
     * Parameter    : NA
     **/
	public static void initReport() {
		FileWriter csvFile = null;
		CSVWriter csvWriter = null;
		File file = new File(reportFolder+"/"+reportFileName);
		try {
			csvFile = new FileWriter(file);
			csvWriter = new CSVWriter(csvFile);
			csvWriter.writeNext(AppConstants.CSV_HEADER_LINE);
			csvWriter.close();
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			
		}
	}
	
	
	/**
     * Method name  : addConent
     * Description  : adds content to the given CSV file
     * Return Type  : void
     * Parameter    : ViolationInfo info
     **/
	public static void addConent() {
		FileWriter csvFile = null;
		CSVWriter csvWriter = null;
		File file = new File(reportFolder+"/"+reportFileName);
		try {
			csvFile = new FileWriter(file,true);
			csvWriter = new CSVWriter(csvFile);
			csvWriter.writeNext(AppConstants.CSV_HEADER_LINE);
			csvWriter.writeAll(violationInfos);
			csvWriter.close();
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			
		}
	}

}
