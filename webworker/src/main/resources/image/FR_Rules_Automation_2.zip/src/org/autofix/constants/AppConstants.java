package org.autofix.constants;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

public class AppConstants {

	private static List<String> pmdValidationRules = new ArrayList<>();
	private static List<String> otherValidationRules = new ArrayList<>();

	public static List<String> getAllPmdValidationName(){
		if(pmdValidationRules.isEmpty()){
			pmdValidationRules.addAll(ValidationRules.PMDValidationRules.getAllRules());
		}
		return new ArrayList<>(pmdValidationRules);
	}

	public static List<String> getAllCustomValidationName(){
		if(otherValidationRules.isEmpty()){
			otherValidationRules.addAll(ValidationRules.CustomValidationRules.getAllRules());
		}
		return new ArrayList<>(otherValidationRules);
	}

	public static final String USER_AUTH_URL = "https://forcereviewer.deloitte.com/frauthapp/validateOrRegister";
	public static final String ERROR_LOG_FILE_NAME = "ErrorLog";
	public static final String INFO_LOG_FILE_NAME = "AppLog";
	public static final String INFO_REPORT_FILE_NAME = "Report";
	public static final int PMD_THREAD_SLEEP_TIME = 5000; // This is in milisecond
	public static final String AUTH_SUCCESS_MESSAGE = "VERIFIED";
	public static final String AUTH_EMAIL_SENT_MESSAGE = "EMAIL_SENT";
	public static final String EMAIL_SENT_USER_MESSAGE = "Registration Link sent to your Deloitte mail Id";
	public static final String AUTH_FAILURE_MESSAGE = "Authentication Failed, Internet Issue or User Not in Deloitte Network";
	public static final String NESTED_VIOLATION_CHECK = "IfElseStmtsMustUseBraces;ForLoopsMustUseBraces;WhileLoopsMustUseBraces;IfStmtsMustUseBraces";
	public static final String TEST_METHOD_STR = "TestMethod";
	public static final String IS_TEST_ANNOTATION = "@ISTEST";
	public static final String DIRECTORY_LOCATION_SEPARATOR = "//";
	public static final String SPACE = " ";
	public static final String EMPTY = "";
	public static final String EQUALS_SIGN = "=";
	public static final String COLON_CHARACTER = ":";
	public static final String SEMI_COLON_CHARACTER = ";";
	public static final String DOT_CHARACTER = ".";
	public static final String ALL_WHITESPACES = "\\s+";
	public static final String PUBLIC_KEYWORD = "public";
	public static final String BRACES_FORMATTER_CHECK = "IfElseStmtsMustUseBraces;ForLoopsMustUseBraces;WhileLoopsMustUseBraces;SoqlSecurityEnforced;NullCheckBeforeDML;";
	public static final String NEED_TO_REMOVE_THIS_LINE = "\t\t\t//NEED_TO_REMOVE_THIS_LINE";
	public static final String VOID_STR = "void";
	public static final String STATIC_STR = "static";
	public static final String EQUALS_STR = "equals";
	public static final String NEW_STR = "new";
	public static final String OPEN_BRACKET_STR = "(";
	public static final String CLOSE_BRACKET_STR = ")";
	public static final String OPEN_BRACES_STR = "{";
	public static final String CLOSE_BRACES_STR = "}";
	public static final char OPEN_BRACES_CHAR = '{';
	public static final char CLOSE_BRACES_CHAR = '}';
	public static final String CLOSE_RECT_BRACE = "]";
	public static final String OPEN_RECT_BRACE = "[";
	public static final String COMMA_STRING = ",";
	public static final String IMPORT_STRING = "import";	
	public static final String FROM_STRING = "from";
	public static final String AS_STRING = "as";

	public static final String LITERAL_CLASS = "CLASS";
	public static final String SELECT_CLAUSE = "SELECT";
	public static final String FROM_CLAUSE = "FROM";
	public static final String TYPEOF_CLAUSE = "TYPEOF";
	public static final String AS_CLAUSE = "AS";
	public static final String WITH_SECURITY_ENFORCED_CLAUSE = "WITH SECURITY_ENFORCED";

	public static final String COMMENT_START_PATTERN = "/*";
	public static final String COMMENT_END_PATTERN = "*/";
	public static final String SINGLE_LINE_COMMENT = "//";

	public static final String APEX_RESERVED_KEYWORD = "abstract;global;private;activate;goto;protected;and;group;public;any;having;array;retrieve;hint;return;as;if;returning;"
			+"asc;implements;rollback;autonomous;import;savepoint;begin;inner;search;bigdecimal;insert;select;blob;instanceof;set;break;"
			+"interface;short;bulk;into;sort;by;int;stat;byte;super;join;case;last_90_days;switch;cast;last_month;synchronized;catch;"
			+"last_n_days;system;char;last_week;testmethod;class;like;then;collect;limit;this;commit;list;this_month;const;long;"
			+"this_week;continue;loop;throw;convertcurrency;map;today;decimal;merge;tolabel;default;new;tomorrow;delete;next_90_days;"
			+"transaction;next_month;desc;trigger;do;next_n_days;true;else;next_week;try;end;not;type;enum;null;undelete;exception;"
			+"nulls;update;exit;number;upsert;export;object;using;extends;of;virtual;false;on;webservice;final;or;finally;when;outer;"
			+"where;float;override;while;for;package;yesterday;from;parallel;future;pragma;test;label";
	
	public static final String SFDC_SOBJECTS = "contract;contractchangeevent;order;orderchangeevent;orderitem;orderitemchangeevent;emailtemplatechangeevent;"
			+"campaign;campaignchangeevent;campaignmemberstatuschangeevent;campaignmember;campaignmemberchangeevent;"
			+"account;accountchangeevent;contact;contactchangeevent;lead;leadchangeevent;opportunity;"
			+"opportunitychangeevent;accountcontactrelation;opportunitycontactrole;opportunitycontactrolechangeevent;opportunitylineitem;"
			+"partner;attachment;product2;product2changeevent;asset;assetchangeevent;case;casecomment;casechangeevent;solution;contentversion;"
			+"contentdocument;contentdocumentlink;contentdistribution;note;feeditem;feedcomment;collaborationgroup;collaborationgroupmember;"
			+"task;taskchangeevent;event;eventchangeevent;taskrelationchangeevent;eventrelationchangeevent;networkmember;topicassignment;user;userchangeevent;"
			+"emailmessage;emailmessagechangeevent;individual;individualchangeevent;"
			+"accountcontactrolechangeevent;quote;quotechangeevent;quotelineitem;quotelineitemchangeevent;pricebook2;pricebook2changeevent;idea;"
			+"ideacomment;macro;macrochangeevent;macroinstructionchangeevent;workorder;workorderchangeevent;workorderlineitem;workorderlineitemchangeevent;"
			+"serviceresource;serviceresourcechangeevent;serviceresourceskill;skillrequirement;entitlement;entitlementchangeevent;"
			+"entitlementcontact;entitymilestone;servicecontract;servicecontractchangeevent;contractlineitem;contractlineitemchangeevent;linkedarticle;"
			+"collaborationgrouprecord;streamingchannel;quicktext;quicktextchangeevent;userservicepresence;agentwork;pendingservicerouting;socialpersona;"
			+"socialpost;socialpostchangeevent;assettokenevent;userprovisioningrequest;userprovisioninglog;userprovmocktarget;"
			+"userprovaccount;userprovaccountstaging;profileskill;profileskilluser;profileskillendorsement;workthanks;workbadgedefinition;workbadge;"
			+"duplicaterecordset;duplicaterecorditem;assetrelationship;orglifecyclenotification;caseexternaldocument;logouteventstream;listemailchangeevent;"
			+"agentworkskill;recordaction;airecordinsight;accountbrand;contactrequest;contactpointaddress;contactpointaddresschangeevent;contactpointemail;contactpointemailchangeevent;"
			+"contactpointphone;contactpointphonechangeevent;batchapexerrorevent;appanalyticsqueryrequest;contactpointconsent;contactpointconsentchangeevent;contactpointtypeconsent;"
			+"contactpointtypeconsentchangeevent;datauselegalbasis;datausepurpose;image;platformstatusalertevent;recommendation;recommendationchangeevent;"
			+"aipredictionevent;asyncoperationevent;asyncoperationstatus;authorizationform;"
			+"authorizationformconsent;authorizationformconsentchangeevent;authorizationformdatause;authorizationformtext;macrousage;promptaction;"
			+"quicktextusage;orgmetricscanresult;orgmetricscansummary;commsubscription;commsubscriptionchanneltype;commsubscriptionconsent;"
			+"commsubscriptionconsentchangeevent;commsubscriptiontiming;"
			+"delegatedaccount;engagementchanneltype;partyconsent;";
	
	// UI App Constant
	public static final int UI_PROGRESS_BAR_MAX_VALUE = 2000;
	public static final int UI_PROGRESS_BAR_MIN_VALUE = 0;
	public static final int PROGRESS_BAR_THREAD_DELAY = 200;
	public static final String GENERIC_UI_ERROR_MSG = "An error occured. Please contact admin";
	public static final String PROCESS_COMPLETED_MSG = "Autofix completed";
	public static final String AUTOFIX_SUBMIT_MSG = "Submitted for autofix ...";
	public static final String SELECT_PROPER_PATH_ERROR_MSG = "Please select proper source path and destination";
	public static final String DebugRuleValidation ="You can select only one of the 2 rules to Fix � Comment out or Remove System debug stmts";	

	// Info Related to Rule for UI
	public static final String IF_ELSE_STMTS_MUST_USE_BRACES_INFO = "If Else Statements Must use Braces";
	public static final String FOR_LOOPS_MUST_USE_BRACES_INFO = "For Statements Must use Braces";
	public static final String WHILE_LOOPS_MUST_USE_BRACES_INFO = "While Statements Must use Braces";
	public static final String CLASS_NAMING_CONVENTIONS_INFO = "Class Naming Conventions";
	public static final String VARIABLE_NAMING_CONVENTIONS_INFO = "Static Final Variable Naming Conventions";
	public static final String EMPTY_WHILE_STMT_INFO = "Remove Empty While Statements";
	public static final String EMPTY_IF_STMT_INFO = "Remove Empty If Statements";
	public static final String SYSTEM_DEBUG_VALIDATION_INFO = "Comment out System Debug Statements";
	public static final String SYSTEM_DEBUG_VALIDATION_REMOVE_INFO = "Remove System Debug Statements";
	public static final String SOQL_WITHOUT_LIMIT_INFO = "SOQL statements must have WHERE or LIMIT clause defined";
	public static final String APEX_UNIT_TEST_METHOD_RULE_INFO = "Apex Unit Test methods should have @isTest annotation";
	public static final String USE_COLLECTION_IS_EMPTY_INFO = "Use Collection IsEmpty method instead of size method";
	public static final String REMOVE_EMPTY_TRYFINALLY_INFO = "Remove Empty Try/Finally block";
	public static final String AVOID_HARDCODED_STRING_INFO = "Remove Hardcoded String";
	public static final String API_VERSION_UPGRADE_XML = "Upgrade the API version for XML";
	public static final String UPDATE_BOOLEAN_CHECK = "Avoid unnecessary comparisons in boolean expressions";
	public static final String SOQL_SECURITY_ENFORCED = "SOQL statements must have enforced security";
	public static final String UNUSED_LOCAL_VARIABLE = "Remove unused local variables";
	public static final String UNUSED_PRIVATE_METHOD = "Comment out Unused Private Method";
	public static final String NULL_CHECK_BEFORE_DML = "Perform ISNULL before DML Operation";
	public static final String SYSTEM_DEBUG_ERROR_MESSAGE= "Please select any one rule, \"Comment out\" or \"Remove\" System Debug Statements";
	public static final String LOOP_ERROR_MESSAGE=  "Please select  '"+IF_ELSE_STMTS_MUST_USE_BRACES_INFO +"'  ,  '"+FOR_LOOPS_MUST_USE_BRACES_INFO+ "'  and  '"+WHILE_LOOPS_MUST_USE_BRACES_INFO +"'  "     
			+"Rule , if you are selecting  '"+SYSTEM_DEBUG_VALIDATION_INFO+ "'  OR  '"+SYSTEM_DEBUG_VALIDATION_REMOVE_INFO+"'" +"  Rule to fix";
	public static final String TOTAL_SELECTED_ERROR_MESSAGE=  "Please select minimum 1 rule to fix";
	public static final String API_XML_VERSION_MESSAGE = "Please select "+API_VERSION_UPGRADE_XML;

	// Force Reviewer Panel Constants
	public static final Rectangle FR_PANEL_BOUNDS = new Rectangle(250, 50, 450, 400);

	//Info related to CSV file creation
	public static final String[] CSV_HEADER_LINE = {"File Name", "Rule Name", "Before Fix", "After Fix"};

	//Rules for HTML,CSS,JS
	public static final String AVOID_EMPTY_BLOCKS_CSS_INFO = "Empty blocks should be removed for CSS";
	public static final String REMOVE_EXTRA_SEMICOLON_JS_INFO = "Remove extra semicolon from js";
	public static final String REMOVE_EXTRA_SEMICOLON_CSS_INFO = "Remove extra semicolon from CSS";
	public static final String REMOVE_DEBUGGER_INFO = "Remove Debugger Statements from JS";
	public static final String GENERIC_FONT_FAMILY = "Font family should contain atleast one generic font family";
	public static final String AVOID_DUPLICATE_PROPERTIES_CSS_INFO = "Properties should not be duplicated";
	public static final String UNDEFINED_ASSIGNMENT = "'undefined' should not be assigned";
	public static final String REMOVE_ALERT_INFO = "Remove Alert Statements from JS";
	public static final String AVOID_USING_GLOBAL_THIS_JS = "Global this object should not be used";
	public static final String REMOVE_UNUSED_VARIABLES_JS = "Remove unused variables";
	public static final String UNNECESSARY_IMPORTS_JS = "Unnecessary imports should be removed";
	public static final String REMOVE_EMPTYPROPERTIES_CSS = "Empty Properties should be removed";



	//Rule Category
	public static final String APEX_CATEGORY = "Apex";
	public static final String AURA_LWC_CATEGORY = "Aura/LWC (Beta)";

	//Related to plugin
	public static final String AUTO_FIX_WORKSPACE = "AUTO_FIX_WORKSPACE";
	public static final String AUTO_FIX_EXTENSION = "AUTO_FIX_EXTENSION";
	public static final String AUTO_FIX_EXTENSION_API_AVAILABLE = "AUTO_FIX_EXTENSION_API_AVAILABLE";
	public static final String AUTO_FIX_EXTENSION_API_VERSION = "AUTO_FIX_EXTENSION_API_VERSION";


}
