package org.autofix.rules;

import java.util.List;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

public class ClassNamingRule implements IFRRules{

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {

		String newClsName="";
		boolean isFixRequired = true;
		ViolationInfo info;
		for(int i=0; i< allLines.size();i++){			
			if(allLines.get(i).contains("@AuraEnabled") || allLines.get(i).contains("@InvocableMethod")){
				int j = i+1;
				int k= j+4;
				while(j<k){
					if(allLines.get(j).contains("(") && allLines.get(j).contains(")") && !allLines.get(j).endsWith(";")){
						isFixRequired=false;
						break;
					}
					else if(allLines.get(j).endsWith(";")){
						break;
					}
					j++;
				}
			}
			if(!isFixRequired){
				break;
			}
		}
		if(!isFixRequired){
			return;
		}

		for(Violation violation : violationLst){
			info = new ViolationInfo(fileName, violation.getRule());
			System.out.println("Rule :: "+violation.getRule()+" BeginCol :: "+violation.getBegincolumn().intValue());
			String line = allLines.get(violation.getBeginline().intValue()-1);
			info.setBeforeFix(line);
			int endIndx=0;
			if(line.contains("{")){
				endIndx = line.indexOf("{");
			}
			String clsNm;
			if(endIndx>0){
				clsNm = line.substring(violation.getBegincolumn().intValue()-1, endIndx).trim();						
			}
			else{
				clsNm = line.substring(violation.getBegincolumn().intValue()-1).trim();
			}
			newClsName = clsNm.substring(0, 1).toUpperCase() + clsNm.substring(1);	
			line = line.replace(clsNm, newClsName);				
			allLines.set(violation.getBeginline().intValue()-1, line);
			info.setAfterFix(line);
			Reporting.violationInfos.add(info.toCSVRow());

			String reference1 = clsNm+" ";
			String reference2 = " "+clsNm+" (";
			String reference3 = " "+clsNm+"(";

			for(int i=violation.getBeginline().intValue(); i<allLines.size(); i++){
				String lineForReferenceCheck = allLines.get(i);
				if(lineForReferenceCheck.toLowerCase().contains(reference1.toLowerCase())){
					info = new ViolationInfo(fileName, violation.getRule());
					info.setBeforeFix(lineForReferenceCheck);
					lineForReferenceCheck=lineForReferenceCheck.replace(reference1,  newClsName+" ");
					allLines.set(i, lineForReferenceCheck);
					info.setAfterFix(lineForReferenceCheck);
					Reporting.violationInfos.add(info.toCSVRow());
				}
				if(lineForReferenceCheck.toLowerCase().contains(reference2.toLowerCase())){
					info = new ViolationInfo(fileName, violation.getRule());
					info.setBeforeFix(lineForReferenceCheck);
					lineForReferenceCheck=lineForReferenceCheck.replace(reference2,  " "+newClsName+" (");
					allLines.set(i, lineForReferenceCheck);
					info.setAfterFix(lineForReferenceCheck);
					Reporting.violationInfos.add(info.toCSVRow());
				}
				if(lineForReferenceCheck.toLowerCase().contains(reference3.toLowerCase())){
					info = new ViolationInfo(fileName, violation.getRule());
					info.setBeforeFix(lineForReferenceCheck);
					lineForReferenceCheck=lineForReferenceCheck.replace(reference3,  " "+newClsName+"(");
					allLines.set(i, lineForReferenceCheck);
					info.setAfterFix(lineForReferenceCheck);
					Reporting.violationInfos.add(info.toCSVRow());
				}
			}
		}
		// For Loop End
	}
}
