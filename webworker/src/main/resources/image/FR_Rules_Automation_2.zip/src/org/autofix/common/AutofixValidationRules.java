package org.autofix.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.main.AutoFixUtilMain;
import org.autofix.model.AutofixRuleSetting;
import org.autofix.model.Autofix_Rule;

public class AutofixValidationRules {

	private static Map<String,Boolean> validationRuleMap = new HashMap<>();
	private static List<String> allSelectedCustomValidation = new ArrayList<>();
	private static List<String> allSelectedPmdValidation = new ArrayList<>();
	private static List<Autofix_Rule> frRuleSettings = new ArrayList<>();
	private static List<String> xmlValidationRule = new ArrayList<>();
	private static List<String> cssValidationRule = new ArrayList<>();
	private static List<String> jsValidationRule = new ArrayList<>();

	static{
		for(AutofixRuleSetting setting : AutofixConfig.getAllAutofixRuleSettings()){
			frRuleSettings.add(setting.getAutoFixRule());
		}
		/*// Iteration 1
		Autofix_Rule rule2 = new Autofix_Rule(PMDValidationRules.FOR_LOOPS_MUST_USE_BRACES, AppConstants.FOR_LOOPS_MUST_USE_BRACES_INFO, 1, 2, true,true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule3 = new Autofix_Rule(PMDValidationRules.WHILE_LOOPS_MUST_USE_BRACES, AppConstants.WHILE_LOOPS_MUST_USE_BRACES_INFO, 1, 3, true,true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule4 = new Autofix_Rule(PMDValidationRules.IF_ELSE_STMTS_MUST_USE_BRACES, AppConstants.IF_ELSE_STMTS_MUST_USE_BRACES_INFO, 1, 4, true,true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule5 = new Autofix_Rule(PMDValidationRules.VARIABLE_NAMING_CONVENTIONS, AppConstants.VARIABLE_NAMING_CONVENTIONS_INFO, 1, 5, true,true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule6 = new Autofix_Rule(CustomValidationRules.APEX_UNIT_TEST_METHOD_RULE, AppConstants.APEX_UNIT_TEST_METHOD_RULE_INFO, 1, 6, true, false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule11 = new Autofix_Rule(CustomValidationRules.USE_COLLECTION_IS_EMPTY, AppConstants.USE_COLLECTION_IS_EMPTY_INFO, 1, 7, true, false, AppConstants.APEX_CATEGORY);
		//FR_Rule rule11 = new FR_Rule(CustomValidationRules.RECORD_TYPE_INFO_BY_DEVELOPER_NAME_RULE, "Testing", 1, 7, true, false);
		Autofix_Rule rule13 = new Autofix_Rule(CustomValidationRules.SOQL_STMT_VALIDATION, AppConstants.SOQL_WITHOUT_LIMIT_INFO, 1, 8, true, false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule15 = new Autofix_Rule(CustomValidationRules.API_VERSION_UPGRADE_XML, AppConstants.API_VERSION_UPGRADE_XML, 1, 9, false,false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule16 = new Autofix_Rule(CustomValidationRules.UPDATE_BOOLEAN_CHECK, AppConstants.UPDATE_BOOLEAN_CHECK, 1, 10, true, false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule31 = new Autofix_Rule(CustomValidationRules.UNUSED_PRIVATE_METHOD, AppConstants.UNUSED_PRIVATE_METHOD, 1, 11, false,false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule32 = new Autofix_Rule(CustomValidationRules.NULL_CHECK_BEFORE_DML, AppConstants.NULL_CHECK_BEFORE_DML, 1, 11, true, false, AppConstants.APEX_CATEGORY);

		// Iteration 2
		Autofix_Rule rule7 = new Autofix_Rule(CustomValidationRules.SYSTEM_DEBUG_VALIDATION, AppConstants.SYSTEM_DEBUG_VALIDATION_INFO, 2, 1, true,false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule8 = new Autofix_Rule(CustomValidationRules.SYSTEM_DEBUG_VALIDATION_REMOVE, AppConstants.SYSTEM_DEBUG_VALIDATION_REMOVE_INFO, 2, 2, false,false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule30 = new Autofix_Rule(PMDValidationRules.UNUSED_LOCAL_VARIABLE, AppConstants.UNUSED_LOCAL_VARIABLE, 2, 3, true,true, AppConstants.APEX_CATEGORY);
		// Iteration 3
		Autofix_Rule rule9 = new Autofix_Rule(PMDValidationRules.EMPTY_IF_STMT, AppConstants.EMPTY_IF_STMT_INFO, 3, 1, true,true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule10 = new Autofix_Rule(PMDValidationRules.EMPTY_WHILE_STMT, AppConstants.EMPTY_WHILE_STMT_INFO, 3, 2, true,true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule12 = new Autofix_Rule(PMDValidationRules.EMPTY_TRY_OR_FINALLY_BLOCK, AppConstants.REMOVE_EMPTY_TRYFINALLY_INFO, 3, 3, true, true, AppConstants.APEX_CATEGORY);
		//Iteration 4
		Autofix_Rule rule14 = new Autofix_Rule(CustomValidationRules.AVOID_HARDCODED_STRING, AppConstants.AVOID_HARDCODED_STRING_INFO, 4, 1, true, false, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule1 = new Autofix_Rule(PMDValidationRules.CLASS_NAMING_CONVENTIONS, AppConstants.CLASS_NAMING_CONVENTIONS_INFO, 4, 2, true, true, AppConstants.APEX_CATEGORY);
		Autofix_Rule rule28 = new Autofix_Rule(CustomValidationRules.SOQL_SECURITY_ENFORCED, AppConstants.SOQL_SECURITY_ENFORCED, 4, 3, true, false, AppConstants.APEX_CATEGORY);

		//Iteration 5
		Autofix_Rule rule17 = new Autofix_Rule(CustomValidationRules.AVOID_EMPTY_BLOCKS_CSS, AppConstants.AVOID_EMPTY_BLOCKS_CSS_INFO, 5, 1, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule19 = new Autofix_Rule(CustomValidationRules.REMOVE_EXTRA_SEMICOLON_CSS, AppConstants.REMOVE_EXTRA_SEMICOLON_CSS_INFO, 5, 2, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule21 = new Autofix_Rule(CustomValidationRules.GENERIC_FONT_FAMILY, AppConstants.GENERIC_FONT_FAMILY, 5, 3, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule18 = new Autofix_Rule(CustomValidationRules.REMOVE_EXTRA_SEMICOLON_JS, AppConstants.REMOVE_EXTRA_SEMICOLON_JS_INFO, 5, 4, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule24 = new Autofix_Rule(CustomValidationRules.AVOID_USING_GLOBAL_THIS_JS, AppConstants.AVOID_USING_GLOBAL_THIS_JS, 5, 5, false, false, AppConstants.AURA_LWC_CATEGORY);

		
		//Iteration 6
		Autofix_Rule rule20 = new Autofix_Rule(CustomValidationRules.DEBUGGER_CHECK_JS, AppConstants.REMOVE_DEBUGGER_INFO, 6, 1, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule22 = new Autofix_Rule(CustomValidationRules.AVOID_DUPLICATE_PROPERTIES_CSS, AppConstants.AVOID_DUPLICATE_PROPERTIES_CSS_INFO, 6, 2, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule23 = new Autofix_Rule(CustomValidationRules.UNDEFINED_ASSIGNMENT, AppConstants.UNDEFINED_ASSIGNMENT, 6, 3, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule25 = new Autofix_Rule(CustomValidationRules.REMOVE_ALERT_JS, AppConstants.REMOVE_ALERT_INFO, 6, 4, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule26 = new Autofix_Rule(CustomValidationRules.REMOVE_UNUSED_VARIABLES_JS, AppConstants.REMOVE_UNUSED_VARIABLES_JS, 6, 5, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule27 = new Autofix_Rule(CustomValidationRules.UNNECESSARY_IMPORTS_JS, AppConstants.UNNECESSARY_IMPORTS_JS, 6, 6, false, false, AppConstants.AURA_LWC_CATEGORY);
		Autofix_Rule rule29 = new Autofix_Rule(CustomValidationRules.REMOVE_EMPTY_PROPERTIES_CSS, AppConstants.REMOVE_EMPTYPROPERTIES_CSS, 6, 7, false, false, AppConstants.AURA_LWC_CATEGORY);


		// Add in FR Rule List
		frRuleSettings.add(rule2);
		frRuleSettings.add(rule3);
		frRuleSettings.add(rule4);
		frRuleSettings.add(rule5);
		frRuleSettings.add(rule6);
		frRuleSettings.add(rule7);
		frRuleSettings.add(rule8);
		frRuleSettings.add(rule9);
		frRuleSettings.add(rule10);
		frRuleSettings.add(rule11);
		frRuleSettings.add(rule12);
		frRuleSettings.add(rule13);
		frRuleSettings.add(rule14);
		frRuleSettings.add(rule1);
		frRuleSettings.add(rule15);
		frRuleSettings.add(rule16);
		frRuleSettings.add(rule17);
		frRuleSettings.add(rule18);
		frRuleSettings.add(rule19);
		frRuleSettings.add(rule20);
		frRuleSettings.add(rule21);
		frRuleSettings.add(rule22);
		frRuleSettings.add(rule23);
		frRuleSettings.add(rule24);
		frRuleSettings.add(rule25);
		frRuleSettings.add(rule26);
		frRuleSettings.add(rule27);
		frRuleSettings.add(rule28);
		frRuleSettings.add(rule29);
		frRuleSettings.add(rule30);
		frRuleSettings.add(rule31);
		frRuleSettings.add(rule32);*/

		for(String s : AppConstants.getAllPmdValidationName()){
			validationRuleMap.put(s, true);
			allSelectedPmdValidation.add(s);
		}
		for(String s : AppConstants.getAllCustomValidationName()){
			validationRuleMap.put(s, true);
			allSelectedCustomValidation.add(s);
		}
		
		xmlValidationRule = Arrays.asList(CustomValidationRules.API_VERSION_UPGRADE_XML);
		cssValidationRule = Arrays.asList(CustomValidationRules.AVOID_EMPTY_BLOCKS_CSS,CustomValidationRules.REMOVE_EXTRA_SEMICOLON_CSS, CustomValidationRules.GENERIC_FONT_FAMILY, CustomValidationRules.AVOID_DUPLICATE_PROPERTIES_CSS,CustomValidationRules.REMOVE_EMPTY_PROPERTIES_CSS);
		jsValidationRule=Arrays.asList(CustomValidationRules.REMOVE_EXTRA_SEMICOLON_JS,CustomValidationRules.DEBUGGER_CHECK_JS,CustomValidationRules.UNDEFINED_ASSIGNMENT,CustomValidationRules.REMOVE_ALERT_JS,CustomValidationRules.AVOID_USING_GLOBAL_THIS_JS,CustomValidationRules.REMOVE_UNUSED_VARIABLES_JS, CustomValidationRules.UNNECESSARY_IMPORTS_JS);
	}

	public static List<Autofix_Rule> getFrRuleSettings(){
		return new ArrayList<>(frRuleSettings);
	}

	public static void frRuleSettingUpdated(){
		for(Autofix_Rule rule : frRuleSettings){
			validationRuleMap.put(rule.getUniqueRuleName(), rule.isSelected());
		}
		updateSelectedCustomValidation();
		updateSelectedPMDValidation();
	}

	
	public static void updateSelected(String ruleName, Boolean status) throws CustomException{
		if(validationRuleMap.get(ruleName) == null){
			throw new CustomException("Rule Name doesn't exist :: "+ruleName);
		}
		validationRuleMap.put(ruleName, status);
	}

	public static void updateSelected(Map<String,Boolean> ruleStatusMap){
		for(String ruleName : ruleStatusMap.keySet()){
			if(validationRuleMap.get(ruleName) != null){
				validationRuleMap.put(ruleName, ruleStatusMap.get(ruleName));
			}
		}
		updateSelectedCustomValidation();
		updateSelectedPMDValidation();
	}

	private static void updateSelectedCustomValidation(){
		allSelectedCustomValidation = new ArrayList<>();
		for(String ruleName : AppConstants.getAllCustomValidationName()){
			if(validationRuleMap.get(ruleName)){
				allSelectedCustomValidation.add(ruleName);
			}
		}
	}

	private static void updateSelectedPMDValidation(){
		allSelectedPmdValidation = new ArrayList<>();
		for(String ruleName : AppConstants.getAllPmdValidationName()){
			if(validationRuleMap.get(ruleName)){
				allSelectedPmdValidation.add(ruleName);
			}
		}
	}

	public static Map<String, Boolean> getValidationRuleMap(){
		return new HashMap<>(validationRuleMap);
	}

	public static Boolean isRuleSelectedByUser(String ruleName){
		if(AutoFixUtilMain.boolIsRunningFromAutoFixExtension){
			return AutoFixUtilMain.selectedRulesFromExtn.contains(ruleName);
		} else {
			return validationRuleMap.get(ruleName);
		}
	}

	public static List<String> getAllSelectedCustomValidation(){
		return new ArrayList<>(allSelectedCustomValidation);
	}

	public static List<String> getAllSelectedPMDValidation(){
		return new ArrayList<>(allSelectedPmdValidation);
	}

	public static void verifySelectedRules() throws CustomException{
		if(isRuleSelectedByUser(CustomValidationRules.SYSTEM_DEBUG_VALIDATION) && 
				isRuleSelectedByUser(CustomValidationRules.SYSTEM_DEBUG_VALIDATION_REMOVE)){
			updateSelected(CustomValidationRules.SYSTEM_DEBUG_VALIDATION, false);
		}
	}

	public static Map<Integer, List<Autofix_Rule>> getSelectedFRRuleSettingsMap(){
		return frRuleSettings.stream()
				.filter(f->f.isSelected())
				.collect(Collectors.groupingBy(Autofix_Rule::getIteration_order));
	}
	
	public static List<String> getXmlValidationRule(){
		return xmlValidationRule;
	}
	
	public static List<String> getCssValidationRule(){
		return cssValidationRule;
	}
	
	public static List<String> getJsValidationRule(){
		return jsValidationRule;
	}

}
