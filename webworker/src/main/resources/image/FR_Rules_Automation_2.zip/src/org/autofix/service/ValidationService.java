package org.autofix.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.autofix.common.ApplicationParameter;
import org.autofix.common.CustomException;
import org.autofix.common.AutofixConfig;
import org.autofix.common.AutofixValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.FileUtility;
import org.autofix.utility.Logging;

public class ValidationService {

	private static Map<String, List<Violation>> fileToViolationMap;
	private static List<String> allApexClassFileName;
	private static List<String> allXmlFileName;
	private static List<String> allCssFileName;
	private static List<String> allJsFileName;

	static{
		try {
			AutofixConfig.initFrValidation();
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Logging.log(e);
		}
	}

	public static void init() throws IOException{
		allApexClassFileName = FileUtility.getAllApexClassFileName(ApplicationParameter.getLocalSourceFolderName());
		allXmlFileName = FileUtility.getAllXmlFileNames(ApplicationParameter.getLocalSourceFolderName());
		allCssFileName = FileUtility.getAllCssFileNames(ApplicationParameter.getLocalSourceFolderName());
		allJsFileName  = FileUtility.getAllJsFileNames(ApplicationParameter.getLocalSourceFolderName());
	}

	public static List<File> runValidationRules() throws IOException, CustomException {
		fileToViolationMap = new HashMap<>();
		List<String> fileNameLst = FileUtility.getAllApexClassFileName(ApplicationParameter.getLocalSourceFolderName());
		for(String name : AutofixValidationRules.getAllSelectedCustomValidation()){
			updateFileToViolationMap(AutofixConfig.getFRValidation(name).runValidation(fileNameLst));
		}
		return getInvalidFiles();
	}

	public static List<File> runValidationRules(List<String> customValidationRuleName) throws IOException, CustomException{
		fileToViolationMap = new HashMap<>();
		List<String> xmlValidationRule = AutofixValidationRules.getXmlValidationRule();
		List<String> cssValidationRule = AutofixValidationRules.getCssValidationRule();
		List<String> jsValidationRule = AutofixValidationRules.getJsValidationRule();
		for(String name : customValidationRuleName){
			if(xmlValidationRule.contains(name)){
				updateFileToViolationMap(AutofixConfig.getFRValidation(name).runValidation(allXmlFileName));
			}else if(cssValidationRule.contains(name)){
				updateFileToViolationMap(AutofixConfig.getFRValidation(name).runValidation(allCssFileName));
			}else if(jsValidationRule.contains(name)){
				updateFileToViolationMap(AutofixConfig.getFRValidation(name).runValidation(allJsFileName));
			}
			else{
				updateFileToViolationMap(AutofixConfig.getFRValidation(name).runValidation(allApexClassFileName));
			}
			
		}
		return getInvalidFiles();
	}

	private static void updateFileToViolationMap(List<File> fileLst){
		if(fileLst != null && !fileLst.isEmpty()){
			for(File file : fileLst){
				if(!file.getViolation().isEmpty()){
					if(fileToViolationMap.get(file.getName()) == null){
						fileToViolationMap.put(file.getName(), new ArrayList<>());
					}
					fileToViolationMap.get(file.getName()).addAll(file.getViolation());
				}
			}
		}
	}

	private static List<File> getInvalidFiles(){
		List<File> invalidFiles = new ArrayList<>();
		File tempFile;
		for(String fileName : fileToViolationMap.keySet()){
			tempFile = new File();
			tempFile.setName(fileName);
			tempFile.getViolation().addAll(fileToViolationMap.get(fileName));
			invalidFiles.add(tempFile);
		}
		return invalidFiles;
	}

}