package org.autofix.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBException;

import org.autofix.codeFormatter.BasicApexFormatter;
import org.autofix.common.ApplicationParameter;
import org.autofix.common.AutofixConfig;
import org.autofix.common.AutofixValidationRules;
import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.PMDValidationRules;
import org.autofix.main.AutoFixUtilMain;
import org.autofix.model.Autofix_Rule;
import org.autofix.model.File;
import org.autofix.model.Pmd;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.AppUtility;
import org.autofix.utility.AutofixUIUtility;
import org.autofix.utility.FileUtility;
import org.autofix.utility.Logging;
import org.autofix.utility.PMDUtility;
import org.autofix.utility.Reporting;

import net.sourceforge.pmd.ruleset._2_0.Rule;
import net.sourceforge.pmd.ruleset._2_0.Ruleset;

/**
 * This is service class for Auto-Fix Application
 * Below are covered in this class
 * 	1> Copy all Source Files to localSource folder.
 * 	2> Based on User Selected Rules Fire PMD and Validation Rules.
 * 	3> Once all Invalid Files received, process each file and call the respective Rules for fixing the violation.
 * 	4> Repeat steps 2 and 3 for each iteration.
 * 	5> All Rules will fix the violation of files in localSource folder
 * 	6> Once all iteration finished copy the required files from localSource folder to Destination folder.
 * @author  Laltu Banerjee
 * @version 1.0
 * @since   2020-04-23
 */

public class AutofixService implements Runnable{

	private String srcFolder;
	private String srcFilePath;
	private String destFoler;
	private CodeFormatterService formatterService;
	static{
		try {
			// Initialize all configured Rule classes
			AutofixConfig.initFRConfig();
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
			e.printStackTrace();
			Logging.log(e);
		}
	}

	public AutofixService(String srcFolderpath) {
		this.srcFolder = srcFolderpath;
		this.destFoler = srcFolderpath;
		this.formatterService = new CodeFormatterService(this.destFoler);
		AutofixUIUtility.setUserSelectedSrcPath(srcFolderpath);
		AutofixUIUtility.setUserSelectedDestPath(srcFolderpath);
	}

	public AutofixService(String srcFilePath, String destFolderPath) {
		if(AutoFixUtilMain.boolIsRunningFromAutoFixExtension){
			this.srcFilePath = srcFilePath;
			this.destFoler = destFolderPath;
			//runApexBasicFormatter(this.srcFilePath);
			this.formatterService = new CodeFormatterService(this.destFoler);
			AutofixUIUtility.setUserSelectedSrcPath(srcFilePath);
			AutofixUIUtility.setUserSelectedDestPath(destFolderPath);

		} else  {
			this.srcFolder = srcFilePath;
			this.destFoler = destFolderPath;
			//runApexBasicFormatter(this.srcFolder);
			this.formatterService = new CodeFormatterService(this.destFoler);
			AutofixUIUtility.setUserSelectedSrcPath(srcFilePath);
			AutofixUIUtility.setUserSelectedDestPath(destFolderPath);
		}
	}

	@Override
	public void run() {
		long startTime = new Date().getTime();
		try {
			initFrAutomationRule();
			AutofixUIUtility.addMessage(AppConstants.PROCESS_COMPLETED_MSG);
			AutofixUIUtility.updateUIProgressBar(AppConstants.UI_PROGRESS_BAR_MAX_VALUE);
		} catch (Exception e) {
			AutofixUIUtility.updateUIProgressBar(AppConstants.UI_PROGRESS_BAR_MAX_VALUE);
			Logging.log(e);
		} finally {
			if(AutoFixUtilMain.boolIsRunningFromAutoFixExtension){
				ApplicationParameter.deleteTempFolder();
			}
		}
		long endTime = new Date().getTime();
		Logging.log("Process Took "+(endTime-startTime)/(1000)+" seconds to complete");
	}

	/**
	 * copy all files from source folder to local source folder
	 * @throws IOException
	 */
	private void copySourceFilesToCurrentDirectory() throws IOException{
		if(AutoFixUtilMain.boolIsRunningFromAutoFixExtension){
			if(AutoFixUtilMain.boolRunOnFolder){
				java.io.File sourceFolder = new java.io.File(this.srcFolder);
				java.io.File localSourceFolder = new java.io.File(ApplicationParameter.getLocalSourceFolderPath());
				// Delete all Files from Local Source Folder
				FileUtility.deleteAllFiles(ApplicationParameter.getLocalSourceFolderPath());
				// Move all files from srcFolder to localsrcFolder
				FileUtility.copyFolder(sourceFolder, localSourceFolder);
				// set source folder as localSourceFolder
				this.srcFolder = ApplicationParameter.getLocalSourceFolderPath();
			} else {
				java.io.File sourceFolder = new java.io.File(this.srcFilePath);
				java.io.File localSourceFolder = new java.io.File(ApplicationParameter.getLocalSourceFolderPath());
				// Delete all Files from Local Source Folder
				FileUtility.deleteAllFiles(ApplicationParameter.getLocalSourceFolderPath());
				// Move all files from srcFolder to localsrcFolder
				FileUtility.copyFile(srcFilePath, localSourceFolder.getPath(), true);
				// Move the MetaXMl File to localSourceFolder
				FileUtility.copyFile(srcFilePath+"-meta.xml", localSourceFolder.getPath(), true);
				// set source folder as localSourceFolder
				this.srcFolder = ApplicationParameter.getLocalSourceFolderPath();
			}

		} else {
			java.io.File sourceFolder = new java.io.File(this.srcFolder);
			java.io.File localSourceFolder = new java.io.File(ApplicationParameter.getLocalSourceFolderPath());
			// Delete all Files from Local Source Folder
			FileUtility.deleteAllFiles(ApplicationParameter.getLocalSourceFolderPath());
			// Move all files from srcFolder to localsrcFolder
			FileUtility.copyFolder(sourceFolder, localSourceFolder);
			// set source folder as localSourceFolder
			this.srcFolder = ApplicationParameter.getLocalSourceFolderPath();
		}
	}

	/**
	 * Create a TempApexRules.xml file based on user selected PMD rules
	 * @param selectedPmdRules
	 * @throws JAXBException
	 * @throws FileNotFoundException
	 */
	private void preProcessBeforeRunningRules(List<String> selectedPmdRules) throws JAXBException, FileNotFoundException{
		if(!selectedPmdRules.isEmpty()){
			Ruleset ruleset = AppUtility.getObject(ApplicationParameter.getPmdRulePath(), Ruleset.class);
			List<Rule> userSelectedRules = new ArrayList<>();
			for(Rule rule : ruleset.getRule()){
				if(selectedPmdRules.contains(rule.getName())){
					userSelectedRules.add(rule);
				}
			}
			ruleset.setRule(userSelectedRules);
			AppUtility.writeXmlToFileFromObject(ruleset, Ruleset.class, ApplicationParameter.getTempPmdRulePath());
		}
	}

	/**
	 * Get all files (org.fpr.model.File) where we need to run our Rules.
	 * @param selectedPMDRules
	 * @param selectedCustomValidationRules
	 * @return
	 * @throws IOException
	 * @throws JAXBException
	 * @throws CustomException
	 */
	public List<File> getInvalidFiles(List<String> selectedPMDRules, List<String> selectedCustomValidationRules) throws IOException, JAXBException, CustomException{
		List<File> invalidFiles = new ArrayList<>();
		List<File> pmdInvalidFiles = new ArrayList<>();
		List<File> customValidationInvalidFiles = new ArrayList<>();
		// get all required org.fpr.model.File from PMD tool
		if(!selectedPMDRules.isEmpty()){
			pmdInvalidFiles = PMDUtility.scanSourceFolder(this.srcFolder);
		}

		if(!selectedCustomValidationRules.isEmpty()){
			customValidationInvalidFiles = ValidationService.runValidationRules(selectedCustomValidationRules);
			// Create a CustomValidationReport in ApplicationParameter.getCustomValidationReportPath() for reference
			Pmd customValidationPMD = new Pmd();
			customValidationPMD.getFile().addAll(customValidationInvalidFiles);
			FileUtility.writeToFile(AppUtility.getFormattedJson(customValidationPMD, Pmd.class), ApplicationParameter.getCustomValidationReportPath());
		}
		// Here we need to merge pmdInvalidFiles and customValidationInvalidFiles
		// Such that two org.fpr.model.File with same name must exist as single record
		// in invalidFiles. We need to copy the violations from one org.fpr.model.File object
		// to another org.fpr.model.File object if File.getName() is Same.
		if(!pmdInvalidFiles.isEmpty() && !customValidationInvalidFiles.isEmpty()){
			Map<String, List<Violation>> customValidationMap  = customValidationInvalidFiles
					.stream()
					.collect(Collectors.toMap(File::getName, File::getViolation));
			Set<String> customValidationKeySet = customValidationMap.keySet();
			for(File file : pmdInvalidFiles){
				if(customValidationKeySet.contains(file.getName())){
					file.getViolation().addAll(customValidationMap.get(file.getName()));
					customValidationKeySet.remove(file.getName());
				}
				invalidFiles.add(file);
			}
			// If any data exist in customValidationKeySet that means
			// file name doesn't matches for that record. Add it
			// in invalidFiles.
			File tempFile;
			for(String fileName : customValidationKeySet){
				tempFile = new File();
				tempFile.setName(fileName);
				tempFile.getViolation().addAll(customValidationMap.get(fileName));
				invalidFiles.add(tempFile);
			}
		}
		else if(!pmdInvalidFiles.isEmpty()){
			invalidFiles.addAll(pmdInvalidFiles);
		}
		else if(!customValidationInvalidFiles.isEmpty()){
			invalidFiles.addAll(customValidationInvalidFiles);
		}
		return invalidFiles;
	}

	/**
	 * Below Method is the brain of Auto-Fix application
	 * It controls the flow of application.
	 */
	public void initFrAutomationRule(){
		try{
			Reporting.initiateReportPreq();
			List<File> allInvalidFiles = new ArrayList<>();
			List<File> currentIterationInvalidFiles = new ArrayList<>();
			List<String> selectedPMDRules;
			List<String> selectedCustomValidationRules;
			// Move all Files from Source to LocalSource Folder
			copySourceFilesToCurrentDirectory();
			AutofixUIUtility.updateUIProgressBar(100);
			// Init Validation service
			ValidationService.init();
			// Get all FRRuleSetting Mapped by iteration
			Map<Integer, List<Autofix_Rule>> frRuleSettingsMap = AutofixValidationRules.getSelectedFRRuleSettingsMap();

			// Get the Keys of frRuleSettingsMap in ascending order
			List<Integer> sortedIterationLst = frRuleSettingsMap.keySet()
					.stream().sorted((i1,i2)->i1.compareTo(i2))
					.collect(Collectors.toList());
			// Calculate the percentage completion of progress-bar for each Iteration
			double progressBarIncrementalValPerIteration = AutofixUIUtility.getProgressBarIncrementalValPerIteration(sortedIterationLst.size());
			double progressBarIncrementalValPerFile;
			// Start of For Loop for each Iteration
			for(Integer iteration : sortedIterationLst){
				System.out.println("Current Iteration "+iteration);
				// get all selected PMD Rules in current Iteration
				selectedPMDRules = frRuleSettingsMap.get(iteration)
						.stream()
						.filter(r->r.isPMDRule()&&r.isSelected())
						.map(r->r.getUniqueRuleName())
						.collect(Collectors.toList());
				// get all selected custom validation rules in current Iteraton
				selectedCustomValidationRules = frRuleSettingsMap.get(iteration)
						.stream()
						.filter(r->(!r.isPMDRule())&&r.isSelected())
						.map(r->r.getUniqueRuleName())
						.collect(Collectors.toList());
				System.out.println(" selectedPMDRules :: "+selectedPMDRules);
				System.out.println(" selectedCustomValidationRules :: "+selectedCustomValidationRules);
				preProcessBeforeRunningRules(selectedPMDRules);
				// get all Invalid Files for Current Iteration
				currentIterationInvalidFiles = getInvalidFiles(selectedPMDRules,selectedCustomValidationRules);
				if(!currentIterationInvalidFiles.isEmpty()){
					// Calculate Progress bar incremental value for each file in this iteration
					progressBarIncrementalValPerFile = progressBarIncrementalValPerIteration/currentIterationInvalidFiles.size();
					// To keep track of all Invalid files
					allInvalidFiles.addAll(currentIterationInvalidFiles);
					// Ordering the rules in execution order
					List<String> orderedRulesByExecutionOrder = frRuleSettingsMap.get(iteration)
							.stream()
							.sorted((r1,r2)->r1.getExecution_order()-r2.getExecution_order())
							.map(r->r.getUniqueRuleName())
							.collect(Collectors.toList());
					System.out.println(" orderedRulesByExecutionOrder :: "+orderedRulesByExecutionOrder);
					// Iterate through each Invalid File
					for(File file : currentIterationInvalidFiles){
						try{
							runFRRuletoFile(file,orderedRulesByExecutionOrder);
						}catch(Exception err){
							err.printStackTrace();
							Logging.log(err);
						}
						AutofixUIUtility.updateUIProgressBar(progressBarIncrementalValPerFile);
					}
				}else{
					AutofixUIUtility.updateUIProgressBar(progressBarIncrementalValPerIteration);
				}
			}
			//change the name of file for ClassNamingViolation
			changeClassName(allInvalidFiles);
			// get File name for each Invalid Files
			List<String> allInvalidFileNamesWithPath = allInvalidFiles.stream()
					.map(f->f.getName())
					.distinct()
					.collect(Collectors.toList());
			System.out.println("allInvalidFileNamesWithPath :: "+allInvalidFileNamesWithPath);

			// copy all invalid files to detination Folder
			FileUtility.copyFilesToDestinaionFolder(allInvalidFileNamesWithPath, this.destFoler, this.srcFolder);
			// Add invalid Files for reporting
			AutofixUIUtility.setAllInvalidFileNameWithPath(allInvalidFileNamesWithPath);
			Collections.sort(Reporting.violationInfos, ViolationInfo.CompareByFileName);
			Reporting.addConent();
		}catch(Exception err){
			Logging.log(err);
		}
	}



	/**
	 * Update the Name of File having ClassNamingConventions violation
	 * @param allInvalidFiles
	 * @throws Exception
	 * @return
	 */
	private void changeClassName(List<File> allInvalidFiles) {
		Path path;
		String incorrectClassName, newClsNameWithPath;
		File tempFile;
		List<File> metaXmlFileNames = new ArrayList<>();
		try {
			for(File invalidFile : allInvalidFiles) {
				for(Violation violation : invalidFile.getViolation()) {
					if(violation.getRule().equalsIgnoreCase(PMDValidationRules.CLASS_NAMING_CONVENTIONS)) {
						path = Paths.get(invalidFile.getName());
						incorrectClassName = path.getFileName().toString();
						//correcting class name , adding UpperCase 
						newClsNameWithPath = path.getParent().toString() +"\\"
								+incorrectClassName.substring(0, 1).toUpperCase() 
								+ incorrectClassName.substring(1);
						invalidFile.setName(newClsNameWithPath);
						tempFile = new File();
						// Also Updating xml file
						tempFile.setName(newClsNameWithPath+"-meta.xml");
						metaXmlFileNames.add(tempFile);
						break;
					}
				}
			}
			if(!metaXmlFileNames.isEmpty()){
				allInvalidFiles.addAll(metaXmlFileNames);
			}
		}catch(Exception e) {
			Logging.log(e);
		}
	}

	/**
	 * Run all required Rules in the Input invalid File
	 * @param file
	 * @param rulesToBeFired
	 * @throws IOException
	 */
	public void runFRRuletoFile(File file, List<String> rulesToBeFired) throws IOException {
		// Run PMD correction method for File
		PMDUtility.doCorrection(file);
		// Call update nested violation method for file
		formatterService.updateNestedViolations(file);
		// Create a map of RuleName, Violations related to that rule for the input file
		Map<String, List<Violation>> violationMap = file.getViolation()
				.stream()
				.collect( Collectors.groupingBy(Violation::getRule) );
		Path path = Paths.get(file.getName());
		List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);

		for(String ruleName : rulesToBeFired){
			if(violationMap.containsKey(ruleName)){
				try {
					AutofixConfig.getFRRule(ruleName).doOperation(path.getFileName().toString(), lines, violationMap.get(ruleName));
				} catch (Exception e) {
					Logging.log("error occured on file :: "+file.getName()+" for rule :: "+ruleName,e);
				}
			}
		}
		Files.write(path, lines, StandardCharsets.UTF_8);
		formatterService.runCodeFormatter1(file);

	}
	
	
	/**
	 * Run basic apex formatting
	 * @param String
	 * @throws Exception
	 * @return
	 */
	public static void runApexBasicFormatter(String sourceFolder) {
		java.io.File folder = new java.io.File(sourceFolder);
		java.io.File[] fileNames = folder.listFiles();
		for(java.io.File file : fileNames) {
			try {
				Logging.log("BK# FILE:" + file.getName());
				BasicApexFormatter.runApexFormatter(file);
			} catch(Exception ex) {
				Logging.log(ex);
			}
		}
	}

}
