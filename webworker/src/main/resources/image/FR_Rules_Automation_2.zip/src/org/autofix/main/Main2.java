package org.autofix.main;

import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.autofix.common.AutofixConfig;
import org.autofix.common.AutofixValidationRules;
import org.autofix.model.AutofixRuleSetting;
import org.autofix.model.Autofix_Rule;
import org.autofix.model.RuleCategory;
import org.autofix.utility.AppUtility;
import org.codehaus.jackson.type.TypeReference;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

public class Main2 {

	public static void main(String[] args) {
		/*AutofixRuleSetting s1 = new AutofixRuleSetting();
		Autofix_Rule rul1 = new Autofix_Rule("aedasd", "asefsd", 1, 1, true, false, "APEX");
		s1.setAutoFixRule(rul1);
		s1.setRuleClassPath("hjhjj");
		s1.setValidationClassPath("qwdasd");
		List<AutofixRuleSetting> lst = new ArrayList<>();
		lst.add(s1);
		lst.add(s1);*/
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		//String json = gson.toJson(FRValidationRules.getFrRuleSettings()); // converts to json
	    //System.out.println(json);
	    /*List<AutofixRuleSetting> out = gson.fromJson(json, new TypeToken<List<AutofixRuleSetting>>() {}.getType());
	    System.out.println(out.get(0).getAutoFixRule().getCategory());
		*/
	    
	    /*List<AutofixRuleSetting> lst = new ArrayList<>();
	    AutofixRuleSetting temp;
	    for(Autofix_Rule str : FRValidationRules.getFrRuleSettings()
	    		.stream()
	    		.sorted((t1,t2)->t1.getIteration_order()-t2.getIteration_order())
	    		.collect(Collectors.toList())
	    		){
	    	temp = new AutofixRuleSetting();
	    	temp.setAutoFixRule(str);
	    	temp.setRuleClassPath(AutofixConfig.frConfigMap.get(str.getUniqueRuleName()));
	    	temp.setValidationClassPath(AutofixConfig.frValidationMap.get(str.getUniqueRuleName()));
	    	lst.add(temp);
	    }
	    
		String json = gson.toJson(lst); // converts to json
	    System.out.println(json);*/
		
		try{
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream input = classLoader.getResourceAsStream("autofix_rule_config.properties");
			String json = IOUtils.toString(input,StandardCharsets.UTF_8);
			System.out.println(json);
			Type type = new TypeToken<List<AutofixRuleSetting>>() {
			}.getType();
			
			List<AutofixRuleSetting> out = gson.fromJson(json, type);
			for(AutofixRuleSetting s : out ){
				System.out.println(s.getAutoFixRule().getUniqueRuleName());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
