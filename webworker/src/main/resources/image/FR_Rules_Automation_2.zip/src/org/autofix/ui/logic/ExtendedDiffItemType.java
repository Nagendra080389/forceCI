package org.autofix.ui.logic;

/**
 * Extends {@link } with MODIFIED item type.
 */
public enum ExtendedDiffItemType {
    EQUAL,
    INSERT,
    DELETE,
    MODIFIED
}
