/**************************************************************************************
Class Name		: WhileLoopRule
Version   		: 1.0 
Created Date	: 03 Feb 2020
Function   		: Class to fix the while loop violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/02/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.util.List;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

public class WhileLoopRule implements IFRRules{
	public final String OPEN_BRACE = "{ ";
	public final String CLOSE_BRACE = " }";

	/**
     * Method name  : doOperation
     * Description  : updates the code by adding braces to while loop
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		List<String> lines = allLines;
		String content;
		ViolationInfo info;
		for(Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			content = lines.get(violation.getBeginline().intValue()-1);
			info.setBeforeFix(content);
			content = content.substring(0, violation.getBegincolumn().intValue()-1) + OPEN_BRACE + content.substring(violation.getBegincolumn().intValue()-1);
			lines.set(violation.getBeginline().intValue()-1, content);
			if(violation.getNumberOfEndBraces() == 0) {
				info.setAfterFix(content.trim().replace("{", "{\n\t").replace("}", "\n}"));
				Reporting.violationInfos.add(info.toCSVRow());
			}
			for(Integer i=0 ; i<violation.getNumberOfEndBraces() ; i++) {
				content = lines.get(violation.getEndline().intValue()-1);
				content = content.substring(0, violation.getEndcolumn().intValue()+2) + CLOSE_BRACE + content.substring(violation.getEndcolumn().intValue()+2);
				lines.set(violation.getEndline().intValue()-1, content);
				if(i == violation.getNumberOfEndBraces()-1) {
					info.setAfterFix(content.trim().replace("{", "{\n\t").replace("}", "\n}"));
					Reporting.violationInfos.add(info.toCSVRow());
				}
			}
		}
	}

}
