package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Program to detect duplicate properties in CSS
 *
 * @author Prasenjeet Banerjee
 * @version 1.0
 * @since 2020-08-10
 */
public class PropertiesShouldNotBeDuplicatedCSSValidation implements IValidation {

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				violationLst = new ArrayList<>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				violationLst = this.detectDuplicateCSSProperties(lstLines);
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	/**
	 * Detects duplicate CSS properties
	 * 
	 * @param allLines
	 * @return List<Violation>
	 */
	private List<Violation> detectDuplicateCSSProperties(List<String> allLines) {
		boolean blockStarted = false;
		List<String> propertyNames = new ArrayList<String>();
		String currentLine = null;
		List<Violation> violationLst = new ArrayList<Violation>();
		Violation tempViolation = null;
		for (int i = 0; i < allLines.size(); i++) {
			currentLine = allLines.get(i).trim();
			if (currentLine.isEmpty()) {
				continue;
			}
			if (blockStarted) {
				String[] property = currentLine.split(":");
				if (property.length > 0 && propertyNames.contains(property[0])) {
					tempViolation = new Violation();
					tempViolation.setBeginline(BigInteger.valueOf(i + 1));
					tempViolation.setEndline(BigInteger.valueOf(i + 1));
					tempViolation.setRule(CustomValidationRules.AVOID_DUPLICATE_PROPERTIES_CSS);
					violationLst.add(tempViolation);
				} else {
					propertyNames.add(property[0]);
				}
			}
			if (currentLine.endsWith("{")) {
				blockStarted = true;
			} else if (currentLine.endsWith("}") && blockStarted) {
				blockStarted = false;
				propertyNames.clear();
			}
		}
		return violationLst;
	}

}
