package org.autofix.rules;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.autofix.checker.ApexCommentChecker;
import org.autofix.checker.ApexSoqlChecker;
import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.AppUtility;
import org.autofix.utility.Reporting;

/**
 * Below class will replace all Hard-coded String with String Variables
 * @author Laltu Banerjee
 * @version 1.0
 * @since 2020-05-15
 */
public class AvoidHardcodedStringRule implements IFRRules{

	// pattern required for this class
	private static final Pattern VALID_VARIABLE_NAME_PATTERN = Pattern.compile("^[a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]$");
	private static final Pattern DETECT_VARIABLE_PATTERN = Pattern.compile("([a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]\\s+=)|"
			+"([a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]=)|"
			+ "([a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]\\s+:)|"
			+ "([a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]:)|"
			+ "([a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]\\{)|"
			+ "([a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]\\s+\\{)");
	private static final Pattern GET_VARIABLE_NAME_PATTERN = Pattern.compile("[a-zA-Z$][a-zA-Z0-9$_]*[a-zA-Z0-9$]");
	private static final Pattern DETECT_CLASS_NAME_PATTERN = Pattern.compile("(class\\s+[a-zA-Z$_][a-zA-Z0-9$_]*[{]{0,1})|"
			+ "(trigger\\s+[a-zA-Z$_][a-zA-Z0-9$_]*\\s+)");
	private static final Pattern DUPLICATE_VARIABLE_SUFFIX_PATTERN = Pattern.compile("[0-9]+$");
	//private static final Pattern ENDING_WITH_UNDERSORE_PATTERN = Pattern.compile("_$");
	private static final Pattern SPECIAL_CHAR_CHECK_PATTERN = Pattern.compile("[^\\w\\s]");
	private static final Pattern MULTIPLE_SPACE_PATTERN = Pattern.compile("\\s+");
	private static final Pattern MULTIPLE_UNDERSCORE_PATTERN = Pattern.compile("_{2,}");
	private static final Pattern STARTING_OR_ENDING_WITH_UNDERSCORE_PATTERN = Pattern.compile("(^_)|(_$)");
	// String Variables
	private static final String SINGLE_LINE_COMMENT = "//";
	private static final String MULTI_LINE_COMMENT_START = "/*";
	private static final String MULTI_LINE_COMMENT_END = "*/";
	private static final String VARIABLE_PREFIX = "CONST_";
	private static final String OPEN_CURLY_BRACES = "{";
	private static final String UNDERSCORE = "_";
	private static final String AUTO_FIX_VAR_DECLERATION_START = "\t// Hardcoded String Variable Decleration Start\n";
	private static final String AUTO_FIX_VAR_DECLERATION_END = "\t// Hardcoded String Variable Decleration ends";
	private static final String AUTO_FIX_VAR_PREFIX = "\tprivate static final String ";
	private static final String CLASS_CONST_VARIABLE = "CLASS_CONST_VARIABLE";
	private static final String EMPTY_STRING = "";
	private static final String COLON = ":";
	private static final List<String> APEX_RESERVED_KEYWORD = Arrays.asList(AppConstants.APEX_RESERVED_KEYWORD.split(";"));
	private static final List<String> SFDC_SOBJECTS = Arrays.asList(AppConstants.SFDC_SOBJECTS.split(";"));
	// other variables
	private Set<String> allHardcodedString,allVariablesDefinedInClass;
	private Map<String,String> autoFixVariableMap;
	private int nextValidVarCounter = 0; 
	private Comparator<Violation> violationComparator = (v1,v2)->v1.getBegincolumn().compareTo(v2.getBegincolumn());

	private ApexSoqlChecker apexSoqlChecker;

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) throws CustomException {
		String tempStr;
		Matcher detectVariablePatternMatcher,getVariablePatternMatcher;
		allHardcodedString = new HashSet<>();
		allVariablesDefinedInClass = new HashSet<>();
		autoFixVariableMap = new LinkedHashMap<>();
		nextValidVarCounter = 1;
		ViolationInfo info = null;
		apexSoqlChecker = ApexSoqlChecker.getInstance(allLines);
		// get all hardcoded string
		for(Violation v : violationLst){
			tempStr = allLines.get(v.getBeginline().intValue()-1);
			allHardcodedString.add(tempStr.substring(v.getBegincolumn().intValue()+1, v.getEndcolumn().intValue()-1));
		}

		//get all variable names defined in class
		for(String str : allLines){
			detectVariablePatternMatcher = DETECT_VARIABLE_PATTERN.matcher(str);
			while(detectVariablePatternMatcher.find()){
				getVariablePatternMatcher = GET_VARIABLE_NAME_PATTERN.matcher(detectVariablePatternMatcher.group());
				if(getVariablePatternMatcher.find()){
					allVariablesDefinedInClass.add(getVariablePatternMatcher.group().trim().toUpperCase());
				}
			}
		}

		// First Valid Line Index
		int firstValidLineIndex = getFirstValidLineIndex(allLines);

		createVariableForHardCodedString();

		// Put the AutoFix Variable in required Place
		String tempVariableName;
		String updatedLine;
		int nextIndex;

		// Create a Map of BeginLine and List of Violation
		// so that we will update the line only once
		Map<BigInteger, List<Violation>> violationMap = violationLst
				.stream()
				.collect(Collectors.groupingBy(Violation::getBeginline));
		for(BigInteger beginLine : violationMap.keySet()){
			tempStr = allLines.get(beginLine.intValue()-1);
			info = new ViolationInfo(fileName, CustomValidationRules.AVOID_HARDCODED_STRING);
			info.setBeforeFix(tempStr);
			violationMap.get(beginLine).sort(violationComparator);
			nextIndex=0;
			updatedLine = "";
			for(Violation v : violationMap.get(beginLine)){
				tempVariableName = autoFixVariableMap.get(tempStr.substring(v.getBegincolumn().intValue()+1, v.getEndcolumn().intValue()-1));
				if(apexSoqlChecker.isSoql(v.getBeginline().intValue(), v.getBegincolumn().intValue()) && 
						apexSoqlChecker.isBindVariableRequired(v.getBeginline().intValue(), v.getBegincolumn().intValue()) ) {
					updatedLine += tempStr.substring(nextIndex, v.getBegincolumn().intValue())+COLON+tempVariableName;
				}else{
					updatedLine += tempStr.substring(nextIndex, v.getBegincolumn().intValue())+tempVariableName;
				}
				nextIndex = v.getEndcolumn().intValue();
			}
			updatedLine += tempStr.substring(nextIndex);
			allLines.set(beginLine.intValue()-1, updatedLine);
			info.setAfterFix(updatedLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}

		int dataNeedToEnterInThisIndex=-1;
		for(int i=firstValidLineIndex;i<allLines.size();i++){
			if(allLines.get(i).contains(OPEN_CURLY_BRACES)){
				dataNeedToEnterInThisIndex = i+1;
				break;
			}
		}
		allLines.add(dataNeedToEnterInThisIndex,getAutoFixVariables());
		System.out.println("Completed");
	}

	private void createVariableForHardCodedString(){
		String tempVariableName;
		for(String str : allHardcodedString){
			tempVariableName = getVariableName(str);
			tempVariableName = checkForSpecialString(tempVariableName);
			while(allVariablesDefinedInClass.contains(tempVariableName)){
				tempVariableName = getUniqueVariableName(tempVariableName);
			}
			autoFixVariableMap.put(str, tempVariableName);
			allVariablesDefinedInClass.add(tempVariableName);
		}
	}

	private String getVariableName(String inputStr){
		String variableName;
		Matcher matcher;
		if(inputStr.length()>20){
			variableName = MULTIPLE_SPACE_PATTERN.matcher(inputStr.substring(0, 19).trim()).replaceAll(UNDERSCORE).toUpperCase();
		}else{
			variableName = MULTIPLE_SPACE_PATTERN.matcher(inputStr.trim()).replaceAll(UNDERSCORE).toUpperCase();
		}
		// Check if it is starting/ending with Underscore
		variableName = STARTING_OR_ENDING_WITH_UNDERSCORE_PATTERN.matcher(variableName).replaceAll(EMPTY_STRING);
		// Check for special character in the variable name
		// if special character found replace by ""
		variableName = SPECIAL_CHAR_CHECK_PATTERN.matcher(variableName).replaceAll(EMPTY_STRING);
		// Check if this is valid variable name
		matcher = VALID_VARIABLE_NAME_PATTERN.matcher(variableName);
		if(matcher.find()){
			// Replace Multiple Underscore with Single Underscore
			return MULTIPLE_UNDERSCORE_PATTERN.matcher(variableName).replaceAll(UNDERSCORE);
		}
		// return a valid variable name
		return CLASS_CONST_VARIABLE+nextValidVarCounter++;
	}

	private String getUniqueVariableName(String inputStr){
		if(!inputStr.startsWith(VARIABLE_PREFIX)){
			return VARIABLE_PREFIX+inputStr;
		}
		else{
			Matcher match = DUPLICATE_VARIABLE_SUFFIX_PATTERN.matcher(inputStr);
			if(match.find()){
				return inputStr.substring(0, match.start())+(Integer.valueOf(match.group()).intValue()+1);
			}
		}
		return inputStr+"_1";
	}

	private String getAutoFixVariables(){
		StringBuilder builder = new StringBuilder();
		builder.append(AUTO_FIX_VAR_DECLERATION_START);
		for(String key : autoFixVariableMap.keySet()){
			builder.append(AUTO_FIX_VAR_PREFIX+autoFixVariableMap.get(key)+" = '"+key+"';\n");
		}
		builder.append(AUTO_FIX_VAR_DECLERATION_END);
		return builder.toString();
	}

	private String checkForSpecialString(String str){
		String tempStr = str.toLowerCase();
		if(APEX_RESERVED_KEYWORD.contains(tempStr) || 
				SFDC_SOBJECTS.contains(tempStr) || 
				tempStr.endsWith("__c") )
		{
			return CLASS_CONST_VARIABLE+"_"+str;
		}
		return str;
	}

	private int getFirstValidLineIndex(List<String> lines) throws CustomException{
		boolean multiLineCommentCheck = false;
		int openCount = 0;
		int closeCount = 0;
		String tempLine;
		for(int i=0;i<lines.size();i++){
			tempLine=lines.get(i);
			if(AppUtility.StringUtility.isNotNullOrBlank(tempLine) && !tempLine.trim().startsWith(SINGLE_LINE_COMMENT) ){
				if(tempLine.trim().startsWith(MULTI_LINE_COMMENT_START)){
					multiLineCommentCheck = true;	
				}
				if(multiLineCommentCheck){
					openCount += frequencyOfInput(MULTI_LINE_COMMENT_START, tempLine);
					closeCount += frequencyOfInput(MULTI_LINE_COMMENT_END, tempLine);
					openCount = openCount-closeCount;
					closeCount = 0;
					if(openCount<1){
						multiLineCommentCheck = false;
					}
				}else{
					Matcher match = DETECT_CLASS_NAME_PATTERN.matcher(tempLine);
					if(match.find()){
						return i;
					}
				}
			}
		}
		throw new CustomException("Not able to find valid first line");
	}

	private int frequencyOfInput(String subString,String inputString){
		int count = 0, fromIndex = 0;
		while ((fromIndex = inputString.indexOf(subString, fromIndex)) != -1 ){
			count++;
			fromIndex++;
		}
		return count;
	}

}
