package org.autofix.codeFormatter;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.autofix.constants.AppConstants;
import org.autofix.utility.Logging;

public class BracesFormatter implements ICodeFormatter {
	
	private static final String SET_BODY = "setbody";

	@Override
	public List<String> formatCode(List<String> inputLst, List<Integer> intLst) {
		String strCurrentLine;
		System.out.println(intLst);
		try{
			for(Integer i : intLst){
				strCurrentLine = inputLst.get(i-1); // Because inputLst is a 0 based String
				System.out.println(strCurrentLine);
				
				//Changes made for escaping instantiating set and put
				if(!strCurrentLine.contains("} );") && !strCurrentLine.contains("});")  && !strCurrentLine.contains("Set<") && !strCurrentLine.contains(">{")){
					
				if (strCurrentLine.contains("{") && strCurrentLine.trim().indexOf("{")==0 ) {
					String strPreviousLine="";
					int j = i-2;
					while(strPreviousLine == "") {
						if(!inputLst.get(j).trim().startsWith("//")) {
							strPreviousLine = inputLst.get(j);
							continue;
						}
						j--;
					}
					String strPreviousLineSpaces = getSpaces(strPreviousLine);
					strCurrentLine = removeOpenBraces(strCurrentLine);//strCurrentLine.replace("{", "");
					strPreviousLine = strPreviousLineSpaces + strPreviousLine.trim() + " {";
					inputLst.set(j, strPreviousLine);
					strCurrentLine = strPreviousLineSpaces + getTabSpaces() + strCurrentLine.trim();
				} else if (strCurrentLine.contains("{") && !strCurrentLine.contains("'{'")) {
					strCurrentLine = strCurrentLine.replaceAll("\\s*\\{\\s*", " {" + System.lineSeparator() + getSpaces(strCurrentLine) + getTabSpaces() );
				}
				System.out.println(strCurrentLine);
				
				if (strCurrentLine.contains("}") && strCurrentLine.trim().length()>1 && strCurrentLine.charAt(0) != '}' && !strCurrentLine.contains("'}'")) {
					if (strCurrentLine.contains("\n")) {
						strCurrentLine = strCurrentLine.replaceAll("\\s*}", System.lineSeparator() + getSpaces(strCurrentLine) + "}");						
					} else {
						strCurrentLine = strCurrentLine.replaceAll("\\s*}", System.lineSeparator() + getSpacesRemovingTab(strCurrentLine) + "}");						
					}
				  }
				}
				
				inputLst.set(i-1, strCurrentLine);
			}
			
			int lineNo = 0;
			for(String currentLine : inputLst){
				if (getClosingBraceOccurances(currentLine) > 1) {
					System.out.println("more than 1 clo braces: " + currentLine);
					System.out.println(formatClosingBraces(currentLine));
					//Changes made for excluding for skipping getter and setters 
					if(!currentLine.contains("{get{") && !currentLine.contains("{set{")
							&& !currentLine.contains("{ get {") && !currentLine.contains("{ set {")) {
						if(!currentLine.toLowerCase().contains(SET_BODY)) {
							inputLst.set(lineNo, formatClosingBraces(currentLine));
						}
					}
				}
				lineNo++;
			}
		} catch(Exception e){
			Logging.log(e);
		}
		return inputLst;
	}
	
	
	/**
     * Method name  : formatCode
     * Description  : Used by the SOQL Security Enforced rule to format the opening braces.
     * 				  In addition, closing braces of SOQL statements that don't end on same line are also formatted.
     * Example	    : Before Autofix : List<Contact> contactList = 
     * 										[SELECT Status__c FROM Contact WHERE Id=:ID];
     *  			: After Autofix : if(Schema.SObjectType.Contact.Fields.Status__c.isAccessible() { 
     *  							  	[SELECT Status__c FROM Contact WHERE Id=:ID]; 
     *  							  } 
     * Return Type  : List<String>
     * Parameter    : List<String> inputLst, List<Integer> intLst, Map<Object, Object> startEndLineMap
     **/
	@Override
	public List<String> formatCode(List<String> inputLst, List<Integer> intLst, Map<Object, Object> startEndLineMap) {
		String strCurrentLine;
		String endLine = AppConstants.EMPTY;
		BigInteger endLineIndex = BigInteger.ZERO;
		int firstIndex = 0;
		String firstIndexLine;
		String secondIndexLine;
		try{
			for(Integer i : intLst){
				strCurrentLine = inputLst.get(i-1); // Because inputLst is a 0 based String
				
				//Changes made for escaping instantiating set and put
				if (!strCurrentLine.contains("} );") && !strCurrentLine.contains("});") && !strCurrentLine.contains("Set<") && !strCurrentLine.contains(">{")) {

					if (strCurrentLine.contains(AppConstants.OPEN_BRACES_STR) && strCurrentLine.trim().indexOf(AppConstants.OPEN_BRACES_STR) == 0) {
						String strPreviousLine = AppConstants.EMPTY;
						int j = i - 2;
						while (strPreviousLine == AppConstants.EMPTY) {
							if (!inputLst.get(j).trim().startsWith("//")) {
								strPreviousLine = inputLst.get(j);
								continue;
							}
							j--;
						}
						String strPreviousLineSpaces = getSpaces(strPreviousLine);
						strCurrentLine = removeOpenBraces(strCurrentLine);
						strPreviousLine = strPreviousLineSpaces + strPreviousLine.trim() + " {";
						inputLst.set(j, strPreviousLine);
						strCurrentLine = strPreviousLineSpaces + getTabSpaces() + strCurrentLine.trim();
					} else if (strCurrentLine.contains(AppConstants.OPEN_BRACES_STR)) {
						strCurrentLine = strCurrentLine.replaceAll("\\s*\\{\\s*", " {" + System.lineSeparator() + getSpaces(strCurrentLine) + getTabSpaces());
					}

					if (strCurrentLine.contains(AppConstants.CLOSE_BRACES_STR) && strCurrentLine.trim().length() > 1 && strCurrentLine.charAt(0) != AppConstants.CLOSE_BRACES_CHAR) {
						if (strCurrentLine.contains("\n")) {
							strCurrentLine = strCurrentLine.replaceAll("\\s*}", System.lineSeparator() + getSpaces(strCurrentLine) + AppConstants.CLOSE_BRACES_STR);
						} else {
							strCurrentLine = strCurrentLine.replaceAll("\\s*}", System.lineSeparator() + getSpacesRemovingTab(strCurrentLine) + AppConstants.CLOSE_BRACES_STR);
						}
					} else if (startEndLineMap != null && !startEndLineMap.isEmpty()
							&& startEndLineMap.get(BigInteger.valueOf(i)) != null) {
						endLineIndex = (BigInteger) startEndLineMap.get(BigInteger.valueOf(i));
						endLine = inputLst.get(endLineIndex.intValue() - 1);

						if (endLine.contains(AppConstants.CLOSE_BRACES_STR) && endLine.trim().length() > 1 && endLine.charAt(0) != AppConstants.CLOSE_BRACES_CHAR) {
							if (endLine.contains("\n")) {
								endLine = endLine.replaceAll("\\s*}", System.lineSeparator() + getSpaces(endLine) + AppConstants.CLOSE_BRACES_STR);
							} else {
								//If there are more than 1 closing brace on the ending line
								if (getClosingBraceOccurances(endLine) > 1) {
									endLine = getTabSpaces() + endLine;
									firstIndex = endLine.indexOf(AppConstants.CLOSE_BRACES_CHAR);
									firstIndexLine = endLine.substring(0, firstIndex + 1);
									secondIndexLine = endLine.substring(firstIndex + 1, endLine.length());
									endLine = firstIndexLine + System.lineSeparator() + formatClosingBracesForSOQL(secondIndexLine, inputLst.get(i - 1));
								} 
								//If there is only 1 closing brace on the ending line
								else {
									firstIndex = endLine.indexOf(AppConstants.CLOSE_BRACES_CHAR);
									firstIndexLine = endLine.substring(0, firstIndex);
									secondIndexLine = endLine.substring(firstIndex, endLine.length());
									endLine = firstIndexLine + System.lineSeparator() + formatClosingBracesForSOQL(secondIndexLine, inputLst.get(i - 1));
								}
							}
							//Set the formatted ending line in the list
							inputLst.set(endLineIndex.intValue()-1, endLine);
						}
					}
				}			
				//Set the formatted starting line in the list
				inputLst.set(i-1, strCurrentLine);
			}
			
			int lineNo = 0;
			for(String currentLine : inputLst){
				if (getClosingBraceOccurances(currentLine) > 1 && !currentLine.contains("\n")) {
					//Changes made for excluding for skipping getter and setters 
					if(!currentLine.contains("{get{") && !currentLine.contains("{set{")
							&& !currentLine.contains("{ get {") && !currentLine.contains("{ set {")) {
						inputLst.set(lineNo, formatClosingBraces(currentLine));
					}
				}
				lineNo++;
			}
			
		} catch(Exception e){
			Logging.log(e);
		}
		return inputLst;
	}
	
	private static int getClosingBraceOccurances(String str) {
		 return str.length() - str.replace("}", "").length();
	}
		
	private static String formatClosingBraces(String strCurrentLine) {
		String currentLineSpaces = getSpaces(strCurrentLine);
		String newStr = currentLineSpaces;
		//strCurrentLine = strCurrentLine.replaceAll("\\s*", "");
		int strLength = strCurrentLine.length();
		
		for (int i=0; i<strLength; i++) {
			if ( (i==0 && strCurrentLine.charAt(0) == '}')) {
				newStr = newStr + "}";
			} else if(strCurrentLine.charAt(i) == '}') {
				currentLineSpaces = getSpacesRemovingTab(currentLineSpaces);
				newStr = newStr + "\n" + (currentLineSpaces) + "}";
			} else {
				newStr = newStr + strCurrentLine.charAt(i);
			}
		}
		return newStr;
	}
	
	/**
     * Method name  : formatClosingBracesForSOQL
     * Description  : Used by the SOQL Security Enforced rule to format the closing braces 
     * Return Type  : String
     * Parameter    : String strCurrentLine, String startLine
     **/
	private static String formatClosingBracesForSOQL(String strCurrentLine, String startLine) {
		String currentLineSpaces = getSpaces(startLine);
		String newStr = currentLineSpaces;
		int strLength = strCurrentLine.length();
		
		for (int i=0; i<strLength; i++) {
			if ( (i==0 && strCurrentLine.charAt(0) == AppConstants.CLOSE_BRACES_CHAR)) {
				newStr = newStr + AppConstants.CLOSE_BRACES_STR;
			} else if(strCurrentLine.charAt(i) == AppConstants.CLOSE_BRACES_CHAR) {
				currentLineSpaces = getSpacesRemovingTab(currentLineSpaces);
				newStr = newStr + "\n" + (currentLineSpaces) + AppConstants.CLOSE_BRACES_STR;
			} else {
				newStr = newStr + strCurrentLine.charAt(i);
			}
		}
		return newStr;
	}
	
	private static String getSpaces(String str) {		 
		String strSpaces = "";
		String trimmedString;
		if (str != null && str != "") {
			trimmedString = str.replaceAll("^\\t+", "");
	    	for( int i=0; i<str.length()-trimmedString.length(); i++) {
	    		strSpaces += "    ";
	    	}
	    	String spacetrimmedString = trimmedString.replaceAll("^\\s+", "");
	    	for( int i=0; i<trimmedString.length()-spacetrimmedString.length(); i++) {
	    		strSpaces += " ";
	    	}
	    }
	    return strSpaces;
	}
	
	private static String getSpacesRemovingTab(String str) {
	    String strSpaces = "";
	    if (str != null && str != "") {
	    	for( int i=0; i < str.length() && str.charAt(i) == ' '; i++) {
	    		if(i>3) {
	    			strSpaces += " ";
	    		}
	    	}
	    }
	    return strSpaces;
	}
	
	/**
	 * Using \t was giving 6 spaces in notepad while 4 spaces in notepad ++, 
	 * this method instead uses 4 spaces always
	 */
	private static String getTabSpaces() {
	    return "    ";
	}
	
	private static String removeOpenBraces(String str) {
		int index = str.indexOf("{");
	    return str.substring(0, index) + str.substring(index + 1);
	}
	
}