package org.autofix.utility;

import java.util.Collections;
import java.util.List;

import org.autofix.common.ApplicationParameter;
import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.ui.AutofixUI_Frame;
import org.autofix.ui.panel.ForceReviewerPanel;

public class AutofixUIUtility {
	private static int ui_progressBar_value=0;
	private static AutofixUI_Frame autoFixUIRef;
	private static ForceReviewerPanel frPanelRef;
	private static double apiVersionUpdateValue=ApplicationParameter.getDefaultAPIVersion();
	private static List<String> allInvalidFileNameWithPath;
	private static String userSelectedSrcPath;
	private static String userSelectedDestPath;
	
	public static String getUserSelectedSrcPath() {
		return userSelectedSrcPath;
	}

	public static void setUserSelectedSrcPath(String userSelectedSrcPath) {
		AutofixUIUtility.userSelectedSrcPath = userSelectedSrcPath;
	}

	public static String getUserSelectedDestPath() {
		return userSelectedDestPath;
	}

	public static void setUserSelectedDestPath(String userSelectedDestPath) {
		AutofixUIUtility.userSelectedDestPath = userSelectedDestPath;
	}

	public static List<String> getAllInvalidFileNameWithPath() {
		return allInvalidFileNameWithPath;
	}

	public static void setAllInvalidFileNameWithPath(List<String> allInvalidFileNameWithPath) {
		if(allInvalidFileNameWithPath != null && !allInvalidFileNameWithPath.isEmpty()){
			Collections.sort(allInvalidFileNameWithPath,(t1,t2)->t1.toUpperCase().compareTo(t2.toUpperCase()));
		}
		AutofixUIUtility.allInvalidFileNameWithPath = allInvalidFileNameWithPath;
	}
	
	public static void setFrPanelRef(ForceReviewerPanel ref){
		frPanelRef = ref;
	}
	
	public static int getUiProgressBarValue(){
		return ui_progressBar_value;
	}
	
	public static void updateUIProgressBar(double progress_val){
		ui_progressBar_value += Double.valueOf(progress_val).intValue();
	}
	
	public static double getProgressBarIncrementValPerFile(int noOfFiles){
		return ((AppConstants.UI_PROGRESS_BAR_MAX_VALUE-getUiProgressBarValue())/noOfFiles);
	}
	
	public static double getProgressBarIncrementalValPerIteration(int totalIteration){
		return ((AppConstants.UI_PROGRESS_BAR_MAX_VALUE-getUiProgressBarValue()-400)/totalIteration);
	}
	
	public static void resetProgressBar(){
		ui_progressBar_value = AppConstants.UI_PROGRESS_BAR_MIN_VALUE;
	}
	
	public static void addMessage(String msg){
		if(frPanelRef != null){
			frPanelRef.showInfo(msg);
		}
	}

	public static double getApiVersionUpdateValue() {
		return apiVersionUpdateValue;
	}
	
	public static void setApiVersionUpdateValue(double apiVersionUpdateValue) throws CustomException {
		if(apiVersionUpdateValue > ApplicationParameter.getDefaultAPIVersion()){
			throw new CustomException("Api version should not be greater then "+(int)ApplicationParameter.getDefaultAPIVersion());
		}else if(apiVersionUpdateValue <= 0){
			throw new CustomException("Invalid API Version");
		}
		AutofixUIUtility.apiVersionUpdateValue = apiVersionUpdateValue;
	}

	public static AutofixUI_Frame getAutoFixUIRef() {
		return autoFixUIRef;
	}

	public static void setAutoFixUIRef(AutofixUI_Frame autoFixUIRef) {
		AutofixUIUtility.autoFixUIRef = autoFixUIRef;
	}
	
}
