/**************************************************************************************
Class Name		:  SoqlStmtRule
Version   		: 1.0 
Created Date	: 05 May 2020
Function   		: Class to fix the SOQL statements without where or limit clause
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			05/05/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.util.List;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

public class SoqlStmtRule implements IFRRules {
	
	private final static String LIMIT_STMT = " LIMIT :(Limits.getLimitQueryRows() - Limits.getQueryRows()) ";
	private final static String RECT_CLOSE_BRACE = "]";

	/**
     * Method name  : doOperation
     * Description  : updates the code with SOQL query fixes
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String tempContent = "";
		ViolationInfo info;
		for(Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			if(violation.getEndcolumn().intValue() != -1) {
				tempContent = allLines.get(violation.getEndline().intValue()-1);
				info.setBeforeFix(tempContent);
				try {
					if(violation.getEndcolumn().intValue() == tempContent.indexOf(RECT_CLOSE_BRACE)) {
						tempContent = tempContent.substring(0,violation.getEndcolumn().intValue()) + LIMIT_STMT + tempContent.substring(violation.getEndcolumn().intValue());
					} else if(tempContent.indexOf(RECT_CLOSE_BRACE) != -1) {
						tempContent = tempContent.substring(0,tempContent.indexOf(RECT_CLOSE_BRACE)) + LIMIT_STMT + tempContent.substring(tempContent.indexOf(RECT_CLOSE_BRACE));
					}
				} catch(Exception ex) {
					Logging.log("error occured on file :: "+fileName+" for rule :: "+violation.getRule(),ex);
				}	
				info.setAfterFix(tempContent);
			}
			allLines.set(violation.getEndline().intValue()-1, tempContent);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}
