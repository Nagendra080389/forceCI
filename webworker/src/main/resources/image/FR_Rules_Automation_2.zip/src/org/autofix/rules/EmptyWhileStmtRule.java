/**************************************************************************************
Class Name		: EmptyWhileStmtRule
Version   		: 1.0 
Created Date	: 03 Feb 2020
Function   		: Class to fix the empty while loop violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/02/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.util.List;

import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

public class EmptyWhileStmtRule implements IFRRules{

	private final String OPEN_BRACE = "{";
	private final String CLOSE_BRACE = "}";

	/**
     * Method name  : doOperation
     * Description  : updates the code by removing empty while loops
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String pieceOfCode;

		for(Violation violation : violationLst) {
			pieceOfCode = "";
			String content = allLines.get(violation.getBeginline().intValue()-1);
			if(content.contains(OPEN_BRACE) && content.contains(CLOSE_BRACE)) {
				allLines.set(violation.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
				pieceOfCode += content + "\n";
			} else if(!content.contains(CLOSE_BRACE)) {
				Integer openBraces = 0;
				Integer closeBraces = 0;
				if(content.contains(OPEN_BRACE)) {
					openBraces++;
				}
				allLines.set(violation.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
				pieceOfCode += content + "\n";
				for(int i=violation.getBeginline().intValue(); i<allLines.size(); i++) {
					content = allLines.get(i);
					if(content.contains(CLOSE_BRACE) && openBraces > 0) {
						allLines.set(i, AppConstants.NEED_TO_REMOVE_THIS_LINE);
						pieceOfCode += content + "\n";
						closeBraces++;
						if(openBraces == closeBraces) {
							break;
						}
					} else if(!content.contains(CLOSE_BRACE)) {
						if(content.contains(OPEN_BRACE)) {
							openBraces++;
						}
						allLines.set(i, AppConstants.NEED_TO_REMOVE_THIS_LINE);
						pieceOfCode += content + "\n";
					}
				}
			}
			Reporting.violationInfos.add(new ViolationInfo(fileName, violation.getRule(), pieceOfCode, "").toCSVRow());
		}
	}

}
