package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Program to detect unused local and global variables in javascript code
 *
 * @author Prasenjeet Banerjee
 * @version 1.0
 * @since 2020-08-10
 */
public class RemoveUnusedVariablesValidation implements IValidation {

	private final static String LOCAL_VARIABLE_USAGE_PATTERN = "[^\"\'a-zA-Z]<variableName>[^\"\'a-zA-Z]";
	private final static String GLOBAL_VARIABLE_USAGE_PATTERN = "[^\"\'a-zA-Z]this.<variableName>[^\"\'a-zA-Z]";
	private static final Pattern AURA_FUNCTION_DECLARATION = Pattern.compile("function(\\s)*\\(.*\\)(\\s)*\\{");
	private static final Pattern LWC_FUNCTION_DECLARATION = Pattern.compile("([a-z]|[A-Z])+(\\s)*\\(.*\\)(\\s)*\\{");
	private static final Pattern LWC_CLASS_DECLARATION = Pattern.compile("extends\\s([a-z]|[A-Z])+(\\s)*\\{");
	private static final Pattern LOCAL_VARIABLE_DECLARATION = Pattern
			.compile("(var|let)(\\s)*\\w*(\\s)*(=(\\s)*[\\w\"\']*(\\s)*)*;");
	private static final Pattern GLOBAL_VARIABLE_DECLARATION = Pattern
			.compile("(@track|@api)*(\\s)*\\w*(\\s)*(=(\\s)*.*(\\s)*)*;");

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				violationLst = detectUnusedLocalVariables(lstLines);
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	/**
	 * Detects unused local and global variables from the code
	 * 
	 * @param allLines
	 * @return List<Violation>
	 */
	private List<Violation> detectUnusedLocalVariables(List<String> allLines) {
		List<Violation> violationLst = new ArrayList<Violation>();
		Violation violation;
		int blockLevel = 0;
		List<String> variableDeclarationList = null;
		Map<String, String> variableMap = new ConcurrentHashMap<String, String>();
		for (int i = 0; i < allLines.size(); i++) {
			String currentLine = allLines.get(i);
			if (currentLine.trim().isEmpty()) {
				continue;
			}
			Matcher auraMatcher = AURA_FUNCTION_DECLARATION.matcher(currentLine);
			Matcher lwcMatcher = LWC_FUNCTION_DECLARATION.matcher(currentLine);
			Matcher lwcClassMatcher = LWC_CLASS_DECLARATION.matcher(currentLine);
			if (auraMatcher.find() || lwcMatcher.find() || lwcClassMatcher.find()) {
				blockLevel++;
				currentLine = currentLine.substring(currentLine.indexOf("{"), currentLine.length());
			} else if (currentLine.indexOf("}") != -1) {
				blockLevel--;
				currentLine = currentLine.substring(0, currentLine.indexOf("}"));
			}
			/*
			 * Find variable declaration and collect the variable names
			 */
			variableDeclarationList = new ArrayList<String>();
			if (blockLevel == 1) {
				Matcher globalVariableDeclarationMatch = GLOBAL_VARIABLE_DECLARATION.matcher(currentLine);
				while (globalVariableDeclarationMatch.find()) {
					variableDeclarationList.add(globalVariableDeclarationMatch.group());
				}
			} else {
				Matcher localVariableDeclarationMatch = LOCAL_VARIABLE_DECLARATION.matcher(currentLine);
				while (localVariableDeclarationMatch.find()) {
					variableDeclarationList.add(localVariableDeclarationMatch.group());
				}
			}
			if (variableDeclarationList.size() != 0) {
				System.out.println("Variable: " + variableDeclarationList + " BlockLevel: " + blockLevel);
				for (String variableDeclaration : variableDeclarationList) {
					String currentLineNumberAndStartEndIndex = (i + 1) + ":" + currentLine.indexOf(variableDeclaration)
							+ ":" + (currentLine.indexOf(variableDeclaration) + variableDeclaration.length() - 1) + "";
					// Check if the variable is only declared or has an assignment;
					if (variableDeclaration.contains("=")) {
						String[] tokens = variableDeclaration.split("=")[0].trim().split(" ");
						variableMap.put(tokens[tokens.length - 1].trim(), currentLineNumberAndStartEndIndex);
					} else {
						variableDeclaration = variableDeclaration.substring(0, variableDeclaration.indexOf(";")).trim();
						String[] tokens = variableDeclaration.split(" ");
						if (tokens.length == 1) {
							variableMap.put(variableDeclaration.split(" ")[0], currentLineNumberAndStartEndIndex);
						} else if (tokens.length >= 1) {
							variableMap.put(variableDeclaration.split(" ")[1], currentLineNumberAndStartEndIndex);
						}
					}
				}
			}
			/*
			 * Check if the variables has been used anywhere in the line and remove from the
			 * map
			 */
			if (blockLevel > 1) {
				for (String variableName : variableMap.keySet()) {
					Matcher localVariableUsage = Pattern
							.compile(LOCAL_VARIABLE_USAGE_PATTERN.replace("<variableName>", variableName))
							.matcher(currentLine);
					Matcher globalVariableUsage = Pattern
							.compile(GLOBAL_VARIABLE_USAGE_PATTERN.replace("<variableName>", variableName))
							.matcher(currentLine);
					if (localVariableUsage.find() || globalVariableUsage.find()) {
						variableMap.remove(variableName);
					}
				}
			}
		}
		System.out.println("Variables: " + variableMap.keySet());
		for (String variableName : variableMap.keySet()) {
			String[] tokens = variableMap.get(variableName).split(":");
			violation = new Violation();
			violation.setBeginline(BigInteger.valueOf(Integer.parseInt(tokens[0])));
			violation.setBegincolumn(BigInteger.valueOf(Integer.parseInt(tokens[1])));
			violation.setEndcolumn(BigInteger.valueOf(Integer.parseInt(tokens[2])));
			violation.setRule(CustomValidationRules.REMOVE_UNUSED_VARIABLES_JS);
			violationLst.add(violation);
		}
		return violationLst;
	}

}
