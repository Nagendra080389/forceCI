package org.autofix.validation;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.LongStream;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
* Violation detection file to detect SOQL queries not having accessibility checks for selected fields using Apex schema function
* If accessibility checks are not present for SOQL query, then such queries need to be flagged by this code
* Example : Before Autofix : [SELECT Status__c FROM Contact WHERE Id=:ID];
*  		  : After Autofix : if(Schema.SObjectType.Contact.Fields.Status__c.isAccessible() { [SELECT Status__c FROM Contact WHERE Id=:ID]; }
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-08-05
*/

public class SoqlSecurityEnforcedValidation implements IValidation {
	
	private static final String QUERY_PATTERN = "(.*)database.query(.*)";
	private static final String IF_BRACKET = "if(";
	private static final String SCHEMA_SOBJECT_TYPE = "Schema.SObjectType.";
	private static final String FIELDS = ".Fields.";
	private static final String IS_ACCESSIBLE = ".isAccessible()";
	private static final String BOOLEAN_AND = " && ";
	private static final String ROUND_CURLY_BRACE = ") { ";
	private static final String NEW_OBJECT_END = ");";
	private static final Pattern AS_PATTERN = Pattern.compile("\\s+as\\s+", Pattern.CASE_INSENSITIVE);
	private static final Pattern FROM_TABLENAME_PATTERN = Pattern.compile("FROM\\s+[a-zA-Z0-9_]*\\s*", Pattern.CASE_INSENSITIVE);
	private static final String CUSTOM_METADATA_QUERY_PATTERN = "__mdt";
	private static final List<String> FIELD_ACCESSIBILITY_KEYWORDS_1 = Arrays.asList("isAccessible()","Schema","SObjectType");
	private static final List<String> FIELD_ACCESSIBILITY_KEYWORDS_2 = Arrays.asList("isAuthorizedToView","getFieldsForAuthorisedView");
	private static final List<String> FIELD_ACCESSIBILITY_KEYWORDS_3 = Arrays.asList("sObjectType","getDescribe()");
	
	private static final Pattern INLINE_SELECT_PATTERN_START = Pattern.compile("\\(\\s*SELECT[a-zA-Z0-9 ]*");
	private static final Pattern INLINE_SELECT_PATTERN_END = Pattern.compile("FROM\\s*[a-zA-Z0-9 ]*\\)");
	private static final Pattern FROM_PATTERN = Pattern.compile("[^(]FROM\\s*[a-zA-Z0-9, ]*[^)]");

	private static final Pattern WHERE_PATTERN = Pattern.compile("WHERE\\s*[a-zA-Z0-9, ]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern GROUP_BY_PATTERN = Pattern.compile("GROUP BY\\s*[a-zA-Z0-9, ]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern ORDER_BY_PATTERN = Pattern.compile("ORDER BY\\s*[a-zA-Z0-9, ]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern LIMIT_PATTERN = Pattern.compile("LIMIT\\s*[0-9]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern OFFSET_PATTERN = Pattern.compile("OFFSET\\s*[0-9]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern WHEN_PATTERN = Pattern.compile("\\s*WHEN\\s*[a-zA-Z0-9]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern THEN_PATTERN = Pattern.compile("\\s*THEN\\s*[a-zA-Z0-9]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern ELSE_PATTERN = Pattern.compile("\\s*ELSE\\s*[a-zA-Z0-9]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern END_PATTERN = Pattern.compile("\\s*END\\s*", Pattern.CASE_INSENSITIVE);
	private static final Pattern TYPE_OF_PATTERN = Pattern.compile("\\s*TYPEOF\\s*[a-zA-Z0-9_]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern AND_PATTERN = Pattern.compile("\\s*AND\\s*[a-zA-Z0-9_]*", Pattern.CASE_INSENSITIVE);
	private static final Pattern ROUND_BRAC_OPEN_PATTERN = Pattern.compile("\\(");
	private static final Pattern ROUND_BRAC_CLOSE_PATTERN = Pattern.compile("\\)");
	private static final Pattern GROUPING_PATTERN = Pattern.compile("GROUPING\\([a-zA-Z0-9 ]*\\)", Pattern.CASE_INSENSITIVE);
	private static final Pattern IF_PATTERN = Pattern.compile("if", Pattern.CASE_INSENSITIVE);
	private static final Pattern SINGLE_LINE_COMMENT_PATTERN = Pattern.compile("^\\s*\\/\\/[\\w]*");
	private static final Pattern ALL_WHITE_SPACE_PATTERN = Pattern.compile("^\\s+$");
	private static final Pattern SOQL_SELECT_PATTERN = Pattern.compile("\\[\\s*SELECT", Pattern.CASE_INSENSITIVE);
	private static final Pattern SOQL_END_PATTERN = Pattern.compile("[a-zA-Z]*[^\\[\\d\\]]\\w*\\s*\\]\\s*");	
	private static final Pattern FOR_LOOP_PATTERN = Pattern.compile("^\\s*for\\s*\\(", Pattern.CASE_INSENSITIVE);
	private static final Pattern NEW_OBJECT_PATTERN = Pattern.compile("[\\w ]*[=]{1}\\s*new\\s*", Pattern.CASE_INSENSITIVE);
	private static final Pattern EQUALS_SOQL_PATTERN = Pattern.compile("[\\w\\[\\]<> ]*[=]{1}\\s*\\[\\s*SELECT\\s*\\w*\\s*", Pattern.CASE_INSENSITIVE);
	private static final Pattern EQUALS_PATTERN = Pattern.compile("[\\w\\[\\]<> ]*[=]{1}\\s*$", Pattern.CASE_INSENSITIVE);
	private static final Pattern FIRST_CHARACTER_PATTERN = Pattern.compile("\\[|\\w+", Pattern.CASE_INSENSITIVE);
	private static final Pattern METHOD_PATTERN = Pattern.compile("\\s*( |private|public|protected|global)[\\w ]+\\([\\w <>,.\\[\\]]*\\)\\s*\\{", Pattern.CASE_INSENSITIVE);
	private static final Pattern ACCESS_CHECK_PATTERN = Pattern.compile("[\\w]+\\.sObjectType", Pattern.CASE_INSENSITIVE);
	private static final Pattern ACCESS_FIELDS_CHECK_PATTERN = Pattern.compile("SObjectType.[\\w]+\\.Fields", Pattern.CASE_INSENSITIVE);
	private static final Pattern ACCESS_FIELDS_NEWSOBJECT_PATTERN = Pattern.compile("get\\('[\\w]+'\\)+\\.newSObject\\(\\)", Pattern.CASE_INSENSITIVE);

	private static final String SELECT_AND_FROM = "select&from";
	
	private static Matcher fromTablePatternMatcher = null;
	private static Matcher fromPatternMatcher = null;
	
	private static Deque<String> accessCurlyDeque;
	private Deque<String> forLoopCurlyDeque;
	private Deque<String> methodCurlyDeque;
	private static boolean fieldMatch;
	private List<String> soqlQueryLines;
	
	private boolean loopEnd = false;
	private boolean forLoopFound = false;
	private boolean soqlFound = false;
	private boolean newObjectFound = false;
	private boolean equalsFound = false;
	private boolean methodFound = false;
	private boolean fromClauseFound = false;
	private static boolean ifClauseFound = false;
	private static String accessObjName = AppConstants.EMPTY;

	
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<>();
		List<Violation> lstViolation = null;
		List<String> lstLines = null;
		
		Map<Integer, String> lineMap = new LinkedHashMap<>();
		Map<Integer, String> fieldAccessLineMap = new LinkedHashMap<>();
		int lineNum = 0;
		boolean securityEnforcedClausePresent = false;
		Deque<String> commentsDeque = new ArrayDeque<>();
		Violation violation = null;
		Matcher singleLineCommentMatcher;
		Matcher allWhiteSpaceMatcher;
		
		for (String filePath : fileNameLst) {
			try {
				accessCurlyDeque = new ArrayDeque<>();
				forLoopCurlyDeque = new ArrayDeque<>();
				methodCurlyDeque = new ArrayDeque<>();
				soqlQueryLines = new ArrayList<>();
				fieldMatch = false;
				methodFound = false;
				fromClauseFound = false;
				ifClauseFound = false;
				accessObjName = AppConstants.EMPTY;
				lineNum = 0;
				lstLines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
				
				//Skip violation check if it is a test class
				if(!isTestClass(lstLines)) {
					lstViolation = new ArrayList<>();

					resetVariables(lineMap);
					
					for(String codeline : lstLines) {
						lineNum++;
						
						singleLineCommentMatcher = SINGLE_LINE_COMMENT_PATTERN.matcher(codeline);
						allWhiteSpaceMatcher = ALL_WHITE_SPACE_PATTERN.matcher(codeline);
						
						pushCommentedLines(codeline, commentsDeque);
						isMethod(codeline, commentsDeque);
						
						/*1. Consider the line only if it does not contain custom metadata queries, database queries
						and usage of "WITH SECURITY_ENFORCED" clause
						2. Also, verify that the line is not commented
						3. Look for SOQL statements only if they are written inside a method*/
						if (!containsCustomMetadataQuery(codeline) && !containsDatabaseQuery(codeline)								
								&& !singleLineCommentMatcher.find() && !allWhiteSpaceMatcher.find() && methodFound) {

							// If a multiline comment has started previously, then skip lines until it ends
							if (!commentsDeque.isEmpty() && !AppConstants.COMMENT_END_PATTERN.equals(commentsDeque.peek())) {
								continue;
							}

							// Check if the line has field accessibility checks using schema functions
							hasFieldAccessibilityCheck(codeline, fieldAccessLineMap, lineNum);

							// Check if the "WITH SECURITY_ENFORCED" clause is already used in the line
							securityEnforcedClausePresent = containsSecurityEnforcedClause(codeline);
							
							//Check for SOQL statement according to the way in which it is written
							checkSoqlType(securityEnforcedClausePresent,lineMap,lineNum,codeline);

							//If "WITH SECURITY_ENFORCED" clause is already being used, then the SOQL query needs to be ignored
							if (securityEnforcedClausePresent && !lineMap.isEmpty()) {

								lineMap.clear();
								soqlQueryLines.clear();
							}
							
							if(methodCurlyDeque != null && methodCurlyDeque.isEmpty()) {
								methodFound = false;
							}
						}
						
						if(!soqlQueryLines.isEmpty() && loopEnd) {
							
							//Process the SOQL query and create Violation object
							violation = processSOQL(soqlQueryLines, lineMap);
							if(violation != null) {
								lstViolation.add(violation);	
							}
						
							resetVariables(lineMap);
						}
					}

					//File processing completed, now adding violations to the file
					if (!lstViolation.isEmpty()) {
						lstFiles.add(getFile(filePath, lstViolation));
					}
				}
			}catch (Exception e) {
				Logging.log(e,"Error occurred for file :: "+filePath);
			}
		}
		return lstFiles;
	}
	
	
	/**
     * Method name  : checkSoqlType
     * Description  : Process and add the SOQL lines along with the surrounding parts to a map
     * Example #1	: for(Contact cntc : [Select AccountId from contact where AccountId in : accntIds])
            	 	  {
                		accContMap.put(cntc.AccountId, cntc.Id);
                	  }
                	  
     * Example #2	: tmpltMap = new Map<Id, HealthCloudGA__CarePlanTemplate__c> ([select ID, Name, HealthCloudGA__Description__c, 
                	  PSP_Care_Coordinator_Default_User__c from HealthCloudGA__CarePlanTemplate__c where ID in :tempIdEPSMap.keySet()]); 
     * Return Type  : void
     * Parameter    : boolean securityEnforcedClausePresent, Map<Integer, String> lineMap, int lineNum, String codeline
     **/
	private void checkSoqlType(boolean securityEnforcedClausePresent, Map<Integer, String> lineMap, int lineNum, String codeline) {
		
		Matcher forPatternMatcher = FOR_LOOP_PATTERN.matcher(codeline);						
		Matcher newObjectMatcher = NEW_OBJECT_PATTERN.matcher(codeline);
		Matcher equalsSoqlMatcher = EQUALS_SOQL_PATTERN.matcher(codeline);
		Matcher equalsMatcher = EQUALS_PATTERN.matcher(codeline);
		Matcher soqlSelectMatcher = SOQL_SELECT_PATTERN.matcher(codeline);
		Matcher soqlEndMatcher = SOQL_END_PATTERN.matcher(codeline);
		
		//If "for" loop is encountered and inside that, SOQL query is being used
		if ((forPatternMatcher.find() || forLoopFound) && !securityEnforcedClausePresent) {

			forLoopFound = true;
			loopEnd = false;
			lineMap.put(lineNum, codeline);

			checkForSoql(codeline, soqlSelectMatcher, soqlEndMatcher);

			processForLoopBraces(codeline, lineMap);
			
		}
		//If "new object" is being created and inside that, SOQL query is being used
		else if ((newObjectMatcher.find() || newObjectFound) && !securityEnforcedClausePresent) {

			newObjectFound = true;
			loopEnd = false;
			lineMap.put(lineNum, codeline);

			checkForSoql(codeline, soqlSelectMatcher, soqlEndMatcher);

			processLineEnd(codeline, lineMap, AppConstants.NEW_STR);

		} 
		//If "=" is encountered followed by usage of SOQL query
		else if ((equalsSoqlMatcher.find() || equalsMatcher.find() || equalsFound)
				&& !securityEnforcedClausePresent) {

			equalsFound = true;
			loopEnd = false;
			lineMap.put(lineNum, codeline);

			checkForSoql(codeline, soqlSelectMatcher, soqlEndMatcher);

			processLineEnd(codeline, lineMap, AppConstants.EQUALS_STR);
			
		} 
		//If only SOQL query is encountered
		else if ((soqlSelectMatcher.find() || soqlFound) && !securityEnforcedClausePresent) {
			soqlFound = true;
			loopEnd = false;

			lineMap.put(lineNum, codeline);
			soqlQueryLines.add(codeline);

			if (soqlEndMatcher.find()) {
				soqlFound = false;
				loopEnd = true;
			}
		}
	}
	
	
	/**
     * Method name  : resetVariables
     * Description  : Resets all the variables required for the logic
     * Return Type  : void
     * Parameter    : Map<Integer, String> lineMap
     **/
	private void resetVariables(Map<Integer, String> lineMap) {
		
		soqlQueryLines.clear();
		lineMap.clear();
		soqlFound = false;
		forLoopFound = false;
		newObjectFound = false;
		equalsFound = false;
		loopEnd = false;
	}
	
	
	/**
     * Method name  : processForLoopBraces
     * Description  : Processes the braces after for loop to determine where it ends
     * Return Type  : void
     * Parameter    : String codeline, Map<Integer, String> lineMap
     **/
	private void processForLoopBraces(String codeline, Map<Integer, String> lineMap) {
		
		long bracesCount = 0;
		
		if (codeline.contains(AppConstants.OPEN_BRACES_STR)) {
			bracesCount = codeline.chars().filter(ch -> ch == AppConstants.OPEN_BRACES_CHAR).count();
			LongStream.range(1, bracesCount + 1)
					.forEach(brace -> forLoopCurlyDeque.push(AppConstants.OPEN_BRACES_STR));
		}
		if (codeline.contains(AppConstants.CLOSE_BRACES_STR)) {

			bracesCount = codeline.chars().filter(ch -> ch == AppConstants.CLOSE_BRACES_CHAR).count();
			LongStream.range(1, bracesCount + 1).forEach(brace -> { 
				if(!forLoopCurlyDeque.isEmpty())forLoopCurlyDeque.pop(); 
			});

			if (forLoopCurlyDeque.isEmpty()) {
				loopEnd = true;
				forLoopFound = false;

				if (soqlQueryLines.isEmpty()) {
					soqlFound = false;
					lineMap.clear();
				}
			}
		}
	}
	
	
	/**
     * Method name  : processLineEnd
     * Description  : Processes the line based on filter to determine where it ends
     * Return Type  : void
     * Parameter    : String codeline, Map<Integer, String> lineMap, String filter
     **/
	private void processLineEnd(String codeline, Map<Integer, String> lineMap, String filter) {
		
		if(AppConstants.NEW_STR.equalsIgnoreCase(filter) && codeline.contains(NEW_OBJECT_END)){
			loopEnd = true;
			newObjectFound = false;

			if (soqlQueryLines.isEmpty()) {
				soqlFound = false;
				lineMap.clear();
			}
		}
		else if (AppConstants.EQUALS_STR.equalsIgnoreCase(filter) && codeline.contains(AppConstants.SEMI_COLON_CHARACTER)) {
			loopEnd = true;
			equalsFound = false;

			if (soqlQueryLines.isEmpty()) {
				soqlFound = false;
				lineMap.clear();
			}
		}
	}

	
	/**
     * Method name  : checkForSoql
     * Description  : Checks for start and end of SOQL query in the current line
     * Return Type  : void
     * Parameter    : String codeline, Matcher soqlSelectMatcher, Matcher soqlEndMatcher
     **/
	private void checkForSoql(String codeline, Matcher soqlSelectMatcher, Matcher soqlEndMatcher) {
		
		soqlSelectMatcher = SOQL_SELECT_PATTERN.matcher(codeline);
		soqlEndMatcher = SOQL_END_PATTERN.matcher(codeline);				
		
		if(soqlSelectMatcher.find() || soqlFound) {
			soqlFound = true;
			soqlQueryLines.add(codeline.trim());
			
			if(soqlEndMatcher.find()) {
				soqlFound = false;
			}
		}
	}
	

	/**
     * Method name  : getFile
     * Description  : Sets the list of violations in a File object for the concerned file
     * Return Type  : File
     * Parameter    : String filePath, List<Violation> lstViolation
     **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;
	}
	
	
	/**
     * Method name  : pushCommentedLines
     * Description  : Pushes comments in lines to a deque which is used for comparison
     * Return Type  : void
     * Parameter    : String codeline, Deque<String> commentsDeque
     **/
	private static void pushCommentedLines(String codeline, Deque<String> commentsDeque) {
		
		//Push to deque if multiline comment start is found
		if(codeline.contains(AppConstants.COMMENT_START_PATTERN))
			commentsDeque.push(AppConstants.COMMENT_START_PATTERN);
		
		//Push to deque if multiline comment end is found
		if(codeline.contains(AppConstants.COMMENT_END_PATTERN))
			commentsDeque.push(AppConstants.COMMENT_END_PATTERN);
	}
	
	
	/**
     * Method name  : processSOQL
     * Description  : Process the SOQL statements depending on whether the whole statement is found
     * Return Type  : void
     * Parameter    : Map<Integer, String> soqlQueryMap, Map<Integer, String> lineMap
     **/
	private Violation processSOQL(List<String> soqlQueryMap, Map<Integer, String> lineMap) {
		
		Object[] result = fetchColumnAndObjectNames(soqlQueryMap);
		List<String> selectedColumns = null;
		List<String> objectName = null;

		if (result != null && result.length > 0) {
			selectedColumns = (ArrayList<String>) result[0];
			objectName = (ArrayList<String>) result[1];
		}

		if (selectedColumns != null && !selectedColumns.isEmpty() && objectName != null && !objectName.isEmpty()
				&& (accessCurlyDeque.isEmpty() || (!accessCurlyDeque.isEmpty() && !accessObjName.equals(objectName.get(0))))) {
			return createViolation(lineMap, selectedColumns, objectName.get(0));
		}
		else { 
			return null;
		}
	}
	
	/**
     * Method name  : containsMetadataQuery
     * Description  : Returns if the given piece of code contains custom metadata query
     * Return Type  : boolean
     * Parameter    : String codeLine
     **/
	private static boolean containsCustomMetadataQuery(String codeLine) {
		return codeLine.toLowerCase().contains(CUSTOM_METADATA_QUERY_PATTERN);		
	}
	
	/**
     * Method name  : containsDatabaseQuery
     * Description  : Returns if the given piece of code contains database query in string format
     * Return Type  : boolean
     * Parameter    : String codeLine
     **/
	private static boolean containsDatabaseQuery(String codeLine) {
		return codeLine.toLowerCase().contains(QUERY_PATTERN);
	}
	
	
	/**
     * Method name  : isMethod
     * Description  : Identifies if the given piece of code is a method or part of a method
     * Return Type  : void
     * Parameter    : String codeLine, Deque<String> commentsDeque
     **/
	private void isMethod(String codeLine, Deque<String> commentsDeque) {
		
		Matcher methodPatternMatcher = METHOD_PATTERN.matcher(codeLine);
		Matcher singleLineCommentMatcher = SINGLE_LINE_COMMENT_PATTERN.matcher(codeLine);
		
		if(!commentsDeque.isEmpty() && !AppConstants.COMMENT_END_PATTERN.equals(commentsDeque.peek())) {
			return;
		}
		
		if((methodPatternMatcher.find() || methodFound) && !singleLineCommentMatcher.find()) {
			methodFound = true;
			
			if(codeLine.contains(AppConstants.OPEN_BRACES_STR) && codeLine.contains(AppConstants.CLOSE_BRACES_STR) && codeLine.indexOf(AppConstants.CLOSE_BRACES_STR) < codeLine.indexOf(AppConstants.OPEN_BRACES_STR)) {
				methodCurlyDeque.pop();
				methodCurlyDeque.push(AppConstants.OPEN_BRACES_STR);
			}
			else if(codeLine.contains(AppConstants.OPEN_BRACES_STR) && codeLine.contains(AppConstants.CLOSE_BRACES_STR) && codeLine.indexOf(AppConstants.CLOSE_BRACES_STR) > codeLine.indexOf(AppConstants.OPEN_BRACES_STR)) {
				methodCurlyDeque.push(AppConstants.OPEN_BRACES_STR);				
				methodCurlyDeque.pop();								
			}
			else if(codeLine.contains(AppConstants.OPEN_BRACES_STR)) {
				methodCurlyDeque.push(AppConstants.OPEN_BRACES_STR);
			}
			else if(codeLine.contains(AppConstants.CLOSE_BRACES_STR)) {				
				methodCurlyDeque.pop();				
			}			
		}
	}
	
	
	/**
     * Method name  : containsSecurityEnforcedClause
     * Description  : Returns if the given piece of code contains usage of the "WITH SECURITY_ENFORCED" clause
     * Return Type  : boolean
     * Parameter    : String pieceOfCode
     **/
	private static boolean containsSecurityEnforcedClause(String codeLine) {
		return codeLine.toUpperCase().contains(AppConstants.WITH_SECURITY_ENFORCED_CLAUSE);				
	}
	
	
	/**
     * Method name  : hasFieldAccessibilityCheck
     * Description  : Checks if the given piece of code has field accessibility checks using schema functions
     * Return Type  : boolean
     * Parameter    : String codeline, Map<Integer, String> fieldAccessLineMap, int lineNum
     **/
	private static void hasFieldAccessibilityCheck(String codeline, Map<Integer, String> fieldAccessLineMap, int lineNum) {		
		
		Matcher ifPatternMatcher = IF_PATTERN.matcher(codeline);
		Matcher accessCheckMatcher = ACCESS_CHECK_PATTERN.matcher(codeline);
		Matcher accessFieldsCheckMatcher = ACCESS_FIELDS_CHECK_PATTERN.matcher(codeline);
		Matcher accessFieldsNewSObjectPattern = ACCESS_FIELDS_NEWSOBJECT_PATTERN.matcher(codeline);
		String accessSubString;
		
		if (ifPatternMatcher.find()) {
			ifClauseFound = true;
		}
		
		if(ifClauseFound && (FIELD_ACCESSIBILITY_KEYWORDS_1.stream().allMatch(codeline :: contains) || FIELD_ACCESSIBILITY_KEYWORDS_2.stream().allMatch(codeline :: contains) || fieldMatch
				|| FIELD_ACCESSIBILITY_KEYWORDS_3.stream().allMatch(codeline :: contains) || codeline.contains("isAccessible()"))) {
			
				fieldMatch = true;
				
				if(accessFieldsCheckMatcher.find()) {
					accessSubString = codeline.substring(accessFieldsCheckMatcher.start(), accessFieldsCheckMatcher.end());
					accessObjName = accessSubString.substring(accessSubString.indexOf('.')+1, accessSubString.lastIndexOf('.'));
				}
				else if(accessCheckMatcher.find()) {
					accessSubString = codeline.substring(accessCheckMatcher.start(), accessCheckMatcher.end());
					accessObjName = accessSubString.substring(0, accessSubString.indexOf('.'));
				}
				else if(accessFieldsNewSObjectPattern.find()) {
					accessSubString = codeline.substring(accessFieldsNewSObjectPattern.start(), accessFieldsNewSObjectPattern.end());
					accessObjName = accessSubString.substring(accessSubString.indexOf("'")+1, accessSubString.lastIndexOf("'"));
				}
				
				if (codeline.contains(AppConstants.OPEN_BRACES_STR) && codeline.contains(AppConstants.CLOSE_BRACES_STR) 
						&& codeline.indexOf(AppConstants.CLOSE_BRACES_STR) < codeline.indexOf(AppConstants.OPEN_BRACES_STR)
						&& !accessCurlyDeque.isEmpty()) {

					accessCurlyDeque.pop();
					accessCurlyDeque.push(AppConstants.OPEN_BRACES_STR);
				} 
				else if (codeline.contains(AppConstants.OPEN_BRACES_STR) && codeline.contains(AppConstants.CLOSE_BRACES_STR) 
						&& codeline.indexOf(AppConstants.CLOSE_BRACES_STR) > codeline.indexOf(AppConstants.OPEN_BRACES_STR)
						&& !accessCurlyDeque.isEmpty()) {
					accessCurlyDeque.push(AppConstants.OPEN_BRACES_STR);

					accessCurlyDeque.pop();
					isEmptyAccessDeque();
				} 
				else if (codeline.contains(AppConstants.OPEN_BRACES_STR)) {
					accessCurlyDeque.push(AppConstants.OPEN_BRACES_STR);
				} 
				else if (codeline.contains(AppConstants.CLOSE_BRACES_STR) && !accessCurlyDeque.isEmpty()) {

					accessCurlyDeque.pop();
					isEmptyAccessDeque();
				}
			}
		}
			
	
	/**
     * Method name  : isEmptyAccessDeque
     * Description  : Method to check whether the accessibility checking function has ended
     * Return Type  : void
     * Parameter    : None
     **/
	private static void isEmptyAccessDeque() {
		
		if(accessCurlyDeque.isEmpty()) {
			fieldMatch = false;
			ifClauseFound = false;
			accessObjName = AppConstants.EMPTY;
		}
	}
	
	
	/**
     * Method name  : createViolation
     * Description  : Prepares violation object within the given piece of code
     * Return Type  : Violation
     * Parameter    : Map<Integer,String> lineMap, List<String> selectedColumns, String objectName
     **/
	private static Violation createViolation(Map<Integer,String> lineMap, List<String> selectedColumns, String objectName) {
		
		String beginLine = lineMap.get((Integer)lineMap.keySet().toArray()[0]);
		String endLine = lineMap.get((Integer)lineMap.keySet().toArray()[lineMap.size() - 1]);
		Matcher firstCharacterMatcher = FIRST_CHARACTER_PATTERN.matcher(beginLine);
		
		Violation violation = new Violation();
		violation.setBeginline(BigInteger.valueOf((Integer)lineMap.keySet().toArray()[0]));
		if(firstCharacterMatcher.find()) {
			violation.setBegincolumn(BigInteger.valueOf(firstCharacterMatcher.start()));
		}
		else {
			violation.setBegincolumn(BigInteger.valueOf(0));
		}
		violation.setEndline(BigInteger.valueOf((Integer)lineMap.keySet().toArray()[lineMap.size() - 1]));
		violation.setEndcolumn(BigInteger.valueOf(endLine.length()));		
		violation.setRule(CustomValidationRules.SOQL_SECURITY_ENFORCED);
		
		StringBuilder correctValue = new StringBuilder();
		
		if (selectedColumns != null) {
			ListIterator<String> iterator = selectedColumns.listIterator();
			
			// Append the field accessibility if condition - START
			correctValue.append(IF_BRACKET);

			while (iterator.hasNext()) {
				String column = iterator.next();

				correctValue.append(SCHEMA_SOBJECT_TYPE).append(objectName).append(FIELDS).append(column)
						.append(IS_ACCESSIBLE);

				// If there is more than 1 select column, then add "&&" in the if condition
				if (iterator.hasNext()) {
					correctValue.append(BOOLEAN_AND);
				}
			}

			correctValue.append(ROUND_CURLY_BRACE);
			// Append the field accessibility if condition - END
		}
		
		violation.setValue(correctValue.toString());
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		return violation;	
	}
	
	
	/**
     * Method name  : fetchColumnAndObjectNames
     * Description  : Returns the selected column names and the object name from the SOQL query
     * Return Type  : Object[]
     * Parameter    : List<String> lineMap
     **/
	private Object[] fetchColumnAndObjectNames(List<String> lineMap) {
		
		String selectedColumns = "";
		String objectName = "";
		List<String> columnNames = new ArrayList<>();
		List<String> objectNameList = new ArrayList<>();
		String[] multiSelectSplit = null;				
		
		boolean roundBracOpenFound = false;
		boolean roundBracCloseFound = false;
		boolean multiSelectFound = false;
		String fromAfterInlineQuery = "";
		Object[] innerQueryFound;		
		
		//Iterate over all lines in a SOQL statement
		for(String codeLine : lineMap) {									
			
			int selectCount = codeLine.toUpperCase().split(AppConstants.SELECT_CLAUSE).length - 1;
			
			if (selectCount > 1 || multiSelectFound) {

				if(!multiSelectFound) { 
					multiSelectFound = true; 
				}
								
				multiSelectSplit = codeLine.split(AppConstants.COMMA_STRING);
				fromTablePatternMatcher = FROM_TABLENAME_PATTERN.matcher(codeLine);				

				for (String column : multiSelectSplit) {

					innerQueryFound = checkForInnerQuery(column, roundBracOpenFound, roundBracCloseFound, fromAfterInlineQuery);
					
					//Get all values returned from checkForInnerQuery()
					roundBracOpenFound = (Boolean) innerQueryFound[0];
					roundBracCloseFound = (Boolean) innerQueryFound[1];
					fromAfterInlineQuery = (String) innerQueryFound[2];
					fromPatternMatcher = (Matcher) innerQueryFound[3];

					//Only process further if inner SELECT query is not found
					if (!roundBracOpenFound && !roundBracCloseFound) {

						objectName = getObjectName(column, selectedColumns, columnNames, objectName);
						if(objectName != null && !AppConstants.EMPTY.equals(objectName)) {
							objectNameList.add(objectName);
						}
					}
					else if (fromPatternMatcher!=null && fromPatternMatcher.find()) {
						objectName = getObjectNameAfterInnerQuery(fromAfterInlineQuery, fromTablePatternMatcher, objectName);
						if(objectName != null && !AppConstants.EMPTY.equals(objectName)) {
							objectNameList.add(objectName);
						}
					}

					if (roundBracCloseFound) {
						roundBracCloseFound = false;
						multiSelectFound = false;
					}
				}
			}
			//If the current line does not have an inner SELECT query
			else {
				processForSingleSelect(codeLine, selectedColumns, columnNames, objectNameList);
			}
		}
		return new Object[] {columnNames, objectNameList};
	}
	
	
	/**
     * Method name  : addSelectedColumnsToList
     * Description  : This method gets the column names that are being selected in the SOQL query and adds them to list
     * Return Type  : void
     * Parameter    : String codeLine, String selectedColumns, List<String> columnNames
     **/
	private static void addSelectedColumnsToList(String codeLine, String selectedColumns, List<String> columnNames) {
		
		String[] splitByComma = selectedColumns.split(AppConstants.COMMA_STRING);
		Matcher asPatternMatcher = null;
		
		for(String column : splitByComma) {
			asPatternMatcher = AS_PATTERN.matcher(codeLine.toLowerCase());
			
			if(asPatternMatcher.find()) {
				columnNames.add(column.substring(column.toLowerCase().indexOf(AppConstants.AS_CLAUSE)+2, column.length()).trim());
			}
			else if(column.indexOf(AppConstants.OPEN_BRACKET_STR) != -1 && column.indexOf(AppConstants.CLOSE_BRACKET_STR) != -1
					&& column.indexOf(AppConstants.CLOSE_BRACKET_STR) - column.indexOf(AppConstants.OPEN_BRACKET_STR) > 1) {
				columnNames.add(column.substring(column.indexOf(AppConstants.OPEN_BRACKET_STR) + 1, column.indexOf(AppConstants.CLOSE_BRACKET_STR)));
			}
			else if(!AppConstants.EMPTY.equals(column) && !AppConstants.SPACE.equals(column) && !column.contains(AppConstants.OPEN_BRACKET_STR) && !column.contains(AppConstants.CLOSE_BRACKET_STR)) {
				columnNames.add(column.trim());
			}
		}
	}
	
	
	/**
     * Method name  : getObjectNameAfterInnerQuery
     * Description  : This method gets the object name from the SOQL query and returns it
     * Return Type  : String
     * Parameter    : String codeLine, Matcher fromTablePatternMatcher, String objectName
     **/
	private String getObjectNameAfterInnerQuery(String codeLine, Matcher fromTablePatternMatcher, String objectName) {
		
		Pattern TABLENAME_PATTERN = Pattern.compile("\\s*[a-zA-Z0-9_]+\\s*", Pattern.CASE_INSENSITIVE);
		Matcher tableNameMatcher = TABLENAME_PATTERN.matcher(codeLine);
		
		fromTablePatternMatcher = FROM_TABLENAME_PATTERN.matcher(codeLine.toUpperCase());
		if(fromTablePatternMatcher.find()) {
			
			objectName = codeLine.substring(codeLine.toUpperCase().indexOf(AppConstants.FROM_CLAUSE) + 4, fromTablePatternMatcher.end()).trim();
		}
			
		if(fromClauseFound && tableNameMatcher.find() && (AppConstants.EMPTY.equals(objectName) || objectName == null)) {
				objectName = codeLine.substring(tableNameMatcher.start(), tableNameMatcher.end()).trim();
				fromClauseFound = false;
		}
		
		if(codeLine.toUpperCase().contains(AppConstants.FROM_CLAUSE) && (AppConstants.EMPTY.equals(objectName) || objectName == null)) {
			fromClauseFound = true;
		}
		return objectName;
	}
	
	
	/**
     * Method name  : getObjectName
     * Description  : This method retrieves the selected column names from SOQL and adds them to list. 
     * 				  Also, the object name from the SOQL statement is retrieved and returned 
     * Return Type  : void
     * Parameter    : String column, String selectedColumns, List<String> columnNames, String objectName
     **/
	private String getObjectName (String column, String selectedColumns, List<String> columnNames, String objectName) {
		
		Matcher wherePatternMatcher = WHERE_PATTERN.matcher(column);
		Matcher groupByPatternMatcher = GROUP_BY_PATTERN.matcher(column);
		Matcher orderByPatternMatcher = ORDER_BY_PATTERN.matcher(column);
		Matcher limitPatternMatcher = LIMIT_PATTERN.matcher(column);
		Matcher offsetPatternMatcher = OFFSET_PATTERN.matcher(column);
		Matcher whenPatternMatcher = WHEN_PATTERN.matcher(column);
		Matcher thenPatternMatcher = THEN_PATTERN.matcher(column);
		Matcher elsePatternMatcher = ELSE_PATTERN.matcher(column);
		Matcher endPatternMatcher = END_PATTERN.matcher(column);
		Matcher typeOfPatternMatcher = TYPE_OF_PATTERN.matcher(column);
		Matcher andPatternMatcher = AND_PATTERN.matcher(column);
		Matcher roundBracOpenPatternMatcher = ROUND_BRAC_OPEN_PATTERN.matcher(column);
		Matcher roundBracClosePatternMatcher = ROUND_BRAC_CLOSE_PATTERN.matcher(column);
		Matcher groupingPatternMatcher = GROUPING_PATTERN.matcher(column);
		Matcher fromTablePatternMatcher = FROM_TABLENAME_PATTERN.matcher(column);
		
		String[] commaSeparated;
		
		//If string contains both SELECT and FROM clauses
		if (column.toUpperCase().contains(AppConstants.SELECT_CLAUSE) && column.toUpperCase().contains(AppConstants.FROM_CLAUSE)) {			
			
			selectedColumns = checkFunctionUsage(column, SELECT_AND_FROM);									

			addSelectedColumnsToList(column, selectedColumns, columnNames);

			objectName = getObjectNameAfterInnerQuery(column, fromTablePatternMatcher, objectName);
		}
		//If string contains only SELECT clause
		else if (column.toUpperCase().contains(AppConstants.SELECT_CLAUSE)) {
			
			selectedColumns = checkFunctionUsage(column, AppConstants.SELECT_CLAUSE);

			addSelectedColumnsToList(column, selectedColumns, columnNames);
		}
		//If string contains only FROM clause
		else if (column.toUpperCase().contains(AppConstants.FROM_CLAUSE) || fromClauseFound) {
			objectName = getObjectNameAfterInnerQuery(column, fromTablePatternMatcher, objectName);
		}
		//If string contains TYPEOF clause
		else if (typeOfPatternMatcher.find()) {
			columnNames.add(column.substring(column.indexOf(AppConstants.TYPEOF_CLAUSE)+6, typeOfPatternMatcher.end()).trim());
		}
		//If string contains GROUPING clause
		else if (groupingPatternMatcher.find() && column.indexOf(AppConstants.CLOSE_BRACKET_STR) - column.indexOf(AppConstants.OPEN_BRACKET_STR) > 1) {
			columnNames.add(column.substring(groupingPatternMatcher.start()+9, typeOfPatternMatcher.end()-1).trim());
		}
		//If string contains only commas
		else if (column.contains(AppConstants.COMMA_STRING)) {
			
			commaSeparated = column.split(AppConstants.COMMA_STRING);
			for(String col : commaSeparated) {
					columnNames.add(col.trim());
			}
		}
		//If string contains only column name and no other functions, clauses or blanks
		else if (!groupByPatternMatcher.find() && !orderByPatternMatcher.find() && !limitPatternMatcher.find() && !offsetPatternMatcher.find()
				&& !whenPatternMatcher.find() && !thenPatternMatcher.find() && !elsePatternMatcher.find() && !endPatternMatcher.find() && !wherePatternMatcher.find()
				&& !andPatternMatcher.find() && !roundBracOpenPatternMatcher.find() && !roundBracClosePatternMatcher.find() && !AppConstants.EMPTY.equals(column) && !AppConstants.SPACE.equals(column)) {
			columnNames.add(column.trim());
		}
		
		return objectName;
	}
	
	
	/**
     * Method name  : isTestClass
     * Description  : This method checks if the current file is a test file
     * Return Type  : boolean
     * Parameter    : List<String> codelines
     **/
	private static boolean isTestClass(List<String> codelines) {
		for(String codeline : codelines) {
			if(codeline.toUpperCase().contains(AppConstants.IS_TEST_ANNOTATION)) {
				return true;
			} else if(codeline.toUpperCase().contains(AppConstants.LITERAL_CLASS)) {
				return false;
			}
		}
		return false;
	}
	
	
	/**
     * Method name  : checkForInnerQuery
     * Description  : This method checks for presence of inner query in the SOQL statement and returns if there is
     * 				  any FROM clause present after the inner query ends
     * Return Type  : Object[]
     * Parameter    : String column, boolean roundBracOpenFound, boolean roundBracCloseFound, String fromAfterInlineQuery
     **/
	private static Object[] checkForInnerQuery(String column, boolean roundBracOpenFound, boolean roundBracCloseFound, String fromAfterInlineQuery) {
		
		Matcher inlineSelectPatternStartMatcher = INLINE_SELECT_PATTERN_START.matcher(column);
		Matcher inlineSelectPatternEndMatcher = INLINE_SELECT_PATTERN_END.matcher(column);	
		Matcher fromPatternMatcher = FROM_TABLENAME_PATTERN.matcher(column);	

		//If open round bracket of inner query is found
		if (!roundBracOpenFound) {
			roundBracOpenFound = inlineSelectPatternStartMatcher.find();
		}

		//If close round bracket of inner query is not found
		if (!roundBracCloseFound) {
			roundBracCloseFound = inlineSelectPatternEndMatcher.find();
			if (roundBracCloseFound) {
				roundBracOpenFound = false;
				
				fromAfterInlineQuery = column.substring(inlineSelectPatternEndMatcher.end(), column.length());
				fromPatternMatcher = FROM_PATTERN.matcher(fromAfterInlineQuery);
			}
		}
		return new Object[] {roundBracOpenFound, roundBracCloseFound, fromAfterInlineQuery, fromPatternMatcher};
	}
	
	
	/**
     * Method name  : checkFunctionUsage
     * Description  : This method checks for usage of functions like MIN,MAX,GROUPING in the SOQL statement and returns the column names
     * Return Type  : Object[]
     * Parameter    : String column, String filter
     **/
	private static String checkFunctionUsage(String column, String filter) {
		
		//If string contains only SELECT clause
		if(AppConstants.SELECT_CLAUSE.equalsIgnoreCase(filter)) {
			return column.substring(column.toUpperCase().indexOf(AppConstants.SELECT_CLAUSE) + 6, column.length()).trim();
		}
		//If string contains both SELECT and FROM clauses
		else {
			return column.substring(column.toUpperCase().indexOf(AppConstants.SELECT_CLAUSE) + 6, column.toUpperCase().indexOf(AppConstants.FROM_CLAUSE));
		}			
	}
	
	
	/**
     * Method name  : processForSingleSelect
     * Description  : This method processes SOQL statements with single SELECT clause and returns the column name
     * Return Type  : Object[]
     * Parameter    : String codeLine, String selectedColumns, List<String> columnNames, List<String> objectNameList
     **/
	private void processForSingleSelect(String codeLine, String selectedColumns, List<String> columnNames, List<String> objectNameList) {
		
		boolean roundBracOpenFound = false;
		boolean roundBracCloseFound = false;
		String objectName = null;
		String fromAfterInlineQuery = null;
		
		Object[] innerQueryFound = checkForInnerQuery(codeLine, roundBracOpenFound, roundBracCloseFound, fromAfterInlineQuery);
		
		roundBracOpenFound = (Boolean) innerQueryFound[0];
		roundBracCloseFound = (Boolean) innerQueryFound[1];
		fromAfterInlineQuery = (String) innerQueryFound[2];
		fromPatternMatcher = (Matcher) innerQueryFound[3];		
		
		//Only process further if inner SELECT query is not found
		if (!roundBracOpenFound && !roundBracCloseFound) {
			objectName = getObjectName(codeLine, selectedColumns, columnNames, objectName);
		}
		else if (fromPatternMatcher!=null && fromPatternMatcher.find()) {
			objectName = getObjectNameAfterInnerQuery(fromAfterInlineQuery, fromTablePatternMatcher, objectName);
		}
				
		if(objectName != null && !AppConstants.EMPTY.equals(objectName)) {
			objectNameList.add(objectName);
		}
	}
	
}
