package org.autofix.model;

public class AutofixRuleSetting {
	
	private Autofix_Rule autoFixRule;
	private String ruleClassPath;
	private String validationClassPath;
	
	public Autofix_Rule getAutoFixRule() {
		return autoFixRule;
	}
	public void setAutoFixRule(Autofix_Rule autoFixRule) {
		this.autoFixRule = autoFixRule;
	}
	public String getRuleClassPath() {
		return ruleClassPath;
	}
	public void setRuleClassPath(String ruleClassPath) {
		this.ruleClassPath = ruleClassPath;
	}
	public String getValidationClassPath() {
		return validationClassPath;
	}
	public void setValidationClassPath(String validationClassPath) {
		this.validationClassPath = validationClassPath;
	}
}
