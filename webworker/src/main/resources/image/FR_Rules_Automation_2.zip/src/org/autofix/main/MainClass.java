package org.autofix.main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.autofix.common.ApplicationParameter;
import org.autofix.model.File;
import org.autofix.model.ObjectFactory;
import org.autofix.model.Pmd;
import org.autofix.model.Violation;
import org.autofix.utility.AppUtility;
import org.autofix.utility.FileUtility;
import org.autofix.utility.PMDUtility;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String binPath = ApplicationParameter.getPmdBinPath()+"pmd.bat";
		String src = "C:\\Users\\lbanerjee\\Desktop\\PMDTool\\APEXCode";
		String rule = ApplicationParameter.getPmdRulePath()+"ApexRules.xml";
		String reportFile = ApplicationParameter.getPmdReportPath()+"report.xml";
		
		String command = binPath+" -d "+src+" -R "+rule+" -f xml -reportfile "+reportFile;
		try {
			Process p = Runtime.getRuntime().exec(command);
			List<File> files = PMDUtility.scanSourceFolder(src);
			List<String> fileName = new ArrayList<String>();
			for(File f : files){
				fileName.add(f.getName());
			}
			FileUtility.copyFilesToDestinaionFolder(fileName, "C:\\Users\\lbanerjee\\Desktop\\Test","");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		/*try {
			Pmd p = AppUtility.getObject(ApplicationParameter.getPmdReportPath()+"report.xml", Pmd.class);
			List<File> f = p.getFile();
			Map<File, List<Violation>> map = new HashMap<File, List<Violation> >();
			for(File f1 : f){
				map.put(f1, f1.getViolation());
			}
			for(File f2 : map.keySet()){
				System.out.println(f2.getName());
				for(Violation v : f2.getViolation()){
					System.out.println(v.getValue());
				}
			}
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

}
