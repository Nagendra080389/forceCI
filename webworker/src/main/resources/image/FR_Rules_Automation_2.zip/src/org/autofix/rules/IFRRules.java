package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;

public interface IFRRules {

	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) throws CustomException;
	
}
