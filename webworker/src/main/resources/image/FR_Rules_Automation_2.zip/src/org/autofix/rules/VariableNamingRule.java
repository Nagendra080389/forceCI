/**************************************************************************************
Class Name		: VariableNamingRule
Version   		: 1.0 
Created Date	: 05 Apr 2020
Function   		: Class to fix variable naming violations.
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Nikhil Kumar			05/04/2020              Initial Version
*************************************************************************************/
package org.autofix.rules;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

public class VariableNamingRule implements IFRRules{
	//private static String variableShouldStartWithLowerCase = "Variables should start with a lowercase character";
	private static String finalStaticInCaps = "Variables that are final and static should be all capitals";
	String regexForUpperCaseVarName, regexForLowerCaseFinalStaticVar;
	Pattern pForUpperCaseVar, pForLowerCaseVar;
	Matcher mUpperCaseVar, mLowerCaseFinalStatic;

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		//List<String> lines = allLines;
		StringBuffer line,  updatedLine;
		String varNameToBeReplaced;
		//char[] characterArrForViolatedVariable;
		ViolationInfo info;
		for(Violation violation : violationLst){
			try{
				line = new StringBuffer(allLines.get(violation.getBeginline().intValue()-1));
				varNameToBeReplaced = line.substring(violation.getBegincolumn().intValue()-1,violation.getEndcolumn().intValue());
				//info.setBeforeFix(line.toString());
				updatedLine = new StringBuffer();
				/*If block to fix the violation where variable name starts with uppercase char
				if(violation.getValue().contains(variableShouldStartWithLowerCase)){
					lowerCaseVar = Character.toLowerCase(line.charAt(violation.getBegincolumn().intValue()-1))+
								line.substring(violation.getBegincolumn().intValue(),violation.getEndcolumn().intValue());
					updatedLine.append(line.substring(0,violation.getBegincolumn().intValue()-1)
							+lowerCaseVar
							+line.substring(violation.getEndcolumn().intValue()));
					//fixed the violation line till here
					//Function call to find all occurrence of this variable in allLines and replace
					replaceVariableInAllLines(violation.getBeginline().intValue(),allLines, varNameToBeReplaced,lowerCaseVar, info);
				}*/
				//This block handles the lower case final and static variables and converts them to uper case
				if(violation.getValue().contains(finalStaticInCaps))
				{
					info = new ViolationInfo(fileName, violation.getRule());
					updatedLine.append(line.substring(0,violation.getBegincolumn().intValue()-1)
							+varNameToBeReplaced.toString().toUpperCase()
							+line.substring(violation.getEndcolumn().intValue()));
					//Replaced the variable name in violation line
					//Function call to find all occurrence of this variable and replace with the uppercase
					replaceVariableInAllLines(violation.getBeginline().intValue(),allLines, varNameToBeReplaced,null, info);
					if(updatedLine.toString()!=null && !updatedLine.toString().isEmpty()) {
						info.setBeforeFix(line.toString());
						allLines.set(violation.getBeginline().intValue()-1, updatedLine.toString());
						info.setAfterFix(updatedLine.toString());
					}
					Reporting.violationInfos.add(info.toCSVRow());
				}
				/*allLines.set(violation.getBeginline().intValue()-1, ((updatedLine.toString()!=null && !updatedLine.toString().isEmpty())? updatedLine.toString(): line.toString()));
				info.setAfterFix(updatedLine.toString());*/
				//Reporting.violationInfos.add(info.toCSVRow());
			}
			catch(Exception ex){
				Logging.log("error occured on file :: "+fileName+" for rule :: "+violation.getRule(),ex);
			}
		}
	}
	
	/**
	 * This method accepts line number of violation, allLines, variable name which needs to be fixed,
	 * new name for the variable and violation info. It finds all the occurrence of the violation variable
	 * and replaces it with the correct variable name. It fixes the variables which starts with upper case character
	 * @param beginLine
	 * @param allLines
	 * @param varNameToBeReplaced
	 * @param lowerCaseVar
	 * @param info
	 */
	public void replaceVariableInAllLines(int beginLine, List<String> allLines, String varNameToBeReplaced, String lowerCaseVar, ViolationInfo info){
		regexForUpperCaseVarName = "[\\W\\D]"+varNameToBeReplaced+"[\\W\\D]";
		pForUpperCaseVar = Pattern.compile(regexForUpperCaseVarName);
		StringBuffer line, newLine;
		for(int i=beginLine; i<allLines.size();i++){
			mUpperCaseVar = pForUpperCaseVar.matcher(allLines.get(i));
			while(mUpperCaseVar.find()){
				line = new StringBuffer(allLines.get(i));
				info.setBeforeFix(line.toString());
				newLine = new StringBuffer(line.substring(0, mUpperCaseVar.start()+1));
				if(lowerCaseVar != null){
					newLine.append(lowerCaseVar + line.substring(mUpperCaseVar.end()-1));
				}
				else{
					newLine.append(varNameToBeReplaced.toUpperCase() + line.substring(mUpperCaseVar.end()-1));
				}
				allLines.set(i, newLine.toString());
				info.setAfterFix(newLine.toString());
				Reporting.violationInfos.add(info.toCSVRow());
			}
		}	
	}
}
	
