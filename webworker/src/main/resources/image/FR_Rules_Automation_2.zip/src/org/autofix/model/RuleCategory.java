package org.autofix.model;

public enum RuleCategory {
	APEX,
	JS,
	CSS
}
