package org.autofix.validation;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;

public class UseCollectionIsEmptyValidation implements IValidation {
	private static String regex = "[a-zA-Z0-9_\\.()]*(\\.size\\(\\)( *)[=!]=)( *)0";	
	Pattern pattern = Pattern.compile(regex);
	
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<File>();
		List<Violation> lstViolation = null;
		for (String filePath : fileNameLst) {
			try {
				int lineNo = 0;
				lstViolation = new ArrayList<Violation>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				for (String strLine : lstLines) {
					Matcher m = pattern.matcher(strLine.toLowerCase());
					while(m.find()){
						lstViolation.add(getViolation(strLine, lineNo, m.start(), m.end()));
					}
					lineNo++;
				}
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));				
				}
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}
		return lstFiles;
	}
	
	private static Violation getViolation(String strLine, int beginLine, int startIndx, int endIndx) {
		Violation violation = new Violation();
		violation.setBeginline(BigInteger.valueOf(beginLine));
		violation.setValue("UseCollectionIsEmpty");
		violation.setBegincolumn(BigInteger.valueOf(startIndx));
		violation.setEndcolumn(BigInteger.valueOf(endIndx));
		violation.setRule(ValidationRules.CustomValidationRules.USE_COLLECTION_IS_EMPTY);
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		return violation;	
	}
	
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;	
	}
}
