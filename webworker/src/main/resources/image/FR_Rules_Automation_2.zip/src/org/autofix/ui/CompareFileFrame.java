package org.autofix.ui;

import org.autofix.common.ApplicationParameter;
import org.autofix.ui.generators.DiffGeneratorUtils;
import org.autofix.ui.generators.DiffItem;
import org.autofix.ui.generators.forms.DiffForm;
import org.autofix.ui.generators.impl.MyersDiffGenerator;
import org.autofix.ui.panel.ReportPanel;
import org.autofix.utility.AppUtility;
import org.autofix.utility.AutofixUIUtility;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class CompareFileFrame extends JFrame implements ActionListener, WindowListener {

    private static final long serialVersionUID = 3912405576207939320L;

    private DiffForm diffForm;

    public CompareFileFrame() {
        super("File Comparision");
        this.setLayout(null);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.setSize(screenSize.width, screenSize.height);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.addWindowListener(this);
    }

    private JScrollPane leftScrollableTextArea, rightScrollableTextArea, fileNameVerticalBoxScrollPane;
    private JTextArea leftTextArea, rightTextArea;
    private boolean isInitDone = false;
    private final Font SALESFORCE_SANS_BOLD_16 = new Font("Salesforce Sans", Font.PLAIN, 16);
    private final Font SALESFORCE_SANS_BOLD_15 = new Font("Salesforce Sans", Font.BOLD, 15);
    private final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    private Box fileNamesVerticalBox;
    private ButtonGroup fileNameRadioButtonGroup;
    private ReportPanel reportPanel;
    private Map<JRadioButton, String> buttonToDestPathMap = new HashMap<>();

    public CompareFileFrame(ReportPanel reportPanel) {
        super("File Comparator");
        this.setLayout(null);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.setSize(screenSize.width, screenSize.height);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.addWindowListener(this);
        this.reportPanel = reportPanel;
    }

    public void init() {
        if (!isInitDone) {
            //Set Label
            JLabel fileNames, srcFolder, destFolder;
            fileNames = new JLabel("Files", SwingConstants.CENTER);
            srcFolder = new JLabel("Source Folder", SwingConstants.CENTER);
            destFolder = new JLabel("Destination Folder", SwingConstants.CENTER);

            fileNames.setFont(SALESFORCE_SANS_BOLD_15);
            srcFolder.setFont(SALESFORCE_SANS_BOLD_15);
            destFolder.setFont(SALESFORCE_SANS_BOLD_15);

            // Files Vertical Bar
            fileNamesVerticalBox = Box.createVerticalBox();
            fileNameVerticalBoxScrollPane = new JScrollPane(fileNamesVerticalBox);

            // set text area
            leftTextArea = new JTextArea();
            rightTextArea = new JTextArea();
            leftTextArea.setFont(SALESFORCE_SANS_BOLD_16);
            rightTextArea.setFont(SALESFORCE_SANS_BOLD_16);
            // set scrollpane
            leftScrollableTextArea = new JScrollPane(leftTextArea);
            rightScrollableTextArea = new JScrollPane(rightTextArea);
            // add action listener
            //leftScrollableTextArea.getVerticalScrollBar().addAdjustmentListener(new AdjustVerticalScrollBar());
            //rightScrollableTextArea.getVerticalScrollBar().addAdjustmentListener(new AdjustVerticalScrollBar());
            //leftScrollableTextArea.getHorizontalScrollBar().addAdjustmentListener(new AdjustHorizontalScrollBar());
            //rightScrollableTextArea.getHorizontalScrollBar().addAdjustmentListener(new AdjustHorizontalScrollBar());

            //set Bounds
            int l = 200;
            fileNames.setBounds(0, 0, l, 20);
            srcFolder.setBounds(l, 0, (screenSize.width / 2) - (l / 2), 20);
            destFolder.setBounds((screenSize.width / 2) + (l / 2), 0, (screenSize.width / 2) - (l / 2), 20);
            fileNameVerticalBoxScrollPane.setBounds(0, 20, l, screenSize.height - 150);
            leftScrollableTextArea.setBounds(l, 20, (screenSize.width / 2) - (l / 2), screenSize.height - 150);
            rightScrollableTextArea.setBounds((screenSize.width / 2) + (l / 2), 20, (screenSize.width / 2) - (l / 2), screenSize.height - 150);
            //add to frame
            this.add(fileNames);
            this.add(srcFolder);
            this.add(destFolder);
            this.add(fileNameVerticalBoxScrollPane);
            this.add(leftScrollableTextArea);
            this.add(rightScrollableTextArea);
            // To ensure this frame initialized only once
            this.isInitDone = true;
        }
        this.leftTextArea.setText("");
        this.rightTextArea.setText("");
        if(diffForm != null) {
            diffForm.setVisible(false);
        }

        fileNamesVerticalBox.removeAll();
        buttonToDestPathMap.clear();
        this.setVisible(true);
    }

    public void loadFileNameVerticalBox() {
        List<String> fileNamesWithPath = AutofixUIUtility.getAllInvalidFileNameWithPath();
        if (AppUtility.isNotNullOrBlank(fileNamesWithPath)) {
            fileNameRadioButtonGroup = new ButtonGroup();
            JRadioButton tempRadioButton;
            for (String filePath : fileNamesWithPath) {
                tempRadioButton = new JRadioButton(Paths.get(filePath).getFileName().toString());
                buttonToDestPathMap.put(tempRadioButton, filePath);
                tempRadioButton.addActionListener(this);
                fileNameRadioButtonGroup.add(tempRadioButton);
                fileNamesVerticalBox.add(tempRadioButton);
            }
        }
    }

    public static void main(String[] a) {
        new CompareFileFrame().init();
    }

    public void entry() {
        init();
        loadFileNameVerticalBox();
        SwingUtilities.updateComponentTreeUI(this);
        this.repaint();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(diffForm != null) {
            diffForm.setVisible(false);
        }
        if (e.getSource() instanceof JRadioButton) {
            JRadioButton selectedRadioButton = (JRadioButton) e.getSource();
            //String fileName = selectedRadioButton.getText();

            AtomicBoolean stopFlag = new AtomicBoolean();
            String srcPath = buttonToDestPathMap.get(selectedRadioButton).replace(ApplicationParameter.getLocalSourceFolderPath(), AutofixUIUtility.getUserSelectedSrcPath());
            String destPath = buttonToDestPathMap.get(selectedRadioButton).replace(ApplicationParameter.getLocalSourceFolderPath(), AutofixUIUtility.getUserSelectedDestPath());
            leftTextArea.setText(srcPath);
            rightTextArea.setText(destPath);
            DiffGeneratorUtils.LinesEncoding linesEncoding = DiffGeneratorUtils.encodeLines(
                    readFileIntoStringsSplit(srcPath),
                    readFileIntoStringsSplit(destPath),
                    stopFlag);

            List<DiffItem> byLineDiffItems = new MyersDiffGenerator(stopFlag).generate(linesEncoding.getLinesA(), linesEncoding.getLinesB());

            diffForm = new DiffForm(srcPath, destPath, byLineDiffItems, linesEncoding, leftTextArea,
					rightTextArea, leftScrollableTextArea, rightScrollableTextArea, reportPanel);
            //diffForm.setVisible(true);
        }
    }

    class AdjustVerticalScrollBar implements AdjustmentListener {
        @Override
        public void adjustmentValueChanged(AdjustmentEvent e) {
            leftScrollableTextArea.getVerticalScrollBar().setValue(e.getAdjustable().getValue());
            rightScrollableTextArea.getVerticalScrollBar().setValue(e.getAdjustable().getValue());
        }
    }

    class AdjustHorizontalScrollBar implements AdjustmentListener {
        @Override
        public void adjustmentValueChanged(AdjustmentEvent e) {
            leftScrollableTextArea.getHorizontalScrollBar().setValue(e.getAdjustable().getValue());
            rightScrollableTextArea.getHorizontalScrollBar().setValue(e.getAdjustable().getValue());
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void windowClosing(WindowEvent e) {
        // TODO Auto-generated method stub
        System.out.println("Test");
        this.setVisible(false);
        this.dispose();
        if(diffForm != null) {
            diffForm.setVisible(false);
        }
        AutofixUIUtility.getAutoFixUIRef().setDefaultMenu();
    }

    @Override
    public void windowClosed(WindowEvent e) {
    }

    @Override
    public void windowIconified(WindowEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void windowActivated(WindowEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        // TODO Auto-generated method stub

    }

    private static String[] readFileIntoStringsSplit(String path) {
        // TODO support other encodings
        String fileContents = readFile(path, StandardCharsets.UTF_8);

        // TODO handle mixed line endings
        String lineEndings = fileContents.contains("\r\n") ? "\r\n" : "\n";

        return fileContents.split(lineEndings);
    }

    /**
     * Taken from: https://stackoverflow.com/a/326440
     * TODO use commons
     */
    private static String readFile(String path, Charset encoding) {
        byte[] encoded;
        try {
            encoded = Files.readAllBytes(Paths.get(path));
        } catch (IOException e) {
            throw new RuntimeException("error reading file!");
        }
        return new String(encoded, encoding);
    }

}
