package org.autofix.common;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.autofix.constants.AppConstants;
import org.autofix.main.AutoFixUtilMain;
import org.autofix.utility.Logging;

public class ApplicationParameter {

	private static String pmdBinPath;
	private static String pmdReportPath;
	private static String pmdRulePath;
	private static String autoFixBasePath;
	private static String boolRunFix;
	private static String localSourceFolderName;
	private static String localSourceFolderPath;
	private static String appLogFolderName;
	private static String tempPmdRulePath;
	private static String customValidationReportPath;
	private static double defaultAPIVersion;
	private static String reportFolderName;
	private static final int BUFFER_SIZE = 4096;
	private static String pmdTempFolderPath;

	static{
		Properties prop = new Properties();
		InputStream input;
		autoFixBasePath = "AUTO_FIX_BASE_PATH";
		try{
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			input = classLoader.getResourceAsStream("config.properties");
			InputStream pmdFolder = classLoader.getResourceAsStream("PMD.zip");
			Path tempPMDDirectory = Files.createTempDirectory("PMD");
			pmdTempFolderPath = tempPMDDirectory.toString();
			// create a buffer to improve copy performance later.
			if (pmdFolder != null) {
				try (ZipInputStream zipInputStream = new ZipInputStream(pmdFolder)) {
					// Extract the zip contents and keep in temp directory
					extract(zipInputStream, tempPMDDirectory.toFile());
				}
			}
			// we must always close the zip file.
			prop.load(input);
			pmdBinPath = tempPMDDirectory.toString() + File.separator + prop.getProperty("pmdBinPath");
			pmdReportPath = tempPMDDirectory.toString() + File.separator + prop.getProperty("pmdReportPath");
			pmdRulePath = tempPMDDirectory.toString() + File.separator + prop.getProperty("pmdRulePath");
			localSourceFolderName = prop.getProperty("localSourceFolderName");
			appLogFolderName = prop.getProperty("appLogFolderName");
			tempPmdRulePath = tempPMDDirectory.toString() + File.separator + prop.getProperty("tempPmdRulePath");
			customValidationReportPath = tempPMDDirectory.toString() + File.separator + prop.getProperty("customValidationReportPath");
			reportFolderName = prop.getProperty("reportFolderName");
			/*if(AutoFixUtilMain.boolIsRunningFromAutoFixExtension){
				autoFixBasePath = System.getProperty(autoFixBasePath);
				pmdBinPath = autoFixBasePath + "/" + prop.getProperty("pmdBinPath");
				pmdReportPath = autoFixBasePath + "/" + prop.getProperty("pmdReportPath");
				pmdRulePath = autoFixBasePath + "/" + prop.getProperty("pmdRulePath");
				localSourceFolderName = prop.getProperty("localSourceFolderName");
				appLogFolderName = prop.getProperty("appLogFolderName");
				tempPmdRulePath = autoFixBasePath + "/" + prop.getProperty("tempPmdRulePath");
				customValidationReportPath = autoFixBasePath + "/" + prop.getProperty("customValidationReportPath");
				reportFolderName = prop.getProperty("reportFolderName");
			} else {
				pmdBinPath = prop.getProperty("pmdBinPath");
				pmdReportPath = prop.getProperty("pmdReportPath");
				pmdRulePath = prop.getProperty("pmdRulePath");
				localSourceFolderName = prop.getProperty("localSourceFolderName");
				appLogFolderName = prop.getProperty("appLogFolderName");
				tempPmdRulePath = prop.getProperty("tempPmdRulePath");
				customValidationReportPath = prop.getProperty("customValidationReportPath");
				reportFolderName = prop.getProperty("reportFolderName");
			}*/
			File localSrcFolder = new File(localSourceFolderName);
			if(! localSrcFolder.exists()){
				localSrcFolder.mkdir();
			}
			localSourceFolderPath = localSrcFolder.getAbsolutePath();
			defaultAPIVersion = Double.valueOf(prop.getProperty("defaultAPIVersion"));
		}catch(Exception error){
			error.printStackTrace();
		}
	}

	public static String getPmdBinPath() {
		return pmdBinPath;
	}

	public static String getPmdReportPath() {
		return pmdReportPath;
	}

	public static String getPmdRulePath() {
		return pmdRulePath;
	}
	
	public static String getLocalSourceFolderPath(){
		return localSourceFolderPath;
	}

	public static String getLocalSourceFolderName() {
		return localSourceFolderName;
	}

	public static String getAppLogFolderName() {
		return appLogFolderName;
	}

	public static String getTempPmdRulePath() {
		return tempPmdRulePath;
	}

	public static String getCustomValidationReportPath() {
		return customValidationReportPath;
	}

	public static double getDefaultAPIVersion() {
		return AutoFixUtilMain.boolIsAutoFixAPIAvailable ? Double.parseDouble(System.getProperty(AppConstants.AUTO_FIX_EXTENSION_API_VERSION)) : defaultAPIVersion;
	}
	
	public static String getReportFolderName() {
		return reportFolderName;
	}

	public static String getPmdTempFolderPath() {
		return pmdTempFolderPath;
	}

	public static void extract(ZipInputStream zip, File target) throws IOException {
		try {
			ZipEntry entry;

			while ((entry = zip.getNextEntry()) != null) {
				File file = new File(target, entry.getName());

				if (!file.toPath().normalize().startsWith(target.toPath())) {
					throw new IOException("Bad zip entry");
				}

				if (entry.isDirectory()) {
					file.mkdirs();
					continue;
				}

				byte[] buffer = new byte[BUFFER_SIZE];
				file.getParentFile().mkdirs();
				BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(file));
				int count;

				while ((count = zip.read(buffer)) != -1) {
					out.write(buffer, 0, count);
				}

				out.close();
			}
		} finally {
			zip.close();
		}
	}
	
	public static void deleteTempFolder(){
		if(pmdTempFolderPath != null){
			try {
				FileUtils.deleteDirectory(new java.io.File(pmdTempFolderPath));
			} catch (IOException error) {
				Logging.log(error);
			}
		}
	}

}
