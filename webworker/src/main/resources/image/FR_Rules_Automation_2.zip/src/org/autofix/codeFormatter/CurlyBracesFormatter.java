package org.autofix.codeFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.autofix.utility.AppUtility;
import org.autofix.utility.Logging;

public class CurlyBracesFormatter implements ICodeFormatter {

	@Override
	public List<String> formatCode(List<String> inputLst, List<Integer> intLst) {
		String stringNeedToBeFormatted;
		for(Integer i : intLst){
			try{
				stringNeedToBeFormatted = inputLst.get(i-1); // Because inputLst is a 0 based String
				System.out.println(stringNeedToBeFormatted);
				List<Integer> openBracesIndexes = AppUtility.getAllIndex(stringNeedToBeFormatted, '{');
				System.out.println(openBracesIndexes);
				List<Integer> closeBracesIndexes = AppUtility.getAllIndex(stringNeedToBeFormatted, '}');
				System.out.println(closeBracesIndexes);
				List<Integer> putNextLineOnIndexes = new ArrayList<>();
				putNextLineOnIndexes.addAll(openBracesIndexes);
				closeBracesIndexes = closeBracesIndexes.stream().map(t->t-1).collect(Collectors.toList());
				putNextLineOnIndexes.addAll(closeBracesIndexes);
				int counter = 0;
				StringBuilder builder = new StringBuilder();
				for(char c : stringNeedToBeFormatted.toCharArray() ){	
					builder.append(c);
					if(putNextLineOnIndexes.contains(counter)){
						builder.append(System.lineSeparator());
					}
					counter ++;
				}
				inputLst.set(i-1, builder.toString());
				System.out.println(builder.toString());
			}catch(Exception e){
				Logging.log(e);
			}

		}
		return inputLst;
	}

	@Override
	public List<String> formatCode(List<String> inputLst, List<Integer> beginLineLst, Map<Object, Object> startEndLineMap) {
		/*Method needs to be overridden as it is added to the ICodeFormatter interface. Used only by the SOQL Security Enforced rule
		and proper implementation of the method is in BracesFormatter file*/
		return null;
	}

}
