package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.AutofixUIUtility;
import org.autofix.utility.Reporting;

/**
* Program to update apiVersion to expected(user input)
* @author  Laltu Banerjee
* @version 1.0
* @since   2020-05-23
*/

public class ApiVersionUpdateRule implements IFRRules{

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) throws CustomException {
		String currentLine;
		ViolationInfo info;
		for(Violation v : violationLst){
			info = new ViolationInfo(fileName, v.getRule());
			currentLine = allLines.get(v.getBeginline().intValue()-1);
			info.setBeforeFix(currentLine);
			currentLine = currentLine.substring(0,v.getBegincolumn().intValue())
					+"<apiVersion>"+AutofixUIUtility.getApiVersionUpdateValue()+"</apiVersion>"
					+currentLine.substring(v.getEndcolumn().intValue());
			allLines.set(v.getBeginline().intValue()-1, currentLine);
			info.setAfterFix(currentLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}
