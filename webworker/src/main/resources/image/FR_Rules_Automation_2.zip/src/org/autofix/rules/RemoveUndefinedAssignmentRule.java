package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
* Autofix rule file to update assignment of "undefined" value to Javascript variables with a null value.
* Example : Before Autofix : var variable = undefined;
*  		  : After Autofix : var variable = null;
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-07-24
*/

public class RemoveUndefinedAssignmentRule implements IFRRules {

	private static final String UNDEFINED_STRING = "undefined";
	private static final String NULL_STRING = "null"; 
	
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		String currentLine;
		ViolationInfo info;
		for (Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			currentLine = allLines.get(violation.getEndline().intValue()-1);
			currentLine = currentLine.replaceFirst(UNDEFINED_STRING, NULL_STRING);
			allLines.set(violation.getEndline().intValue()-1, currentLine);
			info.setAfterFix(currentLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}