/**************************************************************************************
Class Name		:  UnusedPrivateMethodValidation
Version   		: 1.0 
Created Date	: 10 Aug 2020
Function   		: Class to spot the Unused Private methodss
Example : Before Autofix : private void foo(){
          After Autofix :  /*private void foo(){
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Kundan Shaw  			   10/08/2020              Initial Version
*************************************************************************************/
package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.PMDValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

public class UnusedPrivateMethodValidation implements IValidation {

	private final static String LITERAL_ISTEST = "@ISTEST";
	private final static String LITERAL_CLASS = "CLASS";
	private final static String OPEN_CURLY_BRACE = "{";
	private final static String CLOSE_CURLY_BRACE = "}";
	private final static String AT_THE_RATE_OF = "@";
	static boolean isTest = false;
	static int countlines=0;

	private final Pattern DETECT_PRIVATE_METHOD_IMPLIMENTATION = Pattern
			.compile("private\\s+(static)*\\s*[\\w<>,]+\\s+(\\w+)\\s*\\(");
	private final Pattern DETECT_PRIVATE_METHOD_CALL = Pattern.compile("([a-zA-Z]\\w*)\\s*\\(");

	/**
	 * Method name : runValidation Description : runs the Unused Private method
	 * validations and returns files with violations if any Return Type : List<File>
	 * Parameter : List<String> fileNameLst
	 **/
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<File>();
		List<String> lstLines = new ArrayList<String>();
		List<String> pieceOfCode = new ArrayList<String>();
		Stack<String> braceStack = new Stack<String>();
		
		Map<String, Integer> calledMethodMap = new TreeMap<String, Integer>();

		int beginLine = 0;
		int endLine = 0;
		int lineNo;

		for (String filePath : fileNameLst) {
			try {
				Map<String, Violation> violationMap = new TreeMap<String, Violation>();
				lineNo = 0;
				boolean search = false;
				boolean isStackStarted = false;
				String methodName = "";
				lstLines = Files.readAllLines(Paths.get(filePath));
				if(!isTestClass(lstLines)) {
					for (String codeline : lstLines) {
						lineNo++;
						String methodCallName = "";
						Matcher matchDeclaration = DETECT_PRIVATE_METHOD_IMPLIMENTATION.matcher(codeline.trim());
						Matcher matchCall = DETECT_PRIVATE_METHOD_CALL.matcher(codeline.trim());
	
						// Fetch All the pattern matches method call.
						while (matchCall.find()) {
							methodCallName = matchCall.group(1);
							if (calledMethodMap.containsKey(methodCallName)) {
								calledMethodMap.put(methodCallName, calledMethodMap.get(methodCallName) + 1);
							} else {
								calledMethodMap.put(methodCallName, 1);
							}
						}
	
						// Fetch all the pattern matches method Implimentation.
						if (matchDeclaration.find()) {
							search = true;
							beginLine = lineNo;
							pieceOfCode.add(codeline);
							methodName = matchDeclaration.group(2);
	
						}
						// Use Stack to get the line number of end of method.
						if (search) {
							if (codeline.contains(OPEN_CURLY_BRACE)) {
								braceStack.push(OPEN_CURLY_BRACE);
								isStackStarted = true;
							}
							if (codeline.contains(CLOSE_CURLY_BRACE) && !braceStack.isEmpty()) {
								braceStack.pop();
							}
							if (braceStack.isEmpty() && isStackStarted) {
								search = false;
								isStackStarted = false;
								endLine = lineNo;
								if(lstLines.get(beginLine-2).contains(AT_THE_RATE_OF)){
									beginLine=beginLine-1;
								}
								violationMap.put(methodName, prepareViolation(beginLine, endLine));
							}
	
						}
	
					}
	
					// Remove private method which is Used.
					if (!calledMethodMap.isEmpty()) {
						calledMethodMap.forEach((k, v) -> {
							if (violationMap.containsKey(k) && calledMethodMap.get(k) > 1) {
								violationMap.remove(k);
							}
						});
					}
	
					if (!violationMap.isEmpty()) {
						lstFiles.add(getFile(filePath, new ArrayList<Violation>(violationMap.values())));
					}
				}		
			} catch (Exception e) {
				Logging.log(e);
			}
		}
		return lstFiles;
	}

	/**
	 * Method name : prepareViolation Description : prepares violation data within
	 * the given piece of code Return Type : Violation Parameter : int beginLine,
	 * int endLine
	 **/
	private static Violation prepareViolation(int beginLine, int endLine) {
		Violation violation = new Violation();
		violation.setValue(AppConstants.UNUSED_PRIVATE_METHOD);
		violation.setBeginline(BigInteger.valueOf(beginLine));
		violation.setBegincolumn(BigInteger.valueOf(0));
		violation.setEndline(BigInteger.valueOf(endLine));
		violation.setEndcolumn(BigInteger.valueOf(0));
		violation.setRule(PMDValidationRules.UNUSED_PRIVATE_METHOD);
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		return violation;

	}

	/**
	 * Method name : getFile Description : returns file after adding listed
	 * violations Return Type : File Parameter : String filePath, List<Violation>
	 * lstViolation
	 **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;
	}


	/**
     * Method name  : isTestClass
     * Description  : returns if the file to be processed is a test class
     * Return Type  : Boolean
     * Parameter    : List<String> codelines
     **/
	private static Boolean isTestClass(List<String> codelines) {
		for(String codeline : codelines) {
			countlines++;
			if(codeline.toUpperCase().contains(LITERAL_ISTEST)) {
				isTest=true;
				countlines=0;
			}
			if(isTest && codeline.toUpperCase().contains(LITERAL_CLASS) && (countlines==0 || countlines==1)){
				return true;
			} 
		}
		return false;
	}
}