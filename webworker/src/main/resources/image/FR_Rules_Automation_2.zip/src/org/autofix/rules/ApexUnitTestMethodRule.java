package org.autofix.rules;

import java.util.List;

import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

/**
 * This class updates the code with Apex Unit Test methods should have @isTest annotation fixes
 *  Example  : Before fix : public static testMethod void method1() {
 *                            //somecode
 *                            }
 *             After fix:  @isTest
 * 						   public static void method1() {
 *                           //somecode
 * 							}
 * @author ruchkumari
 *
 */
public class ApexUnitTestMethodRule implements IFRRules{
	public static final String TEST_METHOD_STR = "TestMethod";
	public static final String IS_TEST_ANNOTATION = "@isTest";
	public static final String ALL_WHITESPACES = "\\s+";
	public static final String PUBLIC_KEYWORD = "public";
	public static final String SPACE = " ";


	/* (non-Javadoc)
	 * @see org.fpr.FRRules.IFRRules#doOperation(java.lang.String, java.util.List, java.util.List)
	 * Method name  : doOperation
	 * Description  : updates the code with Apex Unit Test methods should have @isTest annotation fixes
	 * Return Type  : void
	 * Parameter    : List<String> allLines, List<Violation> violationLst
	 */
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String content;
		ViolationInfo info;
		List<String> linesToBeReplaced = allLines;
		try {
			for(Violation violation : violationLst) {
				info = new ViolationInfo(fileName, violation.getRule());
				content = linesToBeReplaced.get(violation.getBeginline().intValue());

				if(content.toUpperCase().contains(TEST_METHOD_STR.toUpperCase())) 
				{
					info.setBeforeFix(content);
					content = replaceStringWithPosition(TEST_METHOD_STR, IS_TEST_ANNOTATION, content);
					info.setAfterFix(content);
					Reporting.violationInfos.add(info.toCSVRow());
				} 
				linesToBeReplaced.set(violation.getBeginline().intValue(), content);
			}
		}catch(Exception e) {
			Logging.log(e.getMessage());
		}
	}

	/**
	 * replace TestMethod with @isTest annotation
	 * @param originalStr
	 * @param replaceStr
	 * @param content
	 * @return
	 */
	public static String replaceStringWithPosition (String originalStr, String replaceStr, String content) {
		String finalStr = AppConstants.EMPTY;
		if(content != null && !content.isEmpty()) {
			if(!content.contains(IS_TEST_ANNOTATION)) {
				content = content.replaceFirst("(?i)"+originalStr,replaceStr);
			}
			String[] contentArray = content.split(ALL_WHITESPACES);
			for(String contentRec: contentArray) {
				if(!contentRec.equalsIgnoreCase(replaceStr)) {
					if(!contentRec.equalsIgnoreCase(PUBLIC_KEYWORD)) {
						finalStr += contentRec + SPACE;
					}
				}
				else {
					finalStr = "    " + contentRec + finalStr;
				}
			}
		}
		return finalStr;
	}
}
