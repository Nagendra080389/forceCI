package org.autofix.checker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.model.Checker;

public class ApexCommentChecker {
	private static List<String> allLines;
	private static Map<Integer, Checker> checkerMap = new HashMap<>();
	private static ApexCommentChecker apexCommentChecker = new ApexCommentChecker();
	
	private static final Pattern singleLineCommentRegex = Pattern.compile("(//)|(/\\*.*\\*/)");
	private static final Pattern multiLineCommentStartRegex = Pattern.compile("(/\\*)");
	private static final Pattern multiLineCommentEndRegex = Pattern.compile("(\\*/)");
	
	private ApexCommentChecker(){}
	
	public static ApexCommentChecker getInstance(String fileNameWithPath) throws IOException {
		Path path = Paths.get(fileNameWithPath);
		allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
		doCheck();
		return apexCommentChecker;
	}

	public static ApexCommentChecker getInstance(List<String> allLines) {
		ApexCommentChecker.allLines = allLines;
		doCheck();
		return apexCommentChecker;
	}
	
	public Checker getChecker(int lineNo) throws CloneNotSupportedException{
		return checkerMap.get(lineNo).clone();
	}
	
	public boolean isCommented(int lineNo, int index){
		Checker checker = checkerMap.get(lineNo);
		if(checker != null){
			if(checker.isMultiLineComment()){
				if(lineNo > checker.getBeginLine() && lineNo < checker.getEndLine()){
					return true;
				}else if( lineNo == checker.getBeginLine() && index >= checker.getBeginIndex()){
					return true;
				}else if( index < checker.getEndIndex()){
					return true;
				}
			}else{
				if(index >= checker.getBeginIndex()){
					return true;
				}
			}
		}
		return false;
	}
	
	private static void doCheck(){
		Checker tempChecker = null;
		String line;
		boolean isMultiLineComment = false;
		Matcher tempMatcher;
		for(int i=0; i<allLines.size(); i++){
			line = allLines.get(i);
			if(isMultiLineComment){
				checkerMap.put(i+1, tempChecker);
				tempMatcher = multiLineCommentEndRegex.matcher(line);
				if(tempMatcher.find()){
					isMultiLineComment = false;
					tempChecker.setEndLine(i+1);
					tempChecker.setEndIndex(tempMatcher.end());
				}
			}else{
				tempMatcher = singleLineCommentRegex.matcher(line);
				if(tempMatcher.find()){
					tempChecker = new Checker();
					tempChecker.setBeginLine(i+1);
					tempChecker.setEndLine(i+1);
					tempChecker.setBeginIndex(tempMatcher.start());
					tempChecker.setEndIndex(line.length()-1);
					checkerMap.put(i+1, tempChecker);
				}
				else{
					tempMatcher = multiLineCommentStartRegex.matcher(line);
					if(tempMatcher.find()){
						isMultiLineComment = true;
						tempChecker = new Checker();
						tempChecker.setBeginLine(i+1);
						tempChecker.setBeginIndex(tempMatcher.start());
						tempChecker.setMultiLineComment(true);
					}
				}
			}
		}
	}
}

