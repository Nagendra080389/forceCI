package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
* Violation detection file to detect existence of unused import statements in Javascript files.
* If unused import statements are found, then they are removed
* Example : Before Autofix : import { Component } from test;
*  		  : After Autofix : Line is removed if not used in the Javascript file
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-08-07
*/

public class RemoveUnnecessaryImportsValidation implements IValidation {
	
	private static final Pattern IMPORT_START_PATTERN = Pattern.compile("^\\s*import\\s*");
	private static final Pattern ONLY_WHITESPACE_PATTERN = Pattern.compile("^\\s*$");
	private static final Pattern CHARACTER_PATTERN = Pattern.compile("\\s*[a-zA-Z0-9]\\s*");
	private static final Pattern SINGLE_LINE_COMMENT_PATTERN = Pattern.compile("^//\\s*[a-zA-Z0-9 ]*");
	private static final Pattern AS_PATTERN = Pattern.compile("\\s+as\\s+");
	private static final Pattern EXTRA_COMMA_IN_BRACE_PATTERN = Pattern.compile("\\{\\s*[a-zA-Z0-9]+\\s*,\\s*\\}");
	private static final Pattern EXTRA_AS_IN_BRACE_PATTERN = Pattern.compile("\\{\\s*[a-zA-Z0-9]*\\s*as\\s*\\}");
	private static final Pattern EXTRA_AS_BEFORE_START_BRACE_PATTERN = Pattern.compile("[^import][^a-zA-Z0-9][^ }][^}]\\s*,+\\s*\\{");
	private static final Pattern WORD_AS_BLANK_PATTERN = Pattern.compile(",\\s*[a-zA-Z0-9]*\\s*as\\s*,");
	private static final Pattern SPACE_BETWEEN_TWO_COMMA_PATTERN = Pattern.compile(",[^a-zA-Z0-9]\\s*,+");
	private static final Pattern EXTRA_COMMA_AFTER_CLOSE_BRACE_PATTERN = Pattern.compile("\\}\\s*,[^a-zA-Z0-9]\\s*,+");	
	private static final Pattern EXTRA_COMMA_BEFORE_CLOSE_BRACE_PATTERN = Pattern.compile(",\\s*\\}");
	private static final Pattern EMPTY_BRACE_PATTERN = Pattern.compile("\\{\\s*\\}");
	private static final Pattern EXTRA_COMMA_BEFORE_FROM_PATTERN = Pattern.compile(",[^a-zA-Z0-9]\\s*,*\\s*from");
	private static final Pattern COMMA_BEFORE_FROM_PATTERN = Pattern.compile("\\}\\s*,\\s*from");
	private static final Pattern EXTRA_AS_BEFORE_FROM_PATTERN = Pattern.compile("\\*\\s*as*\\s*from");
	private static final Pattern EXTRA_WORD_BEFORE_FROM_PATTERN = Pattern.compile("[a-zA-Z0-9]+\\s*as\\s*from");
	private static final Pattern EXTRA_COMMA_AFTER_START_BRACE_PATTERN = Pattern.compile("\\{\\s*,");
	private static final Pattern EXTRA_COMMA_AFTER_IMPORT_PATTERN = Pattern.compile("import\\s*,\\s*");
	private static final Pattern EXTRA_WORD_AFTER_START_BRACE_PATTERN = Pattern.compile("\\{\\s*[a-zA-Z0-9]*\\s*as\\s*,");
	private static final Pattern IMPORT_FROM_PATTERN = Pattern.compile("import\\s*from");
	private static final Pattern IMPORT_END_PATTERN = Pattern.compile(";$");
	
	private static final String OPEN_CURLY_BRACE_REGEX = "\\{";
	private static final String CLOSE_CURLY_BRACE_REGEX = "\\}";
	private static final String FROM_WITH_SPACE = " from ";
	private static final String OPEN_CURLY_SPACE = " { ";
	private static final String COMMA_SPACE = " , ";
	private static final String CLOSE_CURLY_COMMA_SPACE = " } , ";
	private static final String CLOSE_CURLY_SPACE = " } ";
	private static final String CLOSE_CURLY_BRACE_FROM = "} from";
	private static final String IMPORT_SPACE = "import ";
	private static final String IMPORT_ALIAS_USAGE_PATTERN = "^[\\w]*[^$\"\']*<aliasName>";

	
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<>();
		List<Violation> lstViolation = null;
		List<String> lstLines = null;
		String currentLine;
				
		Matcher importMatcher;
		Matcher whiteSpaceMatcher;
		Matcher characterMatcher;
		Matcher asPatternMatcher;
		Matcher singleLineCommentMatcher;
		Matcher importEndMatcher;
		
		List<String> importNames = null;
		Map<String, Integer> importsLineNumMap = null;
		Map<String, String> importsMap = null;
		Deque<String> commentedImportStmtDeque = null;
		Deque<String> commentedLineDeque = null;
		boolean importEndFound = false;
		
		String[] importName = null;
		String name = "";
		
		for (String filePath : fileNameLst) {
			try {
				lstViolation = new ArrayList<>();
				lstLines = Files.readAllLines(Paths.get(filePath));
				
				importNames = new ArrayList<>();
				importsLineNumMap = new HashMap<>();
				importsMap = new HashMap<>();
				commentedImportStmtDeque = new ArrayDeque<>();
				commentedLineDeque = new ArrayDeque<>();
				
				for (int i = 0; i < lstLines.size(); i++) {
					
					currentLine = lstLines.get(i);
					
					singleLineCommentMatcher = SINGLE_LINE_COMMENT_PATTERN.matcher(currentLine);
					importMatcher = IMPORT_START_PATTERN.matcher(currentLine);
					whiteSpaceMatcher = ONLY_WHITESPACE_PATTERN.matcher(currentLine);
					characterMatcher = CHARACTER_PATTERN.matcher(currentLine);
					importEndMatcher = IMPORT_END_PATTERN.matcher(currentLine);
					
					//If multiline comment is encountered, push to deque
					pushCommentedImportStmt(currentLine, commentedImportStmtDeque);
					
					//If import statement is ending on same or next line and the line is not commented
					if((importMatcher.find() || !importEndFound) && !singleLineCommentMatcher.find()) {
						
						if (currentLine.contains(AppConstants.COMMENT_END_PATTERN) ||
								(!commentedImportStmtDeque.isEmpty() && !AppConstants.COMMENT_END_PATTERN.equals(commentedImportStmtDeque.peek()))) {
							continue;
						}
						
						//If import statement is written across multiple lines
						importEndFound = isImportEndFound(importEndMatcher);												

						if(currentLine.contains(AppConstants.OPEN_BRACES_STR) && !currentLine.contains(AppConstants.COMMA_STRING)
								&& currentLine.contains(AppConstants.CLOSE_BRACES_STR)) {
							
							importName = currentLine.split(OPEN_CURLY_BRACE_REGEX)[1].split(CLOSE_CURLY_BRACE_REGEX);
							
							name = processSingleImportLine(importName);
							addImportToList(name, importNames);
							addLinesToMap(importsLineNumMap, importsMap, currentLine, i+1);
						}
						else if( (currentLine.contains(AppConstants.OPEN_BRACES_STR) || !currentLine.contains(AppConstants.OPEN_BRACES_STR))
									&& currentLine.contains(AppConstants.COMMA_STRING)
									&& ((currentLine.contains(AppConstants.SINGLE_LINE_COMMENT)
											&& currentLine.indexOf(AppConstants.COMMA_STRING) < currentLine.indexOf(AppConstants.SINGLE_LINE_COMMENT))
											|| (!currentLine.contains(AppConstants.SINGLE_LINE_COMMENT)))) {
								
							
							
							importName = currentLine.split(AppConstants.COMMA_STRING);
							
							processMultiImportLine(importName, importNames);
							addLinesToMap(importsLineNumMap, importsMap, currentLine, i+1);
						}
						else {
							
							asPatternMatcher = AS_PATTERN.matcher(currentLine);
							
							if(asPatternMatcher.find() && currentLine.indexOf(AppConstants.FROM_STRING) != -1) {								
								name = processAsFromLine(asPatternMatcher, currentLine);
							}
							else {								
								name = processImportFromLine(name, currentLine);								
							}
							
							addImportToList(name, importNames);
							addLinesToMap(importsLineNumMap, importsMap, currentLine, i+1);							
						}						
					}
					/*If the current line does not contain any import statement, check if the imported
					components are used. Only check if line is not empty and contains some characters*/
					else if(!importMatcher.find() && !whiteSpaceMatcher.find() && characterMatcher.find() && !importNames.isEmpty()
							&& !currentLine.contains(AppConstants.SINGLE_LINE_COMMENT)) {
												
						checkImportComponentUsage(importNames, currentLine, commentedLineDeque);												
					}																						
				}
				
				//Remove all the additional patterns leftover after removing the unused imported component 
				removeLeftoverPatterns(importNames, importsMap);
				
				//Create Violation objects for fixing later
				if(!importsMap.isEmpty()) {						
					createViolation(importsMap, importsLineNumMap, lstViolation);
				}
			
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));
				}
			}catch (Exception e) {
				Logging.log(e,"Error occurred for file :: "+filePath);
			}
		}
		return lstFiles;
	}

	
	/**
     * Method name  : getFile
     * Description  : Sets the list of violations in a File object for the concerned file
     * Return Type  : File
     * Parameter    : String filePath, List<Violation> lstViolation
     **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;
	}
	
	
	/**
     * Method name  : pushCommentedImportStmt
     * Description  : Pushes comment pattern to a deque when commented import statements are encountered
     * Return Type  : void
     * Parameter    : String codeline, Deque<String> commentsDeque
     **/
	private static void pushCommentedImportStmt(String codeline, Deque<String> commentedImportStmtDeque) {
		
		//Push to deque if multiline comment start is found
		if(codeline.contains(AppConstants.COMMENT_START_PATTERN)) {
			commentedImportStmtDeque.push(AppConstants.COMMENT_START_PATTERN);
		}
		
		if(codeline.contains(AppConstants.COMMENT_END_PATTERN)) {
			commentedImportStmtDeque.push(AppConstants.COMMENT_END_PATTERN);
		}
	}
	
	
	/**
     * Method name  : isImportEndFound
     * Description  : Checks if import statement end has been encountered for a multi-line import statement
     * Return Type  : boolean
     * Parameter    : Matcher importEndMatcher
     **/
	private static boolean isImportEndFound(Matcher importEndMatcher) {
		return importEndMatcher.find();
	}
	
	/**
     * Method name  : pushCommentedLine
     * Description  : Pushes comment pattern to a deque when commented code lines are encountered
     * Return Type  : void
     * Parameter    : String codeline, Deque<String> commentsDeque
     **/
	private static void pushCommentedLine(String codeline, Deque<String> commentedLineDeque) {
		
		//Push to deque if multiline comment start is found
		if(codeline.contains(AppConstants.COMMENT_START_PATTERN)) {
			commentedLineDeque.push(AppConstants.COMMENT_START_PATTERN);
		}
		
		if(codeline.contains(AppConstants.COMMENT_END_PATTERN)) {
			commentedLineDeque.push(AppConstants.COMMENT_END_PATTERN);
		}
	}
	
	
	/**
     * Method name  : processSingleImportLine
     * Description  : Method that gets the imported component name from lines that have single imported component
     * Example		: import { LightningElement } from 'lwc';
     * Return Type  : String
     * Parameter    : String[] importName
     **/
	private static String processSingleImportLine(String[] importName) {
		
		Matcher asPatternMatcher = AS_PATTERN.matcher(importName[0]);
		
		if(asPatternMatcher.find()) {
			return importName[0].substring(importName[0].indexOf(asPatternMatcher.end()), importName[0].length() -1).trim();
		}
		else {
			return importName[0].trim();
		}					
	}
	
	
	/**
     * Method name  : processMultiImportLine
     * Description  : Method that gets the imported component names from lines that have multiple imported components
     * Example		: import { LightningElement, wire, track } from 'lwc';
     * Return Type  : void
     * Parameter    : String[] importName, List<String> importNames
     **/
	private static void processMultiImportLine(String[] importName, List<String> importNames) {
		
		Matcher asPatternMatcher;
		String aliasName = "";
		
		for(String line : importName) {
			
			asPatternMatcher = AS_PATTERN.matcher(line);
			
			if(line.contains(AppConstants.IMPORT_STRING)) {
				
				aliasName = processImportLine(asPatternMatcher, line);									
			}
			else if(asPatternMatcher.find() && line.indexOf(AppConstants.FROM_STRING) != -1) {
				
				aliasName = processAsFromLine(asPatternMatcher, line);
			}
			else if (line.indexOf(AppConstants.OPEN_BRACES_STR) != -1 && line.indexOf(AppConstants.CLOSE_BRACES_STR) != -1) {
				
				aliasName = processOpenCloseCurlyBraceLine(asPatternMatcher, line);
			}
			else if (line.indexOf(AppConstants.OPEN_BRACES_STR) != -1) {
				
				aliasName = processOpenCurlyBraceLine(asPatternMatcher, line);
			}
			else if (line.indexOf(AppConstants.CLOSE_BRACES_STR) != -1) {
				
				aliasName = processCloseCurlyBraceLine(asPatternMatcher, line);
			}
			else if (line.indexOf(AppConstants.FROM_STRING) != -1) {
				
				aliasName = processOnlyFromLine(line);
			}
			else {
				aliasName = line.trim();									
			}
			
			if (!AppConstants.EMPTY.equals(aliasName)) {				
				addImportToList(aliasName, importNames);				
			}
		}
	}
	
	
	/**
     * Method name  : processImportLine
     * Description  : Method that gets the import names from lines that have import keyword
     * Return Type  : void
     * Parameter    : Matcher asPatternMatcher, String name, String line, List<String> importNames, 
				 	  Map<String, Integer> importsLineNumMap, String currentLine, int lineNum
     **/
	private static String processImportLine(Matcher asPatternMatcher, String line) {
		
		if(asPatternMatcher.find()) {
			return line.substring(asPatternMatcher.end(), line.length()).trim();
		}
		else if(line.contains(AppConstants.OPEN_BRACES_STR) && line.contains(AppConstants.CLOSE_BRACES_STR)) {
			return line.substring(line.indexOf(AppConstants.OPEN_BRACES_STR)+1, line.length()-1).trim();
		}
		else if(line.contains(AppConstants.OPEN_BRACES_STR)) {
			return line.substring(line.indexOf(AppConstants.OPEN_BRACES_STR)+1, line.length()).trim();
		}		
		else {
			return line.substring(line.indexOf(AppConstants.IMPORT_STRING)+6, line.length()).trim();
		}
	}
	
	
	/**
     * Method name  : processAsFromLine
     * Description  : Method that gets the import names from lines that have as and from keywords
     * Return Type  : void
     * Parameter    : Matcher asPatternMatcher, String line)
     **/
	private static String processAsFromLine(Matcher asPatternMatcher, String line) {		
		return line.substring(asPatternMatcher.end(), line.indexOf(AppConstants.FROM_STRING)-1).trim();		
	}
	
	
	/**
     * Method name  : processOpenCloseCurlyBraceLine
     * Description  : Method that gets the import names from lines that have both open & closed curly braces
     * Return Type  : void
     * Parameter    : Matcher asPatternMatcher, String line
     **/
	private static String processOpenCloseCurlyBraceLine(Matcher asPatternMatcher, String line) {
		
		asPatternMatcher.reset();
		if(asPatternMatcher.find()) {
			return line.substring(asPatternMatcher.end(), line.indexOf(AppConstants.CLOSE_BRACES_STR)-1).trim();
		}
		else {
			return line.substring(line.indexOf(AppConstants.OPEN_BRACES_STR)+1, line.indexOf(AppConstants.CLOSE_BRACES_STR)-1).trim();
		}
	}
	
	
	/**
     * Method name  : processOpenCurlyBraceLine
     * Description  : Method that gets the import names from lines that have open curly brace
     * Return Type  : void
     * Parameter    : Matcher asPatternMatcher, String line
     **/
	private static String processOpenCurlyBraceLine(Matcher asPatternMatcher, String line) {
		
		asPatternMatcher.reset();
		if(asPatternMatcher.find()) {
			return line.substring(asPatternMatcher.end(), line.length()).trim();
		}
		else {
			return line.substring(line.indexOf(AppConstants.OPEN_BRACES_STR)+1, line.length()).trim();
		}
	}
	
	
	/**
     * Method name  : processCloseCurlyBraceLine
     * Description  : Method that gets the import names from lines that have closed curly brace
     * Return Type  : void
     * Parameter    : Matcher asPatternMatcher, String line
     **/
	private static String processCloseCurlyBraceLine(Matcher asPatternMatcher, String line) {
		
		asPatternMatcher.reset();
		if(asPatternMatcher.find()) {
			return line.substring(asPatternMatcher.end(), line.indexOf(AppConstants.CLOSE_BRACES_STR)-1).trim();
		}
		else {
			return line.substring(0, line.indexOf(AppConstants.CLOSE_BRACES_STR)-1).trim();
		}
	}
	
	
	/**
     * Method name  : processOnlyFromLine
     * Description  : Method that gets the import names from lines that have only "from" keyword
     * Return Type  : void
     * Parameter    : String line
     **/
	private static String processOnlyFromLine(String line) {		
		return line.substring(0, line.indexOf(AppConstants.FROM_STRING)-1).trim();
	}
	
	
	/**
     * Method name  : processImportFromLine
     * Description  : Method that gets the import names from lines that have import and from keywords with one import alias
     * Return Type  : void
     * Parameter    : String name, String currentLine
     **/
	private static String processImportFromLine(String name, String currentLine) {
		
		if(currentLine.contains(AppConstants.IMPORT_STRING) && currentLine.contains(AppConstants.FROM_STRING)) {
			name = currentLine.substring(currentLine.indexOf(AppConstants.IMPORT_STRING)+6, currentLine.indexOf(AppConstants.FROM_STRING)-1).trim();
		}
		else if (currentLine.contains(AppConstants.FROM_STRING)) {
			name = currentLine.substring(0, currentLine.indexOf(AppConstants.FROM_STRING)-1).trim();
		}
		
		if(name.contains(AppConstants.OPEN_BRACES_STR) && name.contains(AppConstants.CLOSE_BRACES_STR)) {
			name = name.substring(name.indexOf(AppConstants.OPEN_BRACES_STR)+1, name.indexOf(AppConstants.CLOSE_BRACES_STR)-1).trim();
		}		
		return name;
	}
	
	
	/**
     * Method name  : addImportToList
     * Description  : Method that adds the imported component names to list for checking their usage in the file
     * Return Type  : void
     * Parameter    : String aliasName, List<String> importNames
     **/
	private static void addImportToList(String aliasName, List<String> importNames) {		
		importNames.add(aliasName);
	}
	
	
	/**
     * Method name  : addLinesToMap
     * Description  : Method that adds the import statement lines & line numbers to map for checking their usage in the file
     * Return Type  : void
     * Parameter    : Map<String, Integer> importsLineNumMap, Map<String, String> importsMap, String currentLine, int lineNum
     **/
	private static void addLinesToMap(Map<String, Integer> importsLineNumMap, Map<String, String> importsMap, String currentLine, int lineNum) {
		
		importsLineNumMap.put(currentLine, lineNum);
		importsMap.put(currentLine, currentLine);
	}
	
	
	/**
     * Method name  : checkImportComponentUsage
     * Description  : Method that checks for imported component's usage in code and removes the imported component from the list if used
     * Return Type  : void
     * Parameter    : List<String> importNames, String currentLine, Deque<String> commentedLineDeque
     **/
	private static void checkImportComponentUsage(List<String> importNames, String currentLine, Deque<String> commentedLineDeque) {
		
		String alias;
		Iterator<String> iter = importNames.iterator();
		Matcher importAliasUsage;
		Matcher singleLineCommentMatcher;
		
		while (iter.hasNext()) { 
			
			alias = iter.next();
			
			pushCommentedLine(currentLine, commentedLineDeque);
			
			importAliasUsage = Pattern.compile(IMPORT_ALIAS_USAGE_PATTERN.replace("<aliasName>", alias)).matcher(currentLine);
			singleLineCommentMatcher = SINGLE_LINE_COMMENT_PATTERN.matcher(currentLine);
			
			//Check if the current line uses any import and that it is not part of commented code
			if (importAliasUsage.find() && !singleLineCommentMatcher.find()) {

				if (!commentedLineDeque.isEmpty() && !AppConstants.COMMENT_END_PATTERN.equals(commentedLineDeque.peek())) {
					break;
				}
					
				// Remove the import alias from the list because it is being used in the code
				iter.remove();
			}
		}
	}
	
	/**
     * Method name  : removeLeftoverPatterns
     * Description  : Method to remove all the leftover patterns remaining in the update statement after removing imported component
     * Example		: Before removing unused import : import LightningElement, { wire as wired, track }, api from 'lwc';
     * 				  After removing unused import  : import , { wire as , track },  from 'lwc';
     * 				  After this method runs        : import { track } from 'lwc';
     * Return Type  : void
     * Parameter    : List<String> importNames, Map<String, String> importsMap
     **/
	private static void removeLeftoverPatterns(List<String> importNames, Map<String, String> importsMap) {
		
		String importStmt;
		String updatedImportStmt;
		
		Matcher extraAsInBraceMatcher = null;
		Matcher extraAsBeforeStartBraceMatcher = null;
		Matcher wordAsBlankMatcher = null;
		Matcher spaceBetweenTwoCommaMatcher = null;		
		Matcher extraCommaBeforeCloseBraceMatcher = null;
		Matcher emptyBraceMatcher = null;		
		Matcher extraCommaInBraceMatcher;
		
		//Remove the import alias from imports map
		for (String alias : importNames) {
			for (Map.Entry<String, String> entry : importsMap.entrySet()) {

				importStmt = entry.getValue();				

				extraCommaInBraceMatcher = EXTRA_COMMA_IN_BRACE_PATTERN.matcher(alias);
				
				if (importStmt.indexOf(alias) != -1) {

					//Remove the import being used from the import statement
					updatedImportStmt = importStmt.replace(alias, AppConstants.EMPTY);

					extraAsInBraceMatcher = EXTRA_AS_IN_BRACE_PATTERN.matcher(updatedImportStmt);
					if(extraAsInBraceMatcher.find()) {
						updatedImportStmt = extraAsInBraceMatcher.replaceAll(AppConstants.EMPTY);
					}
					
					extraAsBeforeStartBraceMatcher = EXTRA_AS_BEFORE_START_BRACE_PATTERN.matcher(updatedImportStmt);
					if(extraAsBeforeStartBraceMatcher.find()) {
						updatedImportStmt = extraAsBeforeStartBraceMatcher.replaceAll(OPEN_CURLY_SPACE);
					}
					
					wordAsBlankMatcher = WORD_AS_BLANK_PATTERN.matcher(updatedImportStmt);
					if(wordAsBlankMatcher.find()) {
						updatedImportStmt = wordAsBlankMatcher.replaceAll(COMMA_SPACE);
					}
					
					spaceBetweenTwoCommaMatcher = SPACE_BETWEEN_TWO_COMMA_PATTERN.matcher(updatedImportStmt);
					if(spaceBetweenTwoCommaMatcher.find()) {
						updatedImportStmt = spaceBetweenTwoCommaMatcher.replaceAll(COMMA_SPACE);
					}										
					
					extraCommaBeforeCloseBraceMatcher = EXTRA_COMMA_BEFORE_CLOSE_BRACE_PATTERN.matcher(updatedImportStmt);
					if(extraCommaBeforeCloseBraceMatcher.find()) {
						updatedImportStmt = extraCommaBeforeCloseBraceMatcher.replaceAll(CLOSE_CURLY_SPACE);
					}
					
					emptyBraceMatcher = EMPTY_BRACE_PATTERN.matcher(updatedImportStmt);
					if(emptyBraceMatcher.find()) {
						updatedImportStmt = emptyBraceMatcher.replaceAll(AppConstants.EMPTY);
					}
					
					if (extraCommaInBraceMatcher.find()) {
						updatedImportStmt = updatedImportStmt.replace(AppConstants.COMMA_STRING, AppConstants.EMPTY);
					}
					
					updatedImportStmt = removeAdditionalPatterns(updatedImportStmt);										
					
					importsMap.put(entry.getKey(), updatedImportStmt);
					break;
				}
			}
		}
	}
	
	
	/**
     * Method name  : removeAdditionalPatterns
     * Description  : Method to remove all the leftover patterns remaining in the update statement after removing imported component
     * Example		: Before removing unused import : import LightningElement, { wire as wired, track }, api from 'lwc';
     * 				  After removing unused import  : import , { wire as , track },  from 'lwc';
     * 				  After this method runs        : import { track } from 'lwc';
     * Return Type  : void
     * Parameter    : List<String> importNames, Map<String, String> importsMap
     **/
	private static String removeAdditionalPatterns(String updatedImportStmt) {
		
		Matcher extraCommaAfterCloseBraceMatcher = null;
		Matcher extraCommaBeforeFromMatcher = null;
		Matcher commaBeforeFromMatcher = null;
		Matcher extraAsBeforeFromMatcher = null;
		Matcher extraWordBeforeFromMatcher = null;
		Matcher extraCommaAfterStartBraceMatcher = null;
		Matcher extraCommaAfterImportMatcher = null;
		Matcher extraWordAfterStartBraceMatcher = null;
		
		extraCommaBeforeFromMatcher = EXTRA_COMMA_BEFORE_FROM_PATTERN.matcher(updatedImportStmt);
		if(extraCommaBeforeFromMatcher.find()) {
			updatedImportStmt = extraCommaBeforeFromMatcher.replaceAll(FROM_WITH_SPACE);
		}										
		
		extraAsBeforeFromMatcher = EXTRA_AS_BEFORE_FROM_PATTERN.matcher(updatedImportStmt);
		if(extraAsBeforeFromMatcher.find()) {
			updatedImportStmt = extraAsBeforeFromMatcher.replaceAll(FROM_WITH_SPACE);
		}
		
		extraWordBeforeFromMatcher = EXTRA_WORD_BEFORE_FROM_PATTERN.matcher(updatedImportStmt);
		if(extraWordBeforeFromMatcher.find()) {
			updatedImportStmt = extraWordBeforeFromMatcher.replaceAll(FROM_WITH_SPACE);
		}
		
		commaBeforeFromMatcher = COMMA_BEFORE_FROM_PATTERN.matcher(updatedImportStmt);
		if(commaBeforeFromMatcher.find()) {
			updatedImportStmt = commaBeforeFromMatcher.replaceAll(CLOSE_CURLY_BRACE_FROM);
		}
		
		extraCommaAfterStartBraceMatcher = EXTRA_COMMA_AFTER_START_BRACE_PATTERN.matcher(updatedImportStmt);
		if(extraCommaAfterStartBraceMatcher.find()) {
			updatedImportStmt = extraCommaAfterStartBraceMatcher.replaceAll(OPEN_CURLY_SPACE);
		}
		
		extraCommaAfterImportMatcher = EXTRA_COMMA_AFTER_IMPORT_PATTERN.matcher(updatedImportStmt);
		if(extraCommaAfterImportMatcher.find()) {
			updatedImportStmt = extraCommaAfterImportMatcher.replaceAll(IMPORT_SPACE);
		}
		
		extraWordAfterStartBraceMatcher = EXTRA_WORD_AFTER_START_BRACE_PATTERN.matcher(updatedImportStmt);
		if(extraWordAfterStartBraceMatcher.find()) {
			updatedImportStmt = extraWordAfterStartBraceMatcher.replaceAll(AppConstants.OPEN_BRACES_STR);
		}
		
		extraCommaAfterCloseBraceMatcher = EXTRA_COMMA_AFTER_CLOSE_BRACE_PATTERN.matcher(updatedImportStmt);
		if(extraCommaAfterCloseBraceMatcher.find()) {
			updatedImportStmt = extraCommaAfterCloseBraceMatcher.replaceAll(CLOSE_CURLY_COMMA_SPACE);
		}
		
		return updatedImportStmt;
	}
	
	
	/**
     * Method name  : createViolation
     * Description  : Method that creates Violation objects based on whether line needs to be removed or the existing value
     * 				  needs to be updated
     * Return Type  : void
     * Parameter    : Map<String, String> importsMap, Map<String, Integer> importsLineNumMap, List<Violation> lstViolation
     **/
	private static void createViolation(Map<String, String> importsMap, Map<String, Integer> importsLineNumMap, List<Violation> lstViolation) {
		
		String importStmt;
		String updatedImportStmt;
		Matcher importFromPatternMatcher;
		Violation violation = null;
		
		for(Map.Entry<String, String> entry : importsMap.entrySet()) {
			
			importStmt = entry.getKey();
			updatedImportStmt = entry.getValue();
			importFromPatternMatcher = IMPORT_FROM_PATTERN.matcher(updatedImportStmt);

			//If the existing import stmt and the updated import stmt are the same, then don't create violation
			if(!AppConstants.EMPTY.equals(updatedImportStmt) && !updatedImportStmt.equals(importStmt)) {
				int lineNum = importsLineNumMap.get(importStmt);
				
				violation = new Violation();
				violation.setBeginline(BigInteger.valueOf(lineNum));
				violation.setRule(CustomValidationRules.UNNECESSARY_IMPORTS_JS);
				
				//If the updated import stmt does not have any imported components, then line needs to be removed 
				if(importFromPatternMatcher.find()) {							
					violation.setValue(AppConstants.NEED_TO_REMOVE_THIS_LINE);								
				}
				//Else, set the updated imported stmt
				else {
					violation.setValue(updatedImportStmt);
				}
				lstViolation.add(violation);
			}
		}
	}
}
