package org.autofix.ui;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import org.autofix.common.ApplicationParameter;
import org.autofix.ui.panel.ForceReviewerPanel;
import org.autofix.ui.panel.HomePanel;
import org.autofix.ui.panel.ReportPanel;
import org.autofix.ui.panel.RuleConfigurationPanel;
import org.autofix.utility.AutofixUIUtility;
import org.autofix.utility.HttpUtility;
import org.autofix.utility.Logging;



public class AutofixUI_Frame extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private Map<JMenuItem, ForceReviewerPanel> forceReviewerMenu;
	private JMenuItem currentSelectedMenuItem;
	private JMenuItem defaultSelectedMenuItem;
	private Font SALESFORCE_SANS_PLAIN_24 = new Font("Salesforce Sans", Font.PLAIN,24);
	private Font SALESFORCE_SANS_PLAIN_10 = new Font("Salesforce Sans", Font.PLAIN,10);

	public AutofixUI_Frame(){
		super("Auto-Fix Utility");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setPreferredSize(new Dimension(800,600));
		this.setMinimumSize(new Dimension(600,450));
	}
	private static Image getScaledImage(Image srcImg, int w, int h){
		BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = resizedImg.createGraphics();

		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();

		return resizedImg;
	}

	public void generateUI() throws IOException {

		UIManager.put("swing.boldMetal", Boolean.FALSE);

		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("staticresource/FORCE_REVIEWER.png");
		// Header Section
		BufferedImage wPic = ImageIO.read(input);
		Image ic = getScaledImage(wPic,110,43);
		JLabel wIcon = new JLabel(new ImageIcon(ic));
		Box verticalBox = Box.createHorizontalBox();
		verticalBox.setBorder(BorderFactory.createLineBorder(Color.decode("#1AA2DD")));
		verticalBox.setBounds(0, 0, 800, 45);
		JLabel title = new JLabel("<html><span style='color: White;'>&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;Auto-Fix Utility</span></html>");
		title.setFont(SALESFORCE_SANS_PLAIN_24);
		verticalBox.add(wIcon);
		verticalBox.add(title);	
		verticalBox.setOpaque(true);
		verticalBox.setForeground(Color.decode("#152D4B"));
		verticalBox.setBackground(Color.decode("#152D4B"));
		// Header Section Ends

		// Side Bar Section Starts
		Box titleText = Box.createVerticalBox();
		titleText.setBounds(0, 45, 200, 600);
		titleText.setOpaque(true);
		titleText.setForeground(Color.decode("#152D4B"));
		titleText.setBackground(Color.decode("#152D4B"));
		configureMenu();
		for(JMenuItem menu : forceReviewerMenu.keySet()){
			menu.setBackground(Color.decode("#152D4B"));
			menu.addActionListener(this);
			titleText.add(menu);
			titleText.add(Box.createRigidArea(new Dimension(0, 5)));
		}
		forceReviewerMenu.get(currentSelectedMenuItem).entry();
		// Sidebar Section Ends

		// Footer Starts
		JLabel copyRight = new JLabel("<html><span style='color: White;'>&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
				+ "Copyright &#169; 2020 Deloitte Digital. All rights reserved. Version 3.0</span></html>");
		copyRight.putClientProperty("html", null);
		copyRight.setFont(SALESFORCE_SANS_PLAIN_10);

		Box footerBox = Box.createHorizontalBox();
		footerBox.setBorder(BorderFactory.createLineBorder(Color.decode("#1AA2DD")));
		footerBox.add(copyRight);
		footerBox.setOpaque(true);
		footerBox.setForeground(Color.decode("#152D4B"));
		footerBox.setBackground(Color.decode("#152D4B"));
		footerBox.setBounds(0,540, 800, 30);
		// Footer Ends

		this.add(footerBox);
		this.add(verticalBox);
		this.add(titleText);				
		this.pack();
		this.getContentPane().setBackground(Color.WHITE);
		this.setIconImage(ImageIO.read(input));
		this.setVisible(true);
		this.setResizable(false);

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				ApplicationParameter.deleteTempFolder();
			}
		});
	}

	public static void initUI(){
		AutofixUI_Frame fr =new AutofixUI_Frame();
		try {
			HttpUtility.authenticateUser();
			AutofixUIUtility.setAutoFixUIRef(fr);
			fr.generateUI();
		} catch (Exception e) {
			e.printStackTrace();
			Logging.log(e);
			String msg = "<html><span style='color: black;'><font size=\\\"12\\\" "
					+ "face=\\\"Arial\\\">"+e.getMessage()+"</font></span></html>";
			JLabel msgLabel = new JLabel(msg);
			msgLabel.setFont(new Font("serif", Font.PLAIN, 14));
			JOptionPane.showMessageDialog(fr,msgLabel);
			System.exit(0);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() instanceof JMenuItem){
			JMenuItem actionedMenuItem = (JMenuItem) e.getSource();
			if(actionedMenuItem == currentSelectedMenuItem){
				return;
			}
			try{
				forceReviewerMenu.get(currentSelectedMenuItem).exit();
				forceReviewerMenu.get(actionedMenuItem).entry();
				currentSelectedMenuItem = actionedMenuItem;
			}catch(Exception error){
				error.printStackTrace();
			}
		}
	}

	public void configureMenu(){
		JMenuItem configMenu = new JMenuItem("<html><span style='color: White;'><font size=\"5\" face=\"Arial\">Configure Rules</font></span></html>"); 		
		JMenuItem utilityMenu = new JMenuItem("<html><span style='color: White;'><font size=\"5\">Auto-Fix Rules</span></font></html>");
		JMenuItem reportMenu = new JMenuItem("<html><span style='color: White;'><font size=\"5\">Code Comparison</span></font></html>");
		forceReviewerMenu = new HashMap<>();
		forceReviewerMenu.put(configMenu, new RuleConfigurationPanel(this));
		forceReviewerMenu.put(utilityMenu, new HomePanel(this));
		forceReviewerMenu.put(reportMenu, new ReportPanel());
		currentSelectedMenuItem = utilityMenu; // By Default selected menu
		defaultSelectedMenuItem = utilityMenu;
	}

	public void setDefaultMenu(){
		try {
			forceReviewerMenu.get(currentSelectedMenuItem).exit();
			forceReviewerMenu.get(defaultSelectedMenuItem).entry();
			currentSelectedMenuItem = defaultSelectedMenuItem;
		} catch (Exception e) {
			Logging.log(e);
		}
	}


}
