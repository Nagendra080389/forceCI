package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Below class for all EmptyCss Properties to be removed from CSS
 * @author Manuraj
 * @version 1.0
 * @modified 2020-08-10
 */

public class RemoveEmptyPropertiesFromCSS implements IValidation{
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		Violation tempViolation;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				violationLst = new ArrayList<>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				boolean blockStarted = false;
				List<String> propertyNames = new ArrayList<String>();
				for (int i = 0; i < lstLines.size(); i++) {
					String currentLine = lstLines.get(i).trim();
					if(currentLine.isEmpty()) {
						continue;
					}
					if(blockStarted) {
						String[] property = currentLine.split(":");
						if(property.length>=2) {
						Integer sb=property[1].trim().length();
							if(property.length >= 0 && sb==1) {
							tempViolation = new Violation();
							tempViolation.setBeginline(BigInteger.valueOf(i+1));
							tempViolation.setEndline(BigInteger.valueOf(i+1));
							tempViolation.setRule(CustomValidationRules.REMOVE_EMPTY_PROPERTIES_CSS);
							violationLst.add(tempViolation);
							}else {
							propertyNames.add(property[1]);
							}
						}
					}
					if(currentLine.endsWith("{")) {
						blockStarted = true;
					}else if(currentLine.endsWith("}") && blockStarted) {
						blockStarted = false;
						propertyNames.clear();
					}
				}
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	
}
