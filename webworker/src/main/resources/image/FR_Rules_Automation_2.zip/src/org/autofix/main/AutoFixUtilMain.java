package org.autofix.main;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.autofix.common.AutofixValidationRules;
import org.autofix.constants.AppConstants;
import org.autofix.model.Autofix_Rule;
import org.autofix.service.AutofixService;
import org.autofix.ui.AutofixUI_Frame;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class AutoFixUtilMain {
    public static Boolean boolRunOnFolder = Boolean.parseBoolean(System.getProperty(AppConstants.AUTO_FIX_WORKSPACE));
    public static Boolean boolIsRunningFromAutoFixExtension = Boolean.parseBoolean(System.getProperty(AppConstants.AUTO_FIX_EXTENSION));
    public static Boolean boolIsAutoFixAPIAvailable = Boolean.parseBoolean(System.getProperty(AppConstants.AUTO_FIX_EXTENSION_API_AVAILABLE));
    public static Boolean boolGetAllAutofixRules = Boolean.parseBoolean(System.getProperty("GET_ALL_AUTO_FIX_RULES"));
    public static List<String> selectedRulesFromExtn = new ArrayList<>();
    private static final String AUTOFIXRULES = "AUTO_FIX_RULES";
    private static final String ALLAUTOFIXRULES = "ALL_AUTO_FIX_RULES";


    public static void main(String[] args) {
        if (boolIsRunningFromAutoFixExtension) {
            if (boolGetAllAutofixRules) {
                setFrRulesToSystemVariable();
            } else if (args.length == 2) {
                runForExtension(args);
            } else {
                System.out.println("Wrong number of arguments");
            }
        } else {
            AutofixUI_Frame.initUI();
        }
    }

    private static void setFrRulesToSystemVariable() {
        StringBuilder builder = new StringBuilder();
        for (Autofix_Rule fr_rule : AutofixValidationRules.getFrRuleSettings()) {
            builder.append(fr_rule.getUniqueRuleName() + "=" + fr_rule.getRuleInfoForUI() + "||");
        }
        System.setProperty(ALLAUTOFIXRULES, builder.toString());
    }

    private static void runForExtension(String[] args) {
        Gson gson = new Gson();
        Type type = new TypeToken<List<String>>() {
        }.getType();
        List<String> lstRulesStaticNamesToBeFixed = selectedRulesFromExtn = gson.fromJson(System.getProperty(AUTOFIXRULES), type);

        //Filter the passed rules and remove rules which are not passed
        for (Autofix_Rule fr_rule : AutofixValidationRules.getFrRuleSettings()) {
            if (lstRulesStaticNamesToBeFixed.contains(fr_rule.getUniqueRuleName())) {
                fr_rule.setSelected(true);
            } else {
                fr_rule.setSelected(false);
            }
        }
        if (boolRunOnFolder) {
            new Thread(new AutofixService(args[0])).start();
        } else {
            new Thread(new AutofixService(args[0], args[1])).start();
        }
    }
}
