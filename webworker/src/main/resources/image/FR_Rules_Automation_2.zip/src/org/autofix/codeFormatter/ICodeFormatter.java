package org.autofix.codeFormatter;

import java.util.List;
import java.util.Map;

public interface ICodeFormatter {
	
	public List<String> formatCode(List<String> inputLst, List<Integer> intLst);
	
	public List<String> formatCode(List<String> inputLst, List<Integer> beginLineLst, Map<Object, Object> startEndLineMap);

}
