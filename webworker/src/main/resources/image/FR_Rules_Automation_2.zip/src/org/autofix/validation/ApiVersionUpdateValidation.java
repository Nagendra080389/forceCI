package org.autofix.validation;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.common.CustomException;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.AutofixUIUtility;
import org.autofix.utility.Logging;

/**
* Program to validate apiVersion in xml file
* If apiVersion is not matching with user input/default apiVersion
* then File is a Invalid File.
*
* @author  Laltu Banerjee
* @version 1.0
* @since   2020-05-23
*/

public class ApiVersionUpdateValidation implements IValidation{

	private static final Pattern DETECT_API_VERSION_PATTERN = Pattern.compile("<apiVersion>[0-9]*.0</apiVersion>");
	private static final Pattern GET_API_VERSION_PATTERN = Pattern.compile("[0-9]*.0");
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		Violation tempViolation;
		File tempFile;
		for(String filePath : fileNameLst){
			try {
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				for(int i=0;i<lstLines.size();i++){
					try {
						tempViolation = checkForViolation(lstLines.get(i), i+1);
						if(tempViolation != null){
							tempFile = new File();
							tempFile.setName(filePath);
							tempFile.getViolation().add(tempViolation);
							invalidFiles.add(tempFile);
							break;
						}
					} catch (CustomException e) {
						break;
					}
				}
			} catch (IOException e) {
				Logging.log(e,"error occured for file :: "+filePath);
			}
		}
		return invalidFiles;
	}
	
	/**
	   * Method for returning org.fpr.model.Violation {@code} 
	   * if criteria matches
	   * @param line input string
	   * @param linenumber line no. of input Line
	   * @return Violation
	   * @throws CustomException to break the loop,
	   * If apiVersion in line is same as expected.
	   */
	private Violation checkForViolation(String line,int linenumber) throws CustomException{
		Matcher detectMatcher = DETECT_API_VERSION_PATTERN.matcher(line);
		if(detectMatcher.find()){
			 Matcher getMatcher = GET_API_VERSION_PATTERN.matcher(detectMatcher.group());
			 if(getMatcher.find()){
				 double fileApiVersionVal = Double.valueOf(getMatcher.group());
				 if(AutofixUIUtility.getApiVersionUpdateValue() != fileApiVersionVal ){
					 Violation violation = new Violation();
					 violation.setBeginline(BigInteger.valueOf(linenumber));
					 violation.setBegincolumn(BigInteger.valueOf(detectMatcher.start()));
					 violation.setEndcolumn(BigInteger.valueOf(detectMatcher.end()));
					 violation.setRule(CustomValidationRules.API_VERSION_UPGRADE_XML);
					 return violation;
				 }
				 else{
					 throw new CustomException("Break this loop");
				 }
			 }
		}
		return null;
	}

}
