package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Program to detect extra semi colon in javascript code
 *
 * @author Akshay Anil Agrawal
 * @version 1.0
 * @since 2020-08-11
 */
public class RemoveExtraSemiColonFromJsValidation implements IValidation {

	private static final Pattern CONSECUTIVE_SEMICOLONS_PATTERN = Pattern.compile("(;\\s*)+;");

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		Violation tempViolation;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				violationLst = new ArrayList<>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));

				for (int i = 0; i < lstLines.size(); i++) {
					tempViolation = checkForViolation(lstLines.get(i), i + 1);
					if (tempViolation != null) {
						violationLst.add(tempViolation);
					}
				}
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	/**
	 * Detects consecutive semi colons
	 * @param line
	 * @param lineNumber
	 * @return Violation
	 */
	private Violation checkForViolation(String line, int lineNumber) {
		Violation v = null;
		Matcher m = CONSECUTIVE_SEMICOLONS_PATTERN.matcher(line);
		if (m.find()) {
			v = new Violation();
			v.setBeginline(BigInteger.valueOf(lineNumber));
			v.setRule(CustomValidationRules.REMOVE_EXTRA_SEMICOLON_JS);
		}
		return v;
	}

}
