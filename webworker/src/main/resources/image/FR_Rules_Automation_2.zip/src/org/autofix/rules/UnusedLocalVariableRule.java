package org.autofix.rules;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
 * This rule class fixes the unused local variable violations. 
 * This marks the line to be removed if only variable(unused) is present in the line.
 * If there are multiple variables in a line, it removes the unused variable from that line.
 * @author nikhikumar
 * 
 */
public class UnusedLocalVariableRule implements IFRRules{
	
	String varDefinedAndNotOne = "(^[ *=][^,;]*,)"; //To check if the variable is defined and has variables after this
	String varUndefinedAndNotOne = "^( *),"; //To check if the variable is undefined and has variables after this
	String hasVarBeforeUnused = "(, *)$"; //To check if there is any variables before the unused one
	Pattern pDefinedAndNotOne = Pattern.compile(varDefinedAndNotOne);
	Pattern pUndefinedAndNotOne = Pattern.compile(varUndefinedAndNotOne);
	Pattern pHasVarBeforeUnused = Pattern.compile(hasVarBeforeUnused);
	
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		ViolationInfo info;
		String line;
		String newLine;
		for(Violation v: violationLst){
			info = new ViolationInfo(fileName, v.getRule());
			line = allLines.get(v.getBeginline().intValue()-1);
			info.setBeforeFix(line);
			try{
				newLine = checkIfOnlyOneVariable(line, v.getBegincolumn().intValue()-1, v.getEndcolumn().intValue());
				if(newLine!=null && !newLine.isEmpty()){
					if(newLine.equals(line)){
						//Line has only one variable(unused). Marking this line to be removed
						allLines.set(v.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
						info.setAfterFix(AppConstants.NEED_TO_REMOVE_THIS_LINE);
						Reporting.violationInfos.add(info.toCSVRow());
					}
					else{
						//Replace the unused variable line.
						allLines.set(v.getBeginline().intValue()-1,newLine);
						info.setAfterFix(newLine);
						Reporting.violationInfos.add(info.toCSVRow());
					}
				}
			}
			catch(Exception exc){
				throw new CustomException("Exception occured in UnusedLocalVariableRule class:"+exc.getMessage());
			}
		}
		
	}
	
	/*This method checks if only one unused variable is present in the line or
	has a combination of used and unused.*/
	public String checkIfOnlyOneVariable(String line, int begCol, int endCol){
		String newLine = line.substring(0, begCol);
		Matcher mDefinedAndNotOneVar = pDefinedAndNotOne.matcher(line.substring(endCol, line.length()));
		Matcher mUndefinedAndNotOneVar = pUndefinedAndNotOne.matcher(line.substring(endCol, line.length()));
		Matcher mCommaBefore = pHasVarBeforeUnused.matcher(line.substring(0, begCol));
		/*If unused var is defined and has more variables after it,
		 removing the variable and its definition from the line*/
		if(mDefinedAndNotOneVar.find()){
			newLine = newLine+ line.substring(endCol+mDefinedAndNotOneVar.end()+1, line.length());
		}
		
		/*If unused var is undefined and has more variables after it,
		 removing the variable from the line*/
		else if(mUndefinedAndNotOneVar.find()){
			newLine+=line.substring(endCol+mUndefinedAndNotOneVar.end());
		}
		//If there are variables before the unused,removing just the unused var
		else if(mCommaBefore.find()){
			newLine = line.substring(0, mCommaBefore.start())+";";
		}
		//If the line has only one variable and that is unused, returning the same line
		else{
			newLine+=line.substring(begCol, line.length());;
		}
		return newLine;
	}

}
