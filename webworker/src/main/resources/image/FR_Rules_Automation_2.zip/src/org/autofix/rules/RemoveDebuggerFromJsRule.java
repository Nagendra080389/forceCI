package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

/**
 * Below class is the rule for all debugger statements from JS validation
 * @author Manuraj
 * @version 1.0
 * @modified 2020-08-10
 */


public class RemoveDebuggerFromJsRule implements IFRRules {

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		String currentLine;
		ViolationInfo info;
		for (Violation v : violationLst) {
			info = new ViolationInfo(fileName, v.getRule());
			currentLine = allLines.get(v.getBeginline().intValue()-1);
			info.setBeforeFix(currentLine);
			if(v.getEndline() != null) {
				int endIndex = v.getEndline().intValue()-1;
				for(int i=v.getBeginline().intValue()-1;i<=endIndex;i++) {
					allLines.set(i, AppConstants.NEED_TO_REMOVE_THIS_LINE);
				}
			} else {
				allLines.set(v.getBeginline().intValue()-1, AppConstants.NEED_TO_REMOVE_THIS_LINE);
			}			
			info.setAfterFix(AppConstants.NEED_TO_REMOVE_THIS_LINE);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}
