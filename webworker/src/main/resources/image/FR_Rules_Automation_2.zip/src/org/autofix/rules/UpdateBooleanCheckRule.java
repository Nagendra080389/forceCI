package org.autofix.rules;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
 * Autofix rule file to fix the violations in boolean checks. 
 * Example : 
 * Before Autofix : if(ttt.red.card.PSP_Replacement__c == false && a == true && a == false);
 * After Autofix :  if(!ttt.red.card.PSP_Replacement__c && a  && !a);
 * @author raedu
 *
 */
public class UpdateBooleanCheckRule implements IFRRules {
	// pattern for fetching the preceding word of the false boolean check
	private static final Pattern pattern = Pattern
			.compile("((\\w*\\.)+)?\\w+(\\s?)(?<!=)==(?!=)(\\s?)\\b((?i)false(?-i))\\b");

	private Comparator<Violation> violationComparator = (v1, v2) -> v2.getBegincolumn().compareTo(v1.getBegincolumn());

	/**
	 * Method name : doOperation Description : fetches the violations from the
	 * violation list and fixes them as per the rule
	 * Return Type : void
	 * Parameter : String fileName, List<String> allLines, List<Violation>
	 * violationList
	 **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationList)
			throws CustomException {
		String currentLine;
		ViolationInfo info;
		Map<BigInteger, List<Violation>> violationMap = violationList.stream()
				.collect(Collectors.groupingBy(Violation::getBeginline));
		List<Integer> indexList = new ArrayList<>();
		Comparator reverseOrder = Collections.reverseOrder();
		for (BigInteger beginLine : violationMap.keySet()) {
			violationMap.get(beginLine).sort(violationComparator);
			for (Violation v : violationMap.get(beginLine)) {
				info = new ViolationInfo(fileName, v.getRule());
				currentLine = allLines.get(beginLine.intValue() - 1);
				info.setBeforeFix(currentLine);
				String replaceStringContent = currentLine.substring(v.getBegincolumn().intValue(),
						v.getEndcolumn().intValue());
				if (replaceStringContent.toLowerCase().contains("false")) {
					Matcher matcher = pattern.matcher(currentLine);
					while (matcher.find()) {
						indexList.add(matcher.start());
					}
					Collections.sort(indexList, reverseOrder);
					for (int j = 0; j < indexList.size(); j++) {
						if (currentLine.substring(indexList.get(j)) != null && !(currentLine
								.substring(indexList.get(j), v.getEndcolumn().intValue()).contains("!"))) {
							currentLine = new StringBuilder(currentLine)
									.replace(v.getBegincolumn().intValue(), v.getEndcolumn().intValue(), "").toString();
							currentLine = new StringBuilder(currentLine).insert(indexList.get(j), "!").toString();
							indexList.clear();
							break;
						}
					}
				} else {
					currentLine = new StringBuilder(currentLine)
							.replace(v.getBegincolumn().intValue(), v.getEndcolumn().intValue(), "").toString();
				}
				allLines.set(beginLine.intValue() - 1, currentLine);
				info.setAfterFix(currentLine);
				Reporting.violationInfos.add(info.toCSVRow());
			}
		}
	}
}
