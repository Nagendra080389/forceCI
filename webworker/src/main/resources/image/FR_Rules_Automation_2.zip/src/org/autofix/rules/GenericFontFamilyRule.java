package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
* Autofix rule file to add "sans-serif" as generic font family if font-family block does not contain at least one
* generic font family in a CSS file.
* Example : Before Autofix : font-family { Times New Roman; }
*  		  : After Autofix : font-family { Times New Roman, sans-serif; }
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-07-17
*/

public class GenericFontFamilyRule implements IFRRules {		

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		String currentLine;
		ViolationInfo info;
		for (Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			currentLine = allLines.get(violation.getEndline().intValue()-1);
			currentLine = currentLine.replaceFirst(AppConstants.SEMI_COLON_CHARACTER, violation.getValue());
			allLines.set(violation.getEndline().intValue()-1, currentLine);
			info.setAfterFix(currentLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}