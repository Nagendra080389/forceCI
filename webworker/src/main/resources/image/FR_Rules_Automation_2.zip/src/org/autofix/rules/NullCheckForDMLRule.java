package org.autofix.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Logging;
import org.autofix.utility.Reporting;

/**
 * This class updates the code with Perform ISNULL before DML Operation fixes
 *  Example: - Before fix : Insert accList;
 *							Database.insert(accList);
 *							Database.insert(accList,true);
 *
 *            After fix : if(!accList.isEmpty){
 *                            insert accList;
 *                            Database.insert(accList);
 *                            Database.insert(accList,true);
 *                            }
 * @author ruchkumari
 *  @version 1.0
 *
 */
public class NullCheckForDMLRule  implements IFRRules{
	private static final  String WHITESPACE_PATTERN = "[\\s]+";
	private static final  String DATABASE_VARIABLE_PATTERN = "[\\\\s]*[Database.]+(insert|update|upsert|delete|undelete|merge)+[\\s]*[\\)\\r\\n\\s\\(\\,\\;]*";
	private static final String IFSTATMENT = "if(";
	private static final  String CLOSE_BRACE = ")";
	private static final  String CURLY_OPEN_BRACE = "{";
	private static final  String CURLY_CLOSE_BRACE = "}";
	private static final  String ISEMPTY = ".isEmpty()";
	private static final  String NOT = "!";
	private static final  String NEW_LINE= "\n" ;
	private static final  String BOOLEAN_OPERATOR= "(true|false|FALSE|TRUE)+";
	private static final  String SEMICOLON_COMMA = "[\\;|\\,|\\)\\s]*";
	private static final  String MERGE_VAR_FOR_IF_STMT = " && !";
	private static final  String COMMA = "[\\s]*[\\,]+[\\s]*";
	
	
	/* (non-Javadoc)
	 * @see org.fpr.FRRules.IFRRules#doOperation(java.lang.String, java.util.List, java.util.List)
	 * Method name  : doOperation
	 * Description  : updates the code with Perform ISNULL before DML Operation fixes
	 * Return Type  : void
	 * Parameter    : List<String> allLines, List<Violation> violationLst
	 */
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String tempContent = "";
		String content="";
		ViolationInfo info;
		try {
			for(Violation violation : violationLst) {
				info = new ViolationInfo(fileName, violation.getRule());
				if(violation.getEndcolumn().intValue() != -1) {
					tempContent = allLines.get(violation.getEndline().intValue()-1);
					info.setBeforeFix(tempContent);
					tempContent = tempContent.substring(violation.getBegincolumn().intValue(),violation.getEndcolumn().intValue());
					String varName = getVariableFromDML(tempContent);					
					content = IFSTATMENT+NOT+varName+ISEMPTY+CLOSE_BRACE+ CURLY_OPEN_BRACE+tempContent+CURLY_CLOSE_BRACE;
					int leftpad = content.length()+violation.getBegincolumn().intValue();
					content = StringUtils.leftPad(content, leftpad);
					info.setAfterFix(content);
				}
				allLines.set(violation.getBeginline().intValue()-1, content);
				Reporting.violationInfos.add(info.toCSVRow());
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			Logging.log(ex.getMessage());
		}
	}


	/**
	 * This method gets the variable name from DML operation
	 * @param tempContent
	 * @return
	 */
	private String getVariableFromDML(String tempContent) {
		String dmlCodeLine = tempContent.trim();
		String dmlVarLine ;
		String name ="";
		 // dml statement having structure like Database.MergeResult[] results1 = merge AccToUpsert AddressToUpsert;
		if(tempContent.contains("=")) {  
			String[] dmlLine = tempContent.split("=");
			if(dmlLine.length==2) {
					dmlCodeLine = dmlLine[1].trim();
			}
		}
		// dml statement having structure like Databse.*
		if(dmlCodeLine.contains("Database") && !dmlCodeLine.contains("merge")) { 
			StringBuilder varName = new StringBuilder(dmlCodeLine);
			varName = replaceAll(varName,DATABASE_VARIABLE_PATTERN,"");
			varName = replaceAll(varName,SEMICOLON_COMMA,"");
			varName = replaceAll(varName,BOOLEAN_OPERATOR,"");
			name = varName.toString();				
		}else if(dmlCodeLine.contains("Database") && dmlCodeLine.contains("merge")) {
			List<String> merVarName = new ArrayList<>();
			String[] mergeDmlStmtVar = dmlCodeLine.split(COMMA);
			for(String mergeVarName : mergeDmlStmtVar) {
				StringBuilder varName = new StringBuilder(mergeVarName);
				varName = replaceAll(varName,DATABASE_VARIABLE_PATTERN,"");
				varName = replaceAll(varName,SEMICOLON_COMMA,"");
				varName = replaceAll(varName,BOOLEAN_OPERATOR,"");
				merVarName.add(varName.toString());
			}
			if(merVarName.size()>=2) {
				name = merVarName.get(0)+ISEMPTY+MERGE_VAR_FOR_IF_STMT+merVarName.get(1);
			}
		}
		// dml having structure like insert/update... acct
		else {
			String[] varName = dmlCodeLine.split(WHITESPACE_PATTERN);	
			if(varName.length==2) {
				name = varName[1];
				name =  name.replace(";", "");
			}
			 // when dml having structure like 'merge AccToUpsert AddressToUpsert;'
			if(varName.length>=3 ) {
				if(varName[1].equals(varName[2])) {  // when both variable name is equal eg : merge AccToUpsert AccToUpsert;
				name = varName[1];
				}else {
					name = varName[1]+ISEMPTY+MERGE_VAR_FOR_IF_STMT+varName[2];
				}
				name =  name.replace(";", "");
			}
		}
		return name;
	}

	private StringBuilder replaceAll(StringBuilder varName, String regex, String replacment)
	{
		Pattern pattern = Pattern.compile(regex);		
		Matcher matcher = pattern.matcher(varName);
		varName = varName.replace(0, varName.length(), matcher.replaceAll(replacment));		
		return varName;    
	}
}
