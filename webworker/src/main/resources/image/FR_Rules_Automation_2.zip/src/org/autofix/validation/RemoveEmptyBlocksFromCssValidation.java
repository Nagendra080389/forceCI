package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Program to identify empty blocks in CSS code
 *
 * @author Prasenjeet Banerjee
 * @version 1.0
 * @since 2020-08-10
 */
public class RemoveEmptyBlocksFromCssValidation implements IValidation {

	private static final Pattern EMPTY_BLOCK = Pattern.compile("\\{\\}");

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		Violation tempViolation;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				violationLst = new ArrayList<>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				int curlyBraceStartLine = -1;
				int curlyBraceEndLine = -1;
				String currentLine = null;
				for (int i = 0; i < lstLines.size(); i++) {
					currentLine = lstLines.get(i).trim();
					tempViolation = checkForViolationInCurrentLine(currentLine, i + 1);
					if (tempViolation != null) {
						violationLst.add(tempViolation);
					} else if (currentLine.endsWith("{")) {
						curlyBraceStartLine = i + 1;
					} else if (currentLine.endsWith("}") && curlyBraceStartLine != -1) {
						curlyBraceEndLine = i + 1;
						tempViolation = new Violation();
						tempViolation.setBeginline(BigInteger.valueOf(curlyBraceStartLine));
						tempViolation.setEndline(BigInteger.valueOf(curlyBraceEndLine));
						tempViolation.setRule(CustomValidationRules.AVOID_EMPTY_BLOCKS_CSS);
						violationLst.add(tempViolation);
					} else if (!currentLine.trim().isEmpty()) {
						curlyBraceStartLine = -1;
						curlyBraceEndLine = -1;
					}
				}
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;
	}

	/**
	 * Checks if the current line has an empty block
	 * 
	 * @param line
	 * @param lineNumber
	 * @return
	 */
	private Violation checkForViolationInCurrentLine(String line, int lineNumber) {
		Matcher emptyBlockMatch = EMPTY_BLOCK.matcher(line);
		if (line != null && emptyBlockMatch.find()) {
			Violation v = new Violation();
			v.setBeginline(BigInteger.valueOf(lineNumber));
			v.setRule(CustomValidationRules.AVOID_EMPTY_BLOCKS_CSS);
			return v;
		}
		return null;
	}

}
