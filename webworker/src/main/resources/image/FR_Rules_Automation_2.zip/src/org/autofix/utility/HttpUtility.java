package org.autofix.utility;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.autofix.common.CustomException;
import org.autofix.constants.AppConstants;

public class HttpUtility {

	private static boolean userAuthenticated = false;
	@SuppressWarnings("restriction")
	public static void authenticateUser() throws ClientProtocolException, IOException, CustomException{
		try{
			if(userAuthenticated){
				return;
			}
			com.sun.security.auth.module.NTSystem NTSystem = new com.sun.security.auth.module.NTSystem();
			String userName = NTSystem.getName();
			String jsonBody = "{\"email\":\""+userName+"\"}";
			System.out.println(jsonBody);
			HttpResponse response = makeHttpPostRequest(jsonBody, AppConstants.USER_AUTH_URL);
			int statusCode = response.getStatusLine().getStatusCode();
			if(statusCode == 200){
				String responseBody = EntityUtils.toString(response.getEntity());
				if(responseBody.equals(AppConstants.AUTH_SUCCESS_MESSAGE)){
					Logging.log("User authenticated successfully");
					userAuthenticated = true;
					return;
				}
				else if(responseBody.equals(AppConstants.AUTH_EMAIL_SENT_MESSAGE)){
					throw new CustomException(AppConstants.EMAIL_SENT_USER_MESSAGE);
				}
				throw new CustomException("Service Glitch found ");
			}
			else{
				throw new CustomException(AppConstants.AUTH_FAILURE_MESSAGE);
			}
		}catch(Exception e){
			throw new CustomException(AppConstants.AUTH_FAILURE_MESSAGE);
		}
	}

	public static HttpResponse makeHttpPostRequest(String jsonBody,String url) throws ClientProtocolException, IOException{
		HttpClient httpClient = getCloseableHttpClient();
		HttpPost httpPost = new HttpPost(url);
		httpPost.addHeader(new BasicHeader("Content-Type", "application/json"));
		StringEntity stringEntity = new StringEntity(jsonBody);
		httpPost.setEntity(stringEntity);
		return httpClient.execute(httpPost);
	}


	// The below method to bypass SSL Certificate Check
	private static CloseableHttpClient getCloseableHttpClient()
	{
		CloseableHttpClient httpClient = null;
		try {
			httpClient = HttpClients.custom().
					setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).
					setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy()
					{
						public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException
						{
							return true;
						}

					}).build()).build();
		} catch (KeyManagementException e) {
			Logging.log("KeyManagementException in creating http client instance", e);
		} catch (NoSuchAlgorithmException e) {
			Logging.log("NoSuchAlgorithmException in creating http client instance", e);
		} catch (KeyStoreException e) {
			Logging.log("KeyStoreException in creating http client instance", e);
		}
		return httpClient;
	}

}
