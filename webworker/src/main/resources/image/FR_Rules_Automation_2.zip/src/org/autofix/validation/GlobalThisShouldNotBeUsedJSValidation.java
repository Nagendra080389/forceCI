package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
 * Program to detect global this keyword usage in javascript code
 *
 * @author Akshay Anil Agrawal, Prasenjeet Banerjee
 * @version 1.0
 * @since 2020-08-11
 * @lastmodified 2020-09-7
 */
public class GlobalThisShouldNotBeUsedJSValidation implements IValidation {
	private static final Pattern LWC_FUNCTION_DECLARATION = Pattern.compile("([a-z]|[A-Z])+(\\s)*\\(.*\\)(\\s)*\\{");
	private static final Pattern LWC_CLASS_DECLARATION = Pattern.compile("extends\\s([a-z]|[A-Z])+(\\s)*\\{");

	@Override
	public List<File> runValidation(List<String> fileNameLst) {

		List<File> invalidFiles = new ArrayList<>();
		List<Violation> violationLst;
		File tempFile;
		for (String filePath : fileNameLst) {
			try {
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				violationLst = detectGlobalThisUsage(lstLines);
				if (!violationLst.isEmpty()) {
					tempFile = new File();
					tempFile.setName(filePath);
					tempFile.getViolation().addAll(violationLst);
					invalidFiles.add(tempFile);
				}
			} catch (Exception err) {
				Logging.log(err);
			}
		}
		return invalidFiles;

	}

	/**
	 * Detects global this keyword outside function blocks
	 * 
	 * @param allLines
	 * @return List<Violation>
	 */
	private List<Violation> detectGlobalThisUsage(List<String> allLines) {
		List<Violation> violationLst = new ArrayList<Violation>();
		Violation violation;
		int blockLevel = 0;
		boolean functionEncountered = false;
		int curlyBraceCounter = 0;
		for (int i = 0; i < allLines.size(); i++) {
			String currentLine = allLines.get(i);
			if (currentLine.trim().isEmpty()) {
				continue;
			}
			Matcher lwcMatcher = LWC_FUNCTION_DECLARATION.matcher(currentLine);
			Matcher lwcClassMatcher = LWC_CLASS_DECLARATION.matcher(currentLine);
			if (lwcMatcher.find() || lwcClassMatcher.find()) {
				blockLevel++;
				functionEncountered = true;
			} else if (functionEncountered && currentLine.contains("{")) {
				curlyBraceCounter++;
			} else if (functionEncountered && currentLine.contains("}") && curlyBraceCounter != 0) {
				curlyBraceCounter--;
			}
			if (currentLine.endsWith("}") && curlyBraceCounter == 0 && !currentLine.contains("})") && blockLevel > 0
					&& functionEncountered) {
				blockLevel--;
			}
			if (blockLevel == 1) {
				functionEncountered = false;
			}
			if (blockLevel == 1 && currentLine.contains("this.")) {
				violation = new Violation();
				violation.setBeginline(BigInteger.valueOf(i + 1));
				violation.setRule(CustomValidationRules.AVOID_USING_GLOBAL_THIS_JS);
				violationLst.add(violation);
			}
		}
		return violationLst;
	}

}
