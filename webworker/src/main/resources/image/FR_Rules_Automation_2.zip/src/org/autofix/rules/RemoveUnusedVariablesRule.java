package org.autofix.rules;

import java.util.List;

import org.autofix.common.CustomException;
import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

/**
 * Program to remove unused local and global variables from javascript code
 *
 * @author Prasenjeet Banerjee
 * @version 1.0
 * @since 2020-08-10
 */
public class RemoveUnusedVariablesRule implements IFRRules {

	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst)
			throws CustomException {
		String currentLine;
		ViolationInfo info;
		for (Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			currentLine = allLines.get(violation.getBeginline().intValue() - 1);
			info.setBeforeFix(currentLine);
			currentLine = currentLine.replaceFirst(currentLine.substring(violation.getBegincolumn().intValue(),
					violation.getEndcolumn().intValue() + 1), "");
			allLines.set(violation.getBeginline().intValue() - 1, currentLine);
			info.setAfterFix(currentLine);
			Reporting.violationInfos.add(info.toCSVRow());
		}
	}

}
