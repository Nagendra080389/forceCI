package org.autofix.utility;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.autofix.common.ApplicationParameter;
import org.autofix.constants.AppConstants;
import org.autofix.model.File;
import org.autofix.model.Pmd;
import org.autofix.model.Violation;

public class PMDUtility {

	private static List<String> beginEndColumnCorrectionRules = new ArrayList<>();
	private static List<String> beginEndColumnCondn = new ArrayList<>();

	static{
		beginEndColumnCorrectionRules.add("IfElseStmtsMustUseBraces");
		beginEndColumnCorrectionRules.add("ForLoopsMustUseBraces");
		beginEndColumnCorrectionRules.add("WhileLoopsMustUseBraces");
		beginEndColumnCondn.add("if");
		beginEndColumnCondn.add("else");
		beginEndColumnCondn.add("else if");
		beginEndColumnCondn.add("for");
		beginEndColumnCondn.add("while");
	}

	public static List<File> scanSourceFolder(String srcPath) throws IOException, JAXBException{
		String binPath = ApplicationParameter.getPmdBinPath();
		String rule = ApplicationParameter.getTempPmdRulePath();
		String reportFile = ApplicationParameter.getPmdReportPath();
		srcPath = ApplicationParameter.getLocalSourceFolderName();
		String command = binPath+" -d "+srcPath+" -R "+rule+" -f xml -reportfile "+reportFile;
		System.out.println("command = "+command);
		Process p = Runtime.getRuntime().exec(command);

		long startTime = new Date().getTime();
		while(p.isAlive()){
			try {
				Thread.sleep(AppConstants.PMD_THREAD_SLEEP_TIME);
				long currentTime = new Date().getTime();
				long diffInSec = (currentTime-startTime)/(1000);
				System.out.println("Process in progress, for "+diffInSec+" seconds");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Pmd pmd = AppUtility.getObject(reportFile, Pmd.class);
		return pmd.getFile();
	}



	public static void doCorrection(File file) throws IOException{
		Path path = Paths.get(file.getName());
		List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
		doCorrectionOnBeginColumn(file.getViolation(), lines);
	}

	private static void doCorrectionOnBeginColumn(List<Violation> violationLst, List<String> lines){
		String currentLine,tempLine;
		char index0Char;
		int indexInRealString;
		int lastIndexOfSemiColon;
		String lowerCaseStr;
		boolean skipThisLine;
		for(Violation violation : violationLst){
			skipThisLine = false;
			System.out.println(violation.getRule());
			if( beginEndColumnCorrectionRules.contains(violation.getRule()) ){
				currentLine = lines.get(violation.getBeginline().intValue()-1);
				tempLine = currentLine.trim();
				lowerCaseStr = tempLine.toLowerCase();
				for(String s : beginEndColumnCondn){
					if(lowerCaseStr.startsWith(s)){
						skipThisLine = true;
					}
				}
				if(!skipThisLine){
					//for beginCol
					index0Char = tempLine.charAt(0);
					System.out.println("index0Char = "+index0Char);
					indexInRealString = currentLine.indexOf(index0Char);
					System.out.println("indexInRealString = "+indexInRealString);
					System.out.println("BeginCol = "+violation.getBegincolumn());
					System.out.println("violation.getBeginline() "+violation.getBeginline());
					if(indexInRealString < violation.getBegincolumn().intValue()){
						violation.setBegincolumn(BigInteger.valueOf(indexInRealString) );
					}
					// now for endColumn
					lastIndexOfSemiColon = currentLine.lastIndexOf(';');
					if(violation.getEndcolumn().intValue() < lastIndexOfSemiColon){
						violation.setEndcolumn(BigInteger.valueOf(lastIndexOfSemiColon+1));
					}
				}

			}

		}
	}

}
