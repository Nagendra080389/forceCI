
package org.autofix.constants;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ValidationRules {
		
	public static class PMDValidationRules{

		public static final String IF_ELSE_STMTS_MUST_USE_BRACES = "IfElseStmtsMustUseBraces";
		public static final String FOR_LOOPS_MUST_USE_BRACES = "ForLoopsMustUseBraces";
		public static final String WHILE_LOOPS_MUST_USE_BRACES = "WhileLoopsMustUseBraces";
		public static final String CLASS_NAMING_CONVENTIONS = "ClassNamingConventions";
		public static final String VARIABLE_NAMING_CONVENTIONS = "VariableNamingConventions";
		public static final String EMPTY_FOR_EACH_STMT = "EmptyForeachStmt"; // not required
		public static final String EMPTY_WHILE_STMT = "EmptyWhileStmt";
		public static final String EMPTY_IF_STMT = "EmptyIfStmt";
		public static final String EMPTY_TRY_OR_FINALLY_BLOCK = "EmptyTryOrFinallyBlock";
		public static final String UNUSED_LOCAL_VARIABLE = "UnusedLocalVariable";
		public static final String UNUSED_PRIVATE_METHOD = "UnusedPrivateMethod";

		public static List<String> getAllRules(){
			List<String> ruleNameLst = new ArrayList<>();
			Field[] allFields = PMDValidationRules.class.getFields();
			String tempString = new String();
			for(Field f : allFields){
				try {
					f.setAccessible(true);
					ruleNameLst.add((String) f.get(tempString));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return ruleNameLst;
		}
	}

	public static class CustomValidationRules{
		public static final String SYSTEM_DEBUG_VALIDATION = "SystemDebugValidation";
		public static final String SYSTEM_DEBUG_VALIDATION_REMOVE = "SystemDebugValidationRemove";
		public static final String SOQL_STMT_VALIDATION = "SoqlStmtViolation";
		public static final String APEX_UNIT_TEST_METHOD_RULE = "ApexUnitTestMethodShouldHaveIsTestAnnotation";
		public static final String RECORD_TYPE_INFO_BY_DEVELOPER_NAME_RULE = "RecordTypeInfoByDeveloperName";
		public static final String AVOID_HARDCODED_STRING = "AvoidHardcordedString";
		public static final String API_VERSION_UPGRADE_XML = "ApiVersionUpgradeXML";
		public static final String EMPTY_TRY_OR_FINALLY_BLOCK = "EmptyTryOrFinallyBlock";
		public static final String USE_COLLECTION_IS_EMPTY = "UseCollectionIsEmpty";
		public static final String UPDATE_BOOLEAN_CHECK = "UpdateBooleanCheck";
		public static final String AVOID_EMPTY_BLOCKS_CSS = "RemoveEmptyBlocksFromCss";
		public static final String REMOVE_EXTRA_SEMICOLON_JS = "RemoveExtraSemiColonFromJs";
		public static final String REMOVE_EXTRA_SEMICOLON_CSS = "RemoveExtraSemiColonFromCSS";
		public static final String DEBUGGER_CHECK_JS = "RemoveDebuggerFromJs";
		public static final String GENERIC_FONT_FAMILY = "GenericFontFamily";
		public static final String AVOID_DUPLICATE_PROPERTIES_CSS = "AvoidDuplicatePropertiesCSS";
		public static final String UNDEFINED_ASSIGNMENT = "RemoveUndefinedAssignment";
		public static final String REMOVE_ALERT_JS = "RemoveAlertFromJs";
		public static final String AVOID_USING_GLOBAL_THIS_JS = "AvoidUsingGlobalThisJS";
		public static final String REMOVE_UNUSED_VARIABLES_JS = "RemoveUnusedVariablesFromJs";
		public static final String UNNECESSARY_IMPORTS_JS = "RemoveUnnecessaryImportsFromJs";
		public static final String UNUSED_PRIVATE_METHOD = "UnusedPrivateMethod";
		public static final String REMOVE_EMPTY_PROPERTIES_CSS = "RemoveEmptyPropertiesFromCSS";
		public static final String SOQL_SECURITY_ENFORCED = "SoqlSecurityEnforced";
		public static final String NULL_CHECK_BEFORE_DML = "NullCheckBeforeDML";
		
		public static List<String> getAllRules(){
			List<String> ruleNameLst = new ArrayList<>();
			Field[] allFields = CustomValidationRules.class.getFields();
			String tempString = new String();
			for(Field f : allFields){
				try {
					f.setAccessible(true);
					ruleNameLst.add((String) f.get(tempString));
				} catch (IllegalArgumentException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return ruleNameLst;
		}
	}

}
