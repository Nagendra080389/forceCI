package org.autofix.model;

public class Checker implements Cloneable{
	int beginLine;
	int endLine;
	int beginIndex;
	int endIndex;
	boolean isMultiLineComment;
	
	@Override
	public Checker clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return (Checker) super.clone();
	}

	public int getBeginLine() {
		return beginLine;
	}
	public void setBeginLine(int beginLine) {
		this.beginLine = beginLine;
	}
	public int getBeginIndex() {
		return beginIndex;
	}
	public void setBeginIndex(int beginIndex) {
		this.beginIndex = beginIndex;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public int getEndLine() {
		return endLine;
	}
	public void setEndLine(int endLine) {
		this.endLine = endLine;
	}
	public boolean isMultiLineComment() {
		return isMultiLineComment;
	}
	public void setMultiLineComment(boolean isMultiLineComment) {
		this.isMultiLineComment = isMultiLineComment;
	}
	@Override
	public String toString() {
		return "Checker [beginLine=" + beginLine + ", endLine=" + endLine + ", beginIndex=" + beginIndex + ", endIndex="
				+ endIndex + ", isMultiLineComment=" + isMultiLineComment + "]";
	}

}
