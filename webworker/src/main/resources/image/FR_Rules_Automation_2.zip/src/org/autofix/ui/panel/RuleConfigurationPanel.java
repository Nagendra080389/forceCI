package org.autofix.ui.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import org.autofix.common.CustomException;
import org.autofix.common.AutofixValidationRules;
import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.Autofix_Rule;
import org.autofix.utility.AppUtility;
import org.autofix.utility.AutofixUIUtility;

/**
 * This Class creates Panel for Auto Fix Rule configuration
 * User can select and deselect rules from the list of rules
 * @author ruchkumari
 *
 */
public class RuleConfigurationPanel extends ForceReviewerPanel implements ActionListener{

	private static final long serialVersionUID = 3165755478709420836L;
	private boolean isInitDone = false;
	private List<JCheckBox> checkboxLst;
	private final Font  SALESFORCE_SANS_ITALIC_15 = new Font("Salesforce Sans", Font.ITALIC,15);
	private final Font SALESFORCE_SANS_PLAIN_12 = new Font("Salesforce Sans", Font.PLAIN,12);
	private final Font SALESFORCE_SANS_PLAIN_15 = new Font("Salesforce Sans", Font.PLAIN,15);
	private List<JLabel> errorLabels = new ArrayList<>();
	private List<Autofix_Rule> forceReviewerConfiguredRules;
	private String errorMsg = "";
	private final int ERROR_LABEL_MAX_SIZE = 5;
	public Map<String, List<String>> ruleCategoryMap = new HashMap<String, List<String>>();
	List<JCheckBox> apex = new ArrayList<JCheckBox>();
	List<JCheckBox> js = new ArrayList<JCheckBox>();
	JCheckBox apexSelectAllCheckBox;
	JCheckBox auraSelectAllCheckBox;
	private String selectAll = "(Select All)";

	public RuleConfigurationPanel(JFrame frame) {
		super();
		this.setOpaque(false);
		this.setBackground(Color.WHITE);
		this.setForeground(Color.WHITE);
		this.setBounds(new Rectangle(250, 50, 460, 440));
		frame.add(this);
	}

	public void addErrorLabels(Box box){
		JLabel tempLabel;
		for(int i=0;i<ERROR_LABEL_MAX_SIZE;i++){
			tempLabel = new JLabel();
			tempLabel.setFont(SALESFORCE_SANS_PLAIN_15);
			tempLabel.setForeground(Color.RED);
			tempLabel.setAlignmentX(CENTER_ALIGNMENT);
			tempLabel.setAlignmentY(TOP_ALIGNMENT);
			errorLabels.add(tempLabel);
			box.add(tempLabel);
		}
	}

	public void addErrorMsg(List<String> errorList){
		for(int i=0;i<Math.min(errorLabels.size(), errorList.size());i++){
			errorLabels.get(i).setText(errorList.get(i));
		}
	}

	public void removeErrorMsg(){
		for(JLabel l : errorLabels){
			l.setText("");
		}
	}

	@Override
	public void entry() {
		if(!isInitDone){
			isInitDone = true;
			initCheckbox();			
			Box verticalBox = Box.createVerticalBox();
			addErrorLabels(verticalBox);
			JLabel staticLable = new JLabel("Please select the rules you wish to Auto-fix in your Code:");
			staticLable.setForeground(Color.BLACK);
			staticLable.setFont(SALESFORCE_SANS_ITALIC_15);
			staticLable.setAlignmentY(TOP_ALIGNMENT);
			staticLable.setAlignmentX(CENTER_ALIGNMENT);
			verticalBox.add(staticLable);
			verticalBox.add(Box.createRigidArea(new Dimension(0, 5)));
			//adding Select ALL check box on apex and aura/lwc list
			apex.add(apexSelectAllCheckBox);
			js.add(auraSelectAllCheckBox);

			// Grouping of Rules
			for(JCheckBox checkbox : checkboxLst) {
				String label = checkbox.getLabel();
				if(ruleCategoryMap.get(AppConstants.APEX_CATEGORY).contains(label)) {
					apex.add(checkbox);
				}else {
					js.add(checkbox);
				}
			}


			// creating collapsable panel for Apex and Aura/LWC
			CollapsablePanel apexCollapsablePanel = new CollapsablePanel(AppConstants.APEX_CATEGORY, apex);
			CollapsablePanel auraCollapsablePanel = new CollapsablePanel(AppConstants.AURA_LWC_CATEGORY, js);

			GridBagConstraints gbc = new GridBagConstraints();
			gbc.insets = new Insets(2, 1, 2, 1); 
			gbc.weightx = 1.0;
			gbc.anchor = gbc.LINE_START;
			gbc.fill = gbc.NONE;
			JPanel mainPanel = new JPanel(new GridBagLayout()); 
			gbc.gridwidth = gbc.REMAINDER;
			mainPanel.add(apexCollapsablePanel,gbc);
			gbc.gridwidth = gbc.REMAINDER;
			mainPanel.add(auraCollapsablePanel,gbc);

			GridBagConstraints gbc_finish = new GridBagConstraints();
			gbc_finish.gridwidth = GridBagConstraints.REMAINDER;
			gbc_finish.anchor = GridBagConstraints.NORTH;
			gbc_finish.weighty = 1;
			JPanel panelToAdd4 = new JPanel();
			panelToAdd4.setOpaque(false);
			mainPanel.add(panelToAdd4, gbc_finish, -1); // adding to remove extra space b/w two CollapsablePanel
			mainPanel.revalidate();
			mainPanel.setAlignmentY(TOP_ALIGNMENT);
			mainPanel.setAlignmentX(CENTER_ALIGNMENT);
			mainPanel.setBackground(Color.WHITE);
			mainPanel.setForeground(Color.WHITE);
			mainPanel.setBorder(BorderFactory.createEmptyBorder());
			mainPanel.setOpaque(false);
			verticalBox.add(mainPanel);

			JScrollPane verticalBoxScrollPane = new JScrollPane(verticalBox);
			verticalBoxScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED );
			verticalBoxScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER );
			verticalBoxScrollPane.setPreferredSize(new Dimension(460, 430));
			verticalBoxScrollPane.setBackground(Color.WHITE);
			verticalBoxScrollPane.setForeground(Color.WHITE);
			verticalBoxScrollPane.setBorder(BorderFactory.createEmptyBorder());
			verticalBoxScrollPane.setOpaque(false);
			verticalBoxScrollPane.getViewport().setOpaque(false);
			verticalBoxScrollPane.setAlignmentY(TOP_ALIGNMENT);
			verticalBoxScrollPane.setAlignmentX(CENTER_ALIGNMENT);
			this.add(verticalBoxScrollPane, BorderLayout.NORTH);

		}
		this.setVisible(true);
	}

	public void initCheckbox(){
		forceReviewerConfiguredRules = AutofixValidationRules.getFrRuleSettings();
		Collections.sort(forceReviewerConfiguredRules, (r1,r2)->r1.getRuleInfoForUI().compareTo(r2.getRuleInfoForUI()));
		checkboxLst = new ArrayList<>();
		JCheckBox tempCheckBox;
		for(Autofix_Rule rule : forceReviewerConfiguredRules){
			//Categorize rule names
			String category = rule.getCategory();
			List<String> ruleNames = ruleCategoryMap.get(category);
			if(ruleNames == null) {
				ruleNames = new ArrayList<String>();
				ruleCategoryMap.put(category, ruleNames);
			}
			ruleNames.add(rule.getRuleInfoForUI());

			tempCheckBox = new JCheckBox(rule.getRuleInfoForUI(),rule.isSelected());
			tempCheckBox.setBackground(Color.white);
			tempCheckBox.setForeground(Color.black);
			tempCheckBox.setFont(SALESFORCE_SANS_PLAIN_12);
			tempCheckBox.addActionListener(this);
			checkboxLst.add(tempCheckBox);
		}
		// creates SelectAll checkbox for Apex and Aura
		createSelectAllCheckBox();
	}



	/**
	 * creates SelectAll checkbox for Apex and Aura
	 */
	private void createSelectAllCheckBox() {
		apexSelectAllCheckBox  = new JCheckBox(selectAll,false);
		apexSelectAllCheckBox.setBackground(Color.white);
		apexSelectAllCheckBox.setForeground(Color.black);
		apexSelectAllCheckBox.setFont(SALESFORCE_SANS_PLAIN_12);
		apexSelectAllCheckBox.setName(AppConstants.APEX_CATEGORY);
		apexSelectAllCheckBox.addActionListener(this);

		auraSelectAllCheckBox  = new JCheckBox(selectAll,false);
		auraSelectAllCheckBox.setBackground(Color.white);
		auraSelectAllCheckBox.setForeground(Color.black);
		auraSelectAllCheckBox.setFont(SALESFORCE_SANS_PLAIN_12);
		auraSelectAllCheckBox.setName(AppConstants.AURA_LWC_CATEGORY);
		auraSelectAllCheckBox.addActionListener(this);

	}

	@Override
	public void exit() throws CustomException {
		// Do all Validation Here
		// If Validation fail throw error
		// so That user won't able to leave this panel
		if(isInitDone){
			if(!errorMsg.isEmpty()){
				if(!errorMsg.contains("please fix errors")){
					errorMsg +=", please fix errors";
				}
				addErrorMsg(AppUtility.splitToNChar(errorMsg, 65));
				throw new CustomException("Panel Is Invalid ");
			}
			for(int i=0;i<checkboxLst.size();i++){
				forceReviewerConfiguredRules.get(i).setSelected(checkboxLst.get(i).isSelected());
			}
			AutofixValidationRules.frRuleSettingUpdated();
			this.setVisible(false);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() instanceof JCheckBox){
			doCheckBoxValidation((JCheckBox)e.getSource());
		}

	}


	public void doCheckBoxValidation(JCheckBox actionedCheckBox){
		removeErrorMsg();
		int systemDebugSelectedCount = 0;
		int isLoopMustHaveBracesSelectedCount = 0;
		int totalSelectedRules = 0;
		errorMsg = "";

		//perform Select and Deselect operation on Apex and Aura
		apexSelectAllCheckBox(actionedCheckBox);
		auraSelectAllCheckBox(actionedCheckBox);

		for(JCheckBox checkBox : checkboxLst){
			checkBox.setBackground(Color.WHITE);
			if(checkBox.isSelected()){  
				++totalSelectedRules;
				if(checkBox.getText().equalsIgnoreCase(AppConstants.SYSTEM_DEBUG_VALIDATION_INFO)){
					systemDebugSelectedCount++;
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.SYSTEM_DEBUG_VALIDATION_REMOVE_INFO)){
					systemDebugSelectedCount++;
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.IF_ELSE_STMTS_MUST_USE_BRACES_INFO)){
					isLoopMustHaveBracesSelectedCount++;
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.FOR_LOOPS_MUST_USE_BRACES_INFO)){
					isLoopMustHaveBracesSelectedCount++;
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.WHILE_LOOPS_MUST_USE_BRACES_INFO)){
					isLoopMustHaveBracesSelectedCount++;
				}
			}
		}
		// Checks for Error in checkbox selection
		if (systemDebugSelectedCount > 1) {
			errorMsg = AppConstants.SYSTEM_DEBUG_ERROR_MESSAGE;
			/*
			 * +", " +CustomValidationRules.SYSTEM_DEBUG_VALIDATION+" or "
			 * +CustomValidationRules.SYSTEM_DEBUG_VALIDATION_REMOVE;
			 */
		}
		if(isLoopMustHaveBracesSelectedCount<3 && systemDebugSelectedCount>0){
			errorMsg = AppConstants.LOOP_ERROR_MESSAGE;
		}
		if(totalSelectedRules==0){
			errorMsg = AppConstants.TOTAL_SELECTED_ERROR_MESSAGE;
		}

		if(!errorMsg.isEmpty()){
			addErrorMsg(AppUtility.splitToNChar(errorMsg, 60));
			// Highlight the Incorrect Checkboxes
			for(JCheckBox checkBox : checkboxLst){
				if(checkBox.getText().equalsIgnoreCase(AppConstants.SYSTEM_DEBUG_VALIDATION_INFO)){
					if(systemDebugSelectedCount>1){
						checkBox.setBackground(Color.RED);
					}
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.SYSTEM_DEBUG_VALIDATION_REMOVE_INFO)){
					if(systemDebugSelectedCount>1){
						checkBox.setBackground(Color.RED);
					}
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.IF_ELSE_STMTS_MUST_USE_BRACES_INFO)){
					if(isLoopMustHaveBracesSelectedCount<3 && systemDebugSelectedCount>0){
						if(!checkBox.isSelected()){
							checkBox.setBackground(Color.RED);
						}
					}
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.FOR_LOOPS_MUST_USE_BRACES_INFO)){
					if(isLoopMustHaveBracesSelectedCount<3 && systemDebugSelectedCount>0){
						if(!checkBox.isSelected()){
							checkBox.setBackground(Color.RED);
						}
					}
				}
				else if(checkBox.getText().equalsIgnoreCase(AppConstants.WHILE_LOOPS_MUST_USE_BRACES_INFO)){
					if(isLoopMustHaveBracesSelectedCount<3 && systemDebugSelectedCount>0){
						if(!checkBox.isSelected()){
							checkBox.setBackground(Color.RED);
						}
					}
				}
			}

		}else{
			removeErrorMsg();
		}

		upgradeApiVersionXml(actionedCheckBox);		

	}

	private void upgradeApiVersionXml(JCheckBox actionedCheckBox) {
		if(actionedCheckBox.isSelected() && actionedCheckBox.getText().equalsIgnoreCase(AppConstants.API_VERSION_UPGRADE_XML)){
			try {
				setAPIupgradeVal("Enter Value for API upgrade",((int)AutofixUIUtility.getApiVersionUpdateValue())+"");
			} catch (CustomException e) {
				actionedCheckBox.setSelected(false);
			}
		}
	}
	private void setAPIupgradeVal(String msg,String defaultVal) throws CustomException {
		defaultVal = JOptionPane.showInputDialog(this, msg, defaultVal);
		if(defaultVal == null){
			throw new CustomException("User canceled the selection");
		}
		try{
			AutofixUIUtility.setApiVersionUpdateValue(Double.valueOf(Integer.parseInt(defaultVal)));
		}catch (NumberFormatException e) {
			setAPIupgradeVal("Please Enter Numeric Value",defaultVal);
		} catch (CustomException e) {
			setAPIupgradeVal(e.getMessage(),defaultVal);
		}
	}
	/**
	 * perform operation when Select ALL checkbox is selected for Aura Category
	 * @param actionedCheckBox
	 */
	private void auraSelectAllCheckBox(JCheckBox actionedCheckBox) {
		if(actionedCheckBox.isSelected() && actionedCheckBox.getText().equalsIgnoreCase("(Select All)")
				&& actionedCheckBox.getName()!=null	&& actionedCheckBox.getName().equalsIgnoreCase(AppConstants.AURA_LWC_CATEGORY)){
			for(JCheckBox checkbox : js) {
				checkbox.setSelected(true);				
			}
		}


		if(!actionedCheckBox.isSelected() && actionedCheckBox.getText().equalsIgnoreCase("(Select All)")
				&& actionedCheckBox.getName()!=null	&& actionedCheckBox.getName().equalsIgnoreCase(AppConstants.AURA_LWC_CATEGORY)){
			for(JCheckBox checkbox : js) {
				checkbox.setSelected(false);

			}
		}	
	}


	/**
	 * perform operation when Select ALL checkbox is selected for Apex Category
	 * @param actionedCheckBox
	 */
	private void apexSelectAllCheckBox(JCheckBox actionedCheckBox) {
		if(actionedCheckBox.isSelected() && actionedCheckBox.getText().equalsIgnoreCase(selectAll)
				&& actionedCheckBox.getName()!=null	&& actionedCheckBox.getName().equalsIgnoreCase(AppConstants.APEX_CATEGORY)){
			for(JCheckBox checkbox : apex) {
				checkbox.setSelected(true);
				if( checkbox.getText().equalsIgnoreCase(AppConstants.API_VERSION_UPGRADE_XML)){
					upgradeApiVersionXml(checkbox);
				}

			}
		}


		if(!actionedCheckBox.isSelected() && actionedCheckBox.getText().equalsIgnoreCase(selectAll)
				&& actionedCheckBox.getName()!=null	&& actionedCheckBox.getName().equalsIgnoreCase(AppConstants.APEX_CATEGORY)){
			for(JCheckBox checkbox : apex) {
				checkbox.setSelected(false);

			}
		}
	}




}
