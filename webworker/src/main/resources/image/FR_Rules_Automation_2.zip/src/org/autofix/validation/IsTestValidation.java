package org.autofix.validation;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;
/**
 * This class return the list of files 
 * having 'Apex Unit Test methods should have @isTest annotation' violation along with Violation details 
 *  Example  : Before fix : public static testMethod void method1() {
 *                            //somecode
 *                            }
 *             After fix:  @isTest
 * 						   public static void method1() {
 *                           //somecode
 * 							}
 * @author ruchkumari
 *
 */
public class IsTestValidation implements IValidation {
	public static final String TEST_METHOD_STR = "TestMethod";
	public static final String SPACE = " ";
	public static final String VOID_STR = "void";
	public static final String STATIC_STR = "static";
	public static final String OPEN_BRACKET_STR = "(";
	public static final String CLOSE_BRACKET_STR = ")";
	public static final String OPEN_BRACES_STR = "{";
	public static final ArrayList<String> methodKeywordsList = 
			new ArrayList<String>(Arrays.asList(VOID_STR.toUpperCase(), STATIC_STR.toUpperCase(), 
					OPEN_BRACES_STR, OPEN_BRACKET_STR, CLOSE_BRACKET_STR,
					TEST_METHOD_STR.toUpperCase().concat(SPACE)));


	/* (non-Javadoc)
	 * @see org.fpr.validation.IValidation#runValidation(java.util.List)
	 *  scan the list of files for which Apex Unit Test methods does not have
	 *  @isTest annotation
	 *  returns file after adding listed violations
	 */
	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		List<File> lstFiles = new ArrayList<File>();
		List<Violation> lstViolation = null;
		for (String filePath : fileNameLst) {
			try {
				int lineNo = 0;
				lstViolation = new ArrayList<Violation>();
				List<String> lstLines = Files.readAllLines(Paths.get(filePath));
				for (String strLine : lstLines) {
					if (containsIsTestKeyword(strLine)) {
						lstViolation.add(getViolation(strLine, lineNo));
					}
					lineNo++;
				}
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));				
				}
			}catch(Exception e) {
				Logging.log(e.getMessage());
			}
		}
		return lstFiles;
	}

	/**
	 * returns if string contains TestMethod
	 * @param strLine
	 * @return
	 */
	private static Boolean containsIsTestKeyword(String strLine) {
		boolean flag = false;
		if (strLine == null || strLine.isEmpty()) {
			return false;
		}

		for(String keywords: methodKeywordsList) {
			if(strLine.toUpperCase().contains(keywords)) {
				flag = true;
			}
			else {
				flag = false;
				break;
			}
		}
		return flag;
	}

	/**
	 * Method name  : getViolation
	 * Description  : runs the  @isTest annotation validations and returns violations
	 * Return Type  : Violation
	 * Parameter    : String strLine, int beginLine
	 **/
	private static Violation getViolation(String strLine, int beginLine) {
		Violation violation = new Violation();
		violation.setBeginline(BigInteger.valueOf(beginLine));
		violation.setValue(TEST_METHOD_STR);
		violation.setBegincolumn(BigInteger.valueOf(strLine.toUpperCase().indexOf(TEST_METHOD_STR.toUpperCase())));
		violation.setEndcolumn(getEndColumn(strLine));
		violation.setRule(ValidationRules.CustomValidationRules.APEX_UNIT_TEST_METHOD_RULE);
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		return violation;	
	}
	/**
	 * Method name  : getFile
	 * Description  : returns file after adding listed violations
	 * Return Type  : File
	 * Parameter    : String filePath, List<Violation> lstViolation
	 **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;	
	}
	/**
	 * Method name  : getEndColumn
	 * Description  : returns the end column of 'TestMethod'
	 * Return Type  : BigInteger
	 * Parameter    : String strLine
	 **/
	public static BigInteger getEndColumn(String strLine) {
		int endColumn = strLine.indexOf(';', strLine.indexOf(TEST_METHOD_STR));
		if (endColumn == -1) {
			endColumn = strLine.length()-1;
		}
		return BigInteger.valueOf(endColumn);
	}

}
