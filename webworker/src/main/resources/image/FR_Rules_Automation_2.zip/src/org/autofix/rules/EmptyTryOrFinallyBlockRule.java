/**************************************************************************************
Class Name		: EmptyTryOrFinallyBlockRule
Version   		: 1.0 
Created Date	: 12 May 2020
Function   		: Class to fix the empty try/finally blocks
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			12/05/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.PMDValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

public class EmptyTryOrFinallyBlockRule implements IFRRules {
	
	private static final String LITERAL_TRY = "try";
	private static final String LITERAL_CATCH = "catch";
	private static final String LITERAL_FINALLY = "finally";

	/**
     * Method name  : doOperation
     * Description  : updates the code by removing empty try/finally blocks
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationList) {
		/**
		String pieceOfCode;
		for(Violation violation : violationList) {
			pieceOfCode = "";
			for(int i=violation.getBeginline().intValue()-1; i<violation.getEndline().intValue(); i++) {
				pieceOfCode += allLines.get(i) + "\n";
				allLines.set(i, AppConstants.NEED_TO_REMOVE_THIS_LINE);
			}
			Reporting.violationInfos.add(new ViolationInfo(fileName, violation.getRule(), pieceOfCode, "").toCSVRow());
		}
		**/
		
		List<String> pieceOfCode = new ArrayList<String>();
		Stack<String> braceStack = new Stack<String>();
		boolean tryForward = false;
		boolean catchForward = false;
		boolean finallyForward = false;
		int tryBeginline = 0;
		int catchBeginline = 0;
		int finallyBeginline = 0;
		
		for(Violation violation : violationList) {
			
			try {
				
				for(int i=violation.getBeginline().intValue()-1; i<allLines.size(); i++) {
					
					//Check if try block exits
					if(allLines.get(i).trim().toLowerCase().startsWith(LITERAL_TRY)) {
						tryBeginline = i;
						pieceOfCode.add(allLines.get(i));
						tryForward = true;
						if(allLines.get(i).contains("{")) {
							braceStack.push("{");
						}
						if(allLines.get(i).contains("}") && !braceStack.isEmpty()) {
							braceStack.pop();
						}
						if(braceStack.isEmpty()) {
							tryForward = false;
						}
						System.out.println(allLines.get(i));
					} else if(tryForward) {
						if(!allLines.get(i).toLowerCase().contains(LITERAL_CATCH) && !allLines.get(i).toLowerCase().contains(LITERAL_FINALLY)) {
							pieceOfCode.add(allLines.get(i));
							System.out.println(allLines.get(i));
						}
						if(allLines.get(i).contains("{") && !allLines.get(i).toLowerCase().contains(LITERAL_CATCH) && !allLines.get(i).toLowerCase().contains(LITERAL_FINALLY)) {
							braceStack.push("{");
						}
						if(allLines.get(i).contains("}") && !braceStack.isEmpty()) {
							braceStack.pop();
						}
						if(braceStack.isEmpty()) {
							tryForward = false;
						}
					} 
					
					//Check if catch block exists
					if(allLines.get(i).trim().toLowerCase().contains(LITERAL_CATCH) && braceStack.isEmpty()) {
						catchBeginline = i;
						pieceOfCode.add(allLines.get(i));
						catchForward = true;
						if(allLines.get(i).contains("{")) {
							braceStack.push("{");
						}
						System.out.println(allLines.get(i));
					} else if(catchForward) {
						if(!allLines.get(i).toLowerCase().contains(LITERAL_FINALLY)) {
							pieceOfCode.add(allLines.get(i));
							System.out.println(allLines.get(i));
						}
						if(allLines.get(i).contains("{") && !allLines.get(i).toLowerCase().contains(LITERAL_FINALLY)) {
							braceStack.push("{");
						}
						if(allLines.get(i).contains("}") && !braceStack.isEmpty()) {
							braceStack.pop();
						}
						if(braceStack.isEmpty()) {
							catchForward = false;
						}
					} 
					
					//Check if finally block exists
					if(allLines.get(i).trim().toLowerCase().contains(LITERAL_FINALLY) && braceStack.isEmpty()) {
						finallyBeginline = i;
						pieceOfCode.add(allLines.get(i));
						finallyForward = true;
						if(allLines.get(i).contains("{")) {
							braceStack.push("{");
						}
						System.out.println(allLines.get(i));
					} else if(finallyForward) {
						pieceOfCode.add(allLines.get(i));
						if(allLines.get(i).contains("{")) {
							braceStack.push("{");
						}
						if(allLines.get(i).contains("}") && !braceStack.isEmpty()) {
							braceStack.pop();
						}
						if(braceStack.isEmpty()) {
							finallyForward = false;
						}
						System.out.println(allLines.get(i));
					}
					
					//Check if the try && catch && finally blocks have been covered if exists
					if(!tryForward && !catchForward && !finallyForward && !pieceOfCode.isEmpty() && braceStack.isEmpty() && containsTwoBlocks(pieceOfCode) && !allLines.get(i+1).trim().contains(LITERAL_FINALLY)) {
						//If empty try exists, remove catch & finally blocks too if exists
						if(containsEmptyTry(pieceOfCode, tryBeginline) != null) {
							EmptyBlockBeginEnds block = containsEmptyTry(pieceOfCode, tryBeginline);
							//violations.add(prepareViolation(block.getBeginline(), tryBeginline+pieceOfCode.size()-1));
							for(int j=block.getBeginline(); j<tryBeginline+pieceOfCode.size(); j++) {
								allLines.set(j, AppConstants.NEED_TO_REMOVE_THIS_LINE);
							}
						} 
						//If empty try doesn't exist, but the piece of code contains both catch & finally blocks
						else if(containsEmptyTry(pieceOfCode, tryBeginline) == null && containsCatchFinally(pieceOfCode)) {
							//If both catch, finally blocks exists & finally block is empty
							if(contaisEmptyFinally(pieceOfCode, finallyBeginline) != null) {
								EmptyBlockBeginEnds block = contaisEmptyFinally(pieceOfCode, finallyBeginline);
								//violations.add(prepareViolation(block.getBeginline(), block.getEndline()-1));
								for(int j=block.getBeginline(); j<block.getEndline(); j++) {
									allLines.set(j, AppConstants.NEED_TO_REMOVE_THIS_LINE);
								}
							}
							//If both try, finally are not empty but catch block is empty
							else if(containsEmptyCatch(pieceOfCode, catchBeginline) != null) {
								EmptyBlockBeginEnds block = containsEmptyCatch(pieceOfCode, catchBeginline);
								//violations.add(prepareViolation(block.getBeginline(), block.getEndline()-1));
								for(int j=block.getBeginline(); j<block.getEndline(); j++) {
									allLines.set(j, AppConstants.NEED_TO_REMOVE_THIS_LINE);
								}
							}
						}
						pieceOfCode.clear(); i=allLines.size();
					}
				}
				
			} catch(Exception ex) {
				Logging.log(ex);
			}
			
		}
	}
	
	
	/**
     * Method name  : containsEmptyTry
     * Description  : returns if the given piece of code contains any empty try block
     * Return Type  : Boolean
     * Parameter    : List<String> pieceOfCode
     **/
	private static EmptyBlockBeginEnds containsEmptyTry(List<String> pieceOfCode, int beginline) {
		List<String> effectiveCode = new ArrayList<String>();
		Stack<String> braceStack = new Stack<String>();
		boolean tryContext = false;
		boolean commentContext = false;
		boolean isEmptyBlock = true;
		int endline = beginline-1;
		for(String codeLine : pieceOfCode) {
			if(tryContext || codeLine.toLowerCase().trim().startsWith(LITERAL_TRY)) {
				tryContext = true;
				endline++;
				
				//comments written in multiple lines
				if(codeLine.trim().startsWith("/*") || commentContext) {
					commentContext = true;
					if(codeLine.trim().contains("*/")) {
						commentContext = false;
					}
				}
				
				//comments written in single line
				else if(codeLine.trim().startsWith("//")) {
					
				} else {
					if(codeLine.contains("{") && !codeLine.toLowerCase().contains(LITERAL_CATCH) && !codeLine.toLowerCase().contains(LITERAL_FINALLY)) {
						braceStack.push("{");
					}
					if(codeLine.contains("}") && !braceStack.isEmpty()) {
						braceStack.pop();
					}
					if(!codeLine.trim().startsWith(LITERAL_TRY) 
							&& !codeLine.trim().toLowerCase().replaceAll(" ", "").equalsIgnoreCase("try{") 
							&& !codeLine.toLowerCase().contains(LITERAL_CATCH) && !codeLine.toLowerCase().contains(LITERAL_FINALLY)) {
						effectiveCode.add(codeLine.trim());
					}
					if(braceStack.isEmpty()) {
						tryContext = false;
					}
				}
			}
		}
		for(String codeline : effectiveCode) {
			if(codeline.trim().length() > 1) {
				isEmptyBlock = false;
				break;
			}
		}
		if(isEmptyBlock) {
			EmptyBlockBeginEnds block = new EmptyBlockBeginEnds(beginline, endline);
			return block;
		}
		return null;
	}
	
	
	/**
     * Method name  : containsEmptyCatch
     * Description  : returns if the given piece of code contains any empty catch block
     * Return Type  : Boolean
     * Parameter    : List<String> pieceOfCode
     **/
	private static EmptyBlockBeginEnds containsEmptyCatch(List<String> pieceOfCode, int beginline) {
		List<String> effectiveCode = new ArrayList<String>();
		Stack<String> braceStack = new Stack<String>();
		boolean catchContext = false;
		boolean commentContext = false;
		boolean isEmptyBlock = true;
		int endline = beginline-1;
		for(String codeLine : pieceOfCode) {
			if(catchContext || codeLine.toLowerCase().contains(LITERAL_CATCH)) {
				catchContext = true;
				endline++;
				
				//comments written in multiple lines
				if(codeLine.trim().startsWith("/*") || commentContext) {
					commentContext = true;
					if(codeLine.trim().contains("*/")) {
						commentContext = false;
					}
				}
				
				//comments written in single line
				else if(codeLine.trim().startsWith("//")) {
					
				} else {
					if(codeLine.contains("{") && !codeLine.toLowerCase().contains(LITERAL_FINALLY)) {
						braceStack.push("{");
					}
					if(codeLine.contains("}") && !codeLine.toLowerCase().contains(LITERAL_CATCH) && !braceStack.isEmpty()) {
						braceStack.pop();
					}
					if(!codeLine.trim().toLowerCase().contains(LITERAL_CATCH) 
							&& !(codeLine.trim().toLowerCase().replaceAll(" ", "").contains("catch(") 
									||codeLine.trim().toLowerCase().replaceAll(" ", "").contains("}catch(")) 
							&& !codeLine.toLowerCase().contains(LITERAL_FINALLY)) {
						if(!braceStack.isEmpty() && !codeLine.trim().equals("}")) {
							effectiveCode.add(codeLine.trim());
						}
					}
					if(braceStack.isEmpty()) {
						catchContext = false;
					}
				}
			}
		}
		for(String codeline : effectiveCode) {
			if(codeline.trim().length() > 1) {
				isEmptyBlock = false;
				break;
			}
		}
		if(isEmptyBlock) {
			EmptyBlockBeginEnds block = new EmptyBlockBeginEnds(beginline, endline);
			return block;
		}
		return null;
	}
	
	
	/**
     * Method name  : contaisEmptyFinally
     * Description  : returns if the given piece of code contains any empty finally block
     * Return Type  : Boolean
     * Parameter    : List<String> pieceOfCode
     **/
	private static EmptyBlockBeginEnds contaisEmptyFinally(List<String> pieceOfCode, int beginline) {
		List<String> effectiveCode = new ArrayList<String>();
		Stack<String> braceStack = new Stack<String>();
		boolean finallyContext = false;
		boolean commentContext = false;
		boolean isEmptyBlock = true;
		int endline = beginline-1;
		for(String codeLine : pieceOfCode) {
			if(finallyContext || codeLine.toLowerCase().contains(LITERAL_FINALLY)) {
				endline++;
				finallyContext = true;
				
				//comments written in multiple lines
				if(codeLine.trim().startsWith("/*") || commentContext) {
					commentContext = true;
					if(codeLine.trim().contains("*/")) {
						commentContext = false;
					}
				}
				
				//comments written in single line
				else if(codeLine.trim().startsWith("//")) {
					
				} else {
					if(codeLine.contains("{")) {
						braceStack.push("{");
					}
					if(codeLine.contains("}") && !codeLine.toLowerCase().contains(LITERAL_FINALLY) && !braceStack.isEmpty()) {
						braceStack.pop();
					}
					if(!codeLine.trim().toLowerCase().contains(LITERAL_FINALLY) 
							&& !(codeLine.trim().toLowerCase().replaceAll(" ", "").equalsIgnoreCase("finally{") 
									|| codeLine.trim().toLowerCase().replaceAll(" ", "").equalsIgnoreCase("}finally{"))) {
						if(!braceStack.isEmpty() && !codeLine.trim().equals("}")) {
							effectiveCode.add(codeLine.trim());
						}
					}
					if(braceStack.isEmpty()) {
						finallyContext = false;
					}
				}
			}
		}
		for(String codeline : effectiveCode) {
			if(codeline.trim().length() > 1) {
				isEmptyBlock = false;
				break;
			}
		}
		if(isEmptyBlock) {
			EmptyBlockBeginEnds block = new EmptyBlockBeginEnds(beginline, endline);
			return block;
		}
		return null;
	}
	
	
	/**
     * Method name  : prepareViolation
     * Description  : prepares violation data within the given piece of code
     * Return Type  : Violation
     * Parameter    : int beginLine, int endLine
     **/
	private static Violation prepareViolation(int beginLine, int endLine) {
		Violation violation = new Violation();
		violation.setValue(AppConstants.REMOVE_EMPTY_TRYFINALLY_INFO);
		violation.setBeginline(BigInteger.valueOf(beginLine));
		violation.setBegincolumn(BigInteger.valueOf(0));
		violation.setEndline(BigInteger.valueOf(endLine));
		violation.setEndcolumn(BigInteger.valueOf(0));
		violation.setRule(PMDValidationRules.EMPTY_TRY_OR_FINALLY_BLOCK);
		violation.setRuleset("Code Style");
		violation.setPriority("3");
		return violation;	
	}
	
	
	/**
     * Method name  : getFile
     * Description  : returns file after adding listed violations
     * Return Type  : File
     * Parameter    : String filePath, List<Violation> lstViolation
     **/
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;	
	}
	
	
	/**
     * Method name  : containsCatchFinally
     * Description  : Checks if the given piece of code contains both catch and finally blocks
     * Return Type  : boolean
     * Parameter    : List<String> pieceOfCode
     **/
	public static boolean containsCatchFinally(List<String> pieceOfCode) {
		boolean containsCatch = false;
		boolean containsFinally = false;
		for(String codeline : pieceOfCode) {
			if(codeline.toLowerCase().contains(LITERAL_CATCH)) {
				containsCatch = true;
			}
			if(codeline.toLowerCase().contains(LITERAL_FINALLY)) {
				containsFinally = true;
			}
		}
		if(containsCatch && containsFinally) {
			return true;
		}
		return false;
	}
	
	
	private static boolean containsTwoBlocks(List<String> pieceOfCode) {
		int count = 0;
		for(String codeline : pieceOfCode) {
			if(codeline.toLowerCase().trim().startsWith(LITERAL_TRY)) {
				count++;
			}
			if(codeline.toLowerCase().contains(LITERAL_CATCH)) {
				count++;
			}
			if(codeline.toLowerCase().contains(LITERAL_FINALLY)) {
				count++;
			}
		}
		if(count > 1) {
			return true;
		}
		return false;
	}
	
	
	/**
     * Class name  	: EmptyBlockBeginEnds
     * Description  : Inner class to carry begin and end lines if a block is empty 
     * Return Type  : NA
     * Parameter    : NA
     **/
	public static class EmptyBlockBeginEnds {
		public int beginline;
		public int endline;
		public EmptyBlockBeginEnds(int beginline, int endline) {
			this.beginline = beginline;
			this.endline = endline;
		}
		public int getBeginline() {
			return beginline;
		}
		public void setBeginline(int beginline) {
			this.beginline = beginline;
		}
		public int getEndline() {
			return endline;
		}
		public void setEndline(int endline) {
			this.endline = endline;
		}
	}

}
