package org.autofix.validation;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.AppUtility;

/**
 * This class fetches all the boolean check violations in the code base.
 * Example : if(a == true || b == false)
 * @author raedu
 *
 */
public class UpdateBooleanCheckValidation implements IValidation {
	//pattern for fetching boolean checks in code base
    private final Pattern pattern = Pattern.compile("(\\s?)(?<!=)==(?!=)(\\s?)\\b((?i)true|false(?-i))\\b");

    /**
     * Method name  : runValidation
     * Description  : runs the validation on the given list of files and returns files with violations
     * Return Type  : List<File>
     * Parameter    : List<String> fileNameList
     **/
	@Override
	public List<File> runValidation(List<String> fileNameList) {
		List<File> lstFiles = new ArrayList<File>();
		List<Violation> lstViolation = null;
		List<String> lstLines = new ArrayList<String>();
		for (String filePath : fileNameList) {
			try {
				lstViolation = new ArrayList<Violation>();
				lstLines = Files.readAllLines(Paths.get(filePath));
				for (int i = 0; i < lstLines.size(); i++) {
					List<Violation> violation = getViolationList(lstLines.get(i), i + 1,pattern);
					if (AppUtility.isNotNullOrBlank(violation)) {
						lstViolation.addAll(violation);
					}
				}
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return lstFiles;
	}

	/**
     * Method name  : getViolation
     * Description  : prepares the violation list based on given piece of code
     * Return Type  : List<Violation>
     * Parameter    : String strLine, int lineNumber, Pattern pattern
     **/
	private static List<Violation> getViolationList(String strLine, int lineNumber, Pattern pattern) {
		Matcher matcher = pattern.matcher(strLine);
		Violation tempViolation;
                List<Violation> violationList= new ArrayList<>();
                while(matcher.find()){
                        tempViolation = new Violation();
                        tempViolation.setBeginline(BigInteger.valueOf(lineNumber));
                        tempViolation.setBegincolumn(BigInteger.valueOf(matcher.start()));
                        tempViolation.setEndcolumn(BigInteger.valueOf(matcher.end()));
                        tempViolation.setRule(CustomValidationRules.UPDATE_BOOLEAN_CHECK);
                        violationList.add(tempViolation);
                }
                return violationList;
	}
	/**
     * Method name  : getFile
     * Description  : get the file
     * Return Type  : File
     * Parameter    : String filePath, List<Violation> violationList
     **/
	private static File getFile(String filePath, List<Violation> violationList) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(violationList);
		return file;
	}

}
