package org.autofix.validation;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.autofix.constants.AppConstants;
import org.autofix.constants.ValidationRules.CustomValidationRules;
import org.autofix.model.File;
import org.autofix.model.Violation;
import org.autofix.utility.Logging;

/**
* Violation detection file to detect font-family block usage in CSS files which don't have at least one generic font-family used.
* If at least one generic font-family is not used in font-family block, then sans-serif is added
* Example : Before Autofix : font-family { Times New Roman; }
*  		  : After Autofix : font-family { Times New Roman, sans-serif; }
*
* @author  Amal Narayanan
* @version 1.0
* @since   2020-07-17
*/

public class GenericFontFamilyValidation implements IValidation {
	
	private static final String FONT_SANS_SERIF = "sans-serif";
	private static final String FONT_SERIF = "serif";
	private static final String FONT_MONOSPACE = "monospace";
	private static final String FONT_CURSIVE = "cursive";
	private static final String FONT_FANTASY = "fantasy";
	private static final String FONT_FAMILY = "font-family";
	private static final List<String> genericFontList = Arrays.asList(FONT_SANS_SERIF, FONT_SERIF, FONT_MONOSPACE, FONT_CURSIVE, FONT_FANTASY);	
	private static final String COMMA_SANS_SERIF_SEMI_COLON = ", sans-serif;";
	private static final String SANS_SERIF_SEMI_COLON = "sans-serif;";
	
	private static final Pattern FONT_FAMILY_PATTERN = Pattern.compile(FONT_FAMILY);
	private static final Pattern MULTIPLE_FONTS_PATTERN = Pattern.compile("[A-Za-z0-9,\\s]+");
	

	@Override
	public List<File> runValidation(List<String> fileNameLst) {
		
		List<File> lstFiles = new ArrayList<>();
		List<Violation> lstViolation = null;
		List<String> lstLines = null;
		boolean isFontFamilyFound = false;
		int fontFamilyLineNum = 0;
		StringBuilder fontString = new StringBuilder();
		List<String> fontFamilyLines = new ArrayList<>();
		Matcher fontFamilyMatcher;
		Matcher multipleFontsMatcher;
		Violation violation;
		
		for (String filePath : fileNameLst) {
			try {
				lstViolation = new ArrayList<>();
				lstLines = Files.readAllLines(Paths.get(filePath));
				for (int i = 0; i < lstLines.size(); i++) {					
					
					String currentLine = lstLines.get(i);
					//Pattern matching to check if current line contains "font-family"					
					fontFamilyMatcher = FONT_FAMILY_PATTERN.matcher(currentLine);
					boolean genericFontRequired = false;
					boolean isCommaRequired = false;
					
					/*If pattern matching successfully finds "font-family" or 
					If font-family is split over multiple lines and "font-family" has already been found*/
					if (fontFamilyMatcher.find() || isFontFamilyFound) {
						
						//Add all the lines relating to the font-family tag to a list
						fontFamilyLines.add(currentLine);
						
						//If font-family is split over multiple lines, then set values for later use
						if(!isFontFamilyFound) {
							isFontFamilyFound = true;
							fontFamilyLineNum = i+1;
						}
						
						if(currentLine.indexOf(AppConstants.SEMI_COLON_CHARACTER) != -1) {
							if (!fontFamilyLines.isEmpty()) {

								//Check whether there is a generic font family already present								
								genericFontRequired = genericFontList.stream()
										.filter(genericFont -> fontFamilyLines.stream().anyMatch(font -> font.toLowerCase().contains(genericFont)))
										.collect(Collectors.toList()).isEmpty();
								
								//If generic font family needs to be added, check if comma separation is needed
								if (genericFontRequired) {
									fontFamilyLines.forEach(fontString::append);
									multipleFontsMatcher = MULTIPLE_FONTS_PATTERN.matcher(fontString.substring(fontString.indexOf(AppConstants.COLON_CHARACTER) + 1, fontString.indexOf(AppConstants.SEMI_COLON_CHARACTER)).trim());

									//Check if there is a font style already existing to determine if comma needs to be added 
									if (multipleFontsMatcher.find()) {
										isCommaRequired = true;
									}
								}
							}
							
							//If generic font family is not required to be added, then clear the variables
							if(!genericFontRequired) {
								isFontFamilyFound = false;
								isCommaRequired = false;
								fontFamilyLines.clear();
							}
						}
						//Continue reading next line till we get ";"
						else {
							continue;
						}
					
						//Create Violation class object if generic font family needs to be added
						if(genericFontRequired) {
							violation = new Violation();
							violation.setBeginline(BigInteger.valueOf(fontFamilyLineNum));
							violation.setEndline(BigInteger.valueOf(i+1L));
							violation.setRule(CustomValidationRules.GENERIC_FONT_FAMILY);
							if(isCommaRequired) {
								violation.setValue(COMMA_SANS_SERIF_SEMI_COLON);
							}
							else {
								violation.setValue(SANS_SERIF_SEMI_COLON);
							}
							
							//Add the violation object to the list of violations
							lstViolation.add(violation);
							
							//Clear variables after creating Violation class object
							isFontFamilyFound = false;
							fontString.setLength(0);
							fontFamilyLines.clear();
						}					
				}				
			}
				if (!lstViolation.isEmpty()) {
					lstFiles.add(getFile(filePath, lstViolation));
				}
			}catch (Exception e) {
				Logging.log(e,"Error occurred for file :: "+filePath);
			}
		}
		return lstFiles;
	}

	/**
	 * Method to set list of all violations for a file
	 * @param filePath
	 * @param lstViolation
	 * @return
	 */
	private static File getFile(String filePath, List<Violation> lstViolation) {
		File file = new File();
		file.setName(filePath);
		file.getViolation().addAll(lstViolation);
		return file;
	}
}
