package org.autofix.common;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.autofix.model.AutofixRuleSetting;
import org.autofix.rules.IFRRules;
import org.autofix.validation.IValidation;

import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class AutofixConfig {

	private static Map<String, IFRRules> frRuleMap = new HashMap<>();
	public static Map<String,String> frConfigMap = new LinkedHashMap<>();
	public static Map<String,String> frValidationMap = new HashMap<>();
	private static Map<String,IValidation> frValidationObjectMap = new HashMap<>();
	private static List<AutofixRuleSetting> allAutofixRuleSettings;

	static{
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		String json="";
		try(InputStream input = classLoader.getResourceAsStream("autofix_rule_config.properties")){
			json = IOUtils.toString(input,StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Type type = new TypeToken<List<AutofixRuleSetting>>() {}.getType();
		allAutofixRuleSettings = new GsonBuilder().create().fromJson(json, type);
		for(AutofixRuleSetting setting : allAutofixRuleSettings ){
			frConfigMap.put(setting.getAutoFixRule().getUniqueRuleName(), setting.getRuleClassPath());
			if(!setting.getAutoFixRule().isPMDRule()){
				frValidationMap.put(setting.getAutoFixRule().getUniqueRuleName(), setting.getValidationClassPath());
			}
		}

		/*//reordered to fire the violations
		//FR Config Map
		frConfigMap.put("IfElseStmtsMustUseBraces","org.autofix.rules.IfElseStmtsRule");
		frConfigMap.put("ForLoopsMustUseBraces","org.autofix.rules.ForLoopRule");
		frConfigMap.put("WhileLoopsMustUseBraces","org.autofix.rules.WhileLoopRule");
		frConfigMap.put("IfStmtsMustUseBraces","org.autofix.rules.IfStmtsRule");
		frConfigMap.put("ClassNamingConventions","org.autofix.rules.ClassNamingRule");
		frConfigMap.put("VariableNamingConventions", "org.autofix.rules.VariableNamingRule");
		frConfigMap.put("ApexUnitTestMethodShouldHaveIsTestAnnotation", "org.autofix.rules.ApexUnitTestMethodRule");
		frConfigMap.put("SystemDebugValidation", "org.autofix.rules.DebugStmtsRule");
		frConfigMap.put("SystemDebugValidationRemove", "org.autofix.rules.DebugStmtsRule");
		frConfigMap.put("EmptyIfStmt", "org.autofix.rules.EmptyIfStmtRule");
		frConfigMap.put("EmptyWhileStmt", "org.autofix.rules.EmptyWhileStmtRule");
		//frConfigMap.put("RecordTypeInfoByDeveloperName", "org.autofix.rules.RecordTypeInfoRule");
		frConfigMap.put("UseCollectionIsEmpty", "org.autofix.rules.UseCollectionIsEmptyRule");
		frConfigMap.put("EmptyTryOrFinallyBlock", "org.autofix.rules.EmptyTryOrFinallyBlockRule");
		frConfigMap.put("SoqlStmtViolation", "org.autofix.rules.SoqlStmtRule");
		frConfigMap.put("AvoidHardcordedString", "org.autofix.rules.AvoidHardcodedStringRule");
		frConfigMap.put("ApiVersionUpgradeXML", "org.autofix.rules.ApiVersionUpdateRule");
		//frConfigMap.put("EmptyTryOrFinallyBlock","org.autofix.rules.EmptyTryOrFinallyBlockRule");
		frConfigMap.put("UpdateBooleanCheck", "org.autofix.rules.UpdateBooleanCheckRule");
		frConfigMap.put("UnusedPrivateMethod","org.autofix.rules.UnusedPrivateMethodRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.NULL_CHECK_BEFORE_DML, "org.autofix.rules.NullCheckForDMLRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.AVOID_EMPTY_BLOCKS_CSS, "org.autofix.rules.RemoveEmptyBlocksFromCssRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.REMOVE_EXTRA_SEMICOLON_JS, "org.autofix.rules.RemoveExtraSemiColonFromJsRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.REMOVE_EXTRA_SEMICOLON_CSS, "org.autofix.rules.RemoveExtraSemiColonFromCSSRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.DEBUGGER_CHECK_JS, "org.autofix.rules.RemoveDebuggerFromJsRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.GENERIC_FONT_FAMILY, "org.autofix.rules.GenericFontFamilyRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.AVOID_DUPLICATE_PROPERTIES_CSS, "org.autofix.rules.PropertiesShouldNotBeDuplicatedCSSRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.UNDEFINED_ASSIGNMENT, "org.autofix.rules.RemoveUndefinedAssignmentRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.REMOVE_ALERT_JS, "org.autofix.rules.RemoveAlertFromJsRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.AVOID_USING_GLOBAL_THIS_JS, "org.autofix.rules.GlobalThisShouldNotBeUsedJSRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.REMOVE_UNUSED_VARIABLES_JS, "org.autofix.rules.RemoveUnusedVariablesRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.UNNECESSARY_IMPORTS_JS, "org.autofix.rules.RemoveUnnecessaryImportsRule");
		frConfigMap.put(ValidationRules.CustomValidationRules.REMOVE_EMPTY_PROPERTIES_CSS, "org.autofix.rules.RemoveEmptyCssProperty");
		frConfigMap.put(ValidationRules.CustomValidationRules.SOQL_SECURITY_ENFORCED, "org.autofix.rules.SoqlSecurityEnforcedRule");
		frConfigMap.put("UnusedLocalVariable", "org.autofix.rules.UnusedLocalVariableRule");





		// FR Validation Map
		frValidationMap.put("SystemDebugValidation", "org.autofix.validation.SystemDebugValidation");
		frValidationMap.put("SystemDebugValidationRemove", "org.autofix.validation.SystemDebugValidation");
		frValidationMap.put("SoqlStmtViolation", "org.autofix.validation.SoqlStmtValidation");
		frValidationMap.put("ApexUnitTestMethodShouldHaveIsTestAnnotation", "org.autofix.validation.IsTestValidation");
		//frValidationMap.put("RecordTypeInfoByDeveloperName", "org.autofix.validation.RecordTypeInfoValidation");
		frValidationMap.put("AvoidHardcordedString", "org.autofix.validation.AvoidHardcodedStringValidation");
		frValidationMap.put("ApiVersionUpgradeXML", "org.autofix.validation.ApiVersionUpdateValidation");
		//frValidationMap.put("EmptyTryOrFinallyBlock", "org.autofix.validation.EmptyTryOrFinallyBlockValidation");
		frValidationMap.put("UseCollectionIsEmpty", "org.autofix.validation.UseCollectionIsEmptyValidation");
		frValidationMap.put("UpdateBooleanCheck", "org.autofix.validation.UpdateBooleanCheckValidation");
		frValidationMap.put("UnusedPrivateMethod", "org.autofix.validation.UnusedPrivateMethodValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.NULL_CHECK_BEFORE_DML, "org.autofix.validation.NullCheckForDMLValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.AVOID_EMPTY_BLOCKS_CSS, "org.autofix.validation.RemoveEmptyBlocksFromCssValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.REMOVE_EXTRA_SEMICOLON_JS, "org.autofix.validation.RemoveExtraSemiColonFromJsValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.REMOVE_EXTRA_SEMICOLON_CSS, "org.autofix.validation.RemoveExtraSemiColonFromCSSValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.DEBUGGER_CHECK_JS, "org.autofix.validation.CheckDebuggerFromJsValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.GENERIC_FONT_FAMILY, "org.autofix.validation.GenericFontFamilyValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.AVOID_DUPLICATE_PROPERTIES_CSS, "org.autofix.validation.PropertiesShouldNotBeDuplicatedCSSValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.UNDEFINED_ASSIGNMENT, "org.autofix.validation.RemoveUndefinedAssignmentValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.REMOVE_ALERT_JS, "org.autofix.validation.RemoveAlertFromJsValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.AVOID_USING_GLOBAL_THIS_JS, "org.autofix.validation.GlobalThisShouldNotBeUsedJSValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.REMOVE_UNUSED_VARIABLES_JS, "org.autofix.validation.RemoveUnusedVariablesValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.UNNECESSARY_IMPORTS_JS, "org.autofix.validation.RemoveUnnecessaryImportsValidation");
		frValidationMap.put(ValidationRules.CustomValidationRules.REMOVE_EMPTY_PROPERTIES_CSS, "org.autofix.validation.RemoveEmptyPropertiesFromCSS");
		frValidationMap.put(ValidationRules.CustomValidationRules.SOQL_SECURITY_ENFORCED, "org.autofix.validation.SoqlSecurityEnforcedValidation");*/
	}

	public static void initFRConfig() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException{
		if(frRuleMap.isEmpty()){
			IFRRules tempFrRule;
			for(String key : frConfigMap.keySet()){
				tempFrRule = (IFRRules) Class.forName(frConfigMap.get(key)).getConstructor().newInstance();
				frRuleMap.put(key, tempFrRule);
			}
		}
	}

	public static void initFrValidation() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException{
		if(frValidationObjectMap.isEmpty()){
			IValidation tempValidation;
			for(String key : frValidationMap.keySet()){

				tempValidation = (IValidation) Class.forName(frValidationMap.get(key)).getConstructor().newInstance();

				frValidationObjectMap.put(key, tempValidation);
			}
		}
	}

	public static IFRRules getFRRule(String ruleName) throws CustomException{
		IFRRules frRule = frRuleMap.get(ruleName);
		if(frRule == null)
			throw new CustomException("No entry found for Rule :: "+ruleName);
		return frRule;
	}

	public static IValidation getFRValidation(String validationName) throws CustomException{
		IValidation validation = frValidationObjectMap.get(validationName);

		if(validation == null){
			throw new CustomException("No Validation Found for :: "+validationName);
		}
		return validation;
	}

	/*public static Map<String, String> getFrConfigMap() {
		return frConfigMap;
	}*/

	public static List<AutofixRuleSetting> getAllAutofixRuleSettings() {
		return allAutofixRuleSettings;
	}

}
