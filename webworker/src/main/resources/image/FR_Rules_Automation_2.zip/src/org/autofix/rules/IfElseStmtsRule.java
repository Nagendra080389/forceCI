/**************************************************************************************
Class Name		: IfElseStmtsRule
Version   		: 1.0 
Created Date	: 03 Feb 2020
Function   		: Class to fix the if else statement violations
Modification Log :
* Developer                   Date                   Description
* ----------------------------------------------------------------------------                 
* Ette Balakrishna			03/02/2020              Initial Version
*************************************************************************************/

package org.autofix.rules;

import java.math.BigInteger;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.autofix.model.Violation;
import org.autofix.model.ViolationInfo;
import org.autofix.utility.Reporting;

public class IfElseStmtsRule implements IFRRules{
	private final static String OPEN_BRACE = "{ ";
	private final static String CLOSE_BRACE = " }";
	private final static String SEMI_COLON = ";";
	private final static Pattern IF_ELSE_FOR_WHILE_PATTERN = Pattern.compile("(.*)\\{(.*)if(.*)"
			+ "|(.*)\\{(.*)else(.*)"
			+ "|(.*)\\{(.*)for(.*)"
			+ "|(.*)\\{(.*)while(.*)");
	private final static Pattern IF_ELSE_FOR_WHILE_PATTERN_OPENBRACE = Pattern.compile("(.*)\\{(.*)if(.*)\\{(.*)"
			+ "|(.*)\\{(.*)else(.*)\\{(.*)"
			+ "|(.*)\\{(.*)for(.*)\\{(.*)"
			+ "|(.*)\\{(.*)while(.*)\\{(.*)");
	
	/**
     * Method name  : doOperation
     * Description  : updates the code by adding braces to if else loop
     * Return Type  : void
     * Parameter    : List<String> allLines, List<Violation> violationLst
     **/
	@Override
	public void doOperation(String fileName, List<String> allLines, List<Violation> violationLst) {
		String content;
		ViolationInfo info;
		for(Violation violation : violationLst) {
			info = new ViolationInfo(fileName, violation.getRule());
			content = allLines.get(violation.getBeginline().intValue()-1);
			info.setBeforeFix(content);
			content = content.substring(0, violation.getBegincolumn().intValue()-1) + OPEN_BRACE + content.substring(violation.getBegincolumn().intValue()-1);
			allLines.set(violation.getBeginline().intValue()-1, content);
			if(violation.getNumberOfEndBraces() == 0) {
				info.setAfterFix(content.trim().replace("{", "{\n\t").replace("}", "\n}"));
				Reporting.violationInfos.add(info.toCSVRow());
			}
			for(Integer i=0 ; i<violation.getNumberOfEndBraces() ; i++) {
				if(!allLines.get(violation.getEndline().intValue()-1).trim().endsWith(SEMI_COLON)) {
					violation = updateEndBraceIndex(violation, allLines);
				}
				content = allLines.get(violation.getEndline().intValue()-1);
				try {
					content = content.substring(0, violation.getEndcolumn().intValue()+2) + CLOSE_BRACE + content.substring(violation.getEndcolumn().intValue()+2);
				} catch(Exception ex) {
					content = content + CLOSE_BRACE;
				}
				allLines.set(violation.getEndline().intValue()-1, content);
				if(i == violation.getNumberOfEndBraces()-1) {
					info.setAfterFix(content.trim().replace("{", "{\n\t").replace("}", "\n}"));
					Reporting.violationInfos.add(info.toCSVRow());
				}
			}
		}
	}
	
	
	/**
     * Method name  : updateEndBraceIndex
     * Description  : checks if the end brace placement is wrong
     * Return Type  : Violation
     * Parameter    : Violation violation, List<String> allLines
     **/
	private static Violation updateEndBraceIndex(Violation violation, List<String> allLines) {
		String codeline;
		Matcher matcher;
		
		codeline = allLines.get(violation.getEndline().intValue()-1);
		matcher = IF_ELSE_FOR_WHILE_PATTERN_OPENBRACE.matcher(codeline);
		while(matcher.find()) {
			violation = correctEndBraceIndex(violation, allLines, true);
		}
		matcher = IF_ELSE_FOR_WHILE_PATTERN.matcher(codeline);
		while(matcher.find()) {
			violation = correctEndBraceIndex(violation, allLines, false);
		}
		return violation;
	}
	
	
	/**
     * Method name  : correctEndBraceIndex
     * Description  : updates the end brace line number and end column in case the placement is wrong
     * Return Type  : Violation
     * Parameter    : Violation violation, List<String> allLines, boolean containsOpenBrace
     **/
	private static Violation correctEndBraceIndex(Violation violation, List<String> allLines, boolean containsOpenBrace) {
		Stack<String> braceStack = new Stack<String>();
		if(containsOpenBrace) {
			braceStack.push(OPEN_BRACE);
		}
		for(int i=violation.getEndline().intValue(); i<allLines.size(); i++) {
			if(allLines.get(i).contains(OPEN_BRACE.trim())) {
				braceStack.push(OPEN_BRACE);
			}
			if(allLines.get(i).contains(CLOSE_BRACE.trim())) {
				braceStack.pop();
			}
			if(braceStack.isEmpty()) {
				violation.setEndline(BigInteger.valueOf(i));
				violation.setEndcolumn(BigInteger.valueOf(allLines.get(i).length()));
				return violation;
			}
		}
		return violation;
	}

}
